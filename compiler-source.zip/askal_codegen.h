/**
 * Copyright 2026 forXsis
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /** Contact me!
 * Gmail: forxtrees@gmail.com
 * Git: https://github.com/forXsis
 * Askal GitHub project: https://github.com/forXsis/askal
 */

#pragma once
#include "askal_ast.h"
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <string>

namespace askal {

    class Codegen {
    public:
        explicit Codegen(Program* prog);
        std::vector<uint8_t> build();
        void set_opt_level(int lvl) { opt_level_ = lvl; }

    private:
        Program* prog_;

        int opt_level_ = 1;

        uint32_t object_temp_id_ = 0;
        struct LoopCtx {
            std::vector<size_t> break_patches;
            std::vector<size_t> continue_patches;
            uint32_t start_ip;
        };
        std::vector<LoopCtx> loop_stack_;
        struct VarInfo {
            uint32_t    id = 0;
            std::string name;
            DataType    type = DataType::NULL_;
            uint32_t    size = 0;
            bool        global = false;
            bool        is_class_member = false;
            bool        is_arg = false;
            bool        is_frame_local = false;
            uint32_t    owner_fun_id = 0;
            std::string class_name;
            std::vector<uint8_t> init_bytes;
            bool        is_class_object = false;
            uint32_t    object_class_id = 0;
        };

        struct FunInfo {
            uint32_t             id = 0;
            std::string          name;
            DataType             ret_type = DataType::NULL_;
            std::vector<FunDecl::Arg> params;
            FunDecl* ast = nullptr;
            std::string          class_name;
            std::vector<uint8_t> body;
            bool                 is_method = false;

            struct LocalVar {
                uint32_t    id = 0;
                DataType    type = DataType::NULL_;
                std::string name;
            };
            std::vector<LocalVar> locals;
        };

        struct ClassInfo {
            uint32_t id = 0;
            std::string name;
            std::vector<uint32_t> var_ids;
            std::vector<uint32_t> fun_ids;
            uint32_t    total_field_bytes = 0;
        };

        struct TryContext {
            std::vector<size_t> catch_jumps;
            size_t              handler_pop_patch;
        };
        std::vector<TryContext> try_stack_;

        std::unordered_map<std::string, uint32_t> global_vars_;
        std::unordered_map<std::string, uint32_t> functions_;
        std::unordered_map<std::string, uint32_t> classes_;
        std::unordered_set<std::string> used_libs_set_;

        std::unordered_map<std::string,
            std::unordered_map<std::string, uint32_t>> class_vars_;
        std::unordered_map<std::string,
            std::unordered_map<std::string, uint32_t>> class_funs_;

        std::unordered_map<uint32_t, VarInfo>   vars_;
        std::unordered_map<uint32_t, FunInfo>   funs_;
        std::unordered_map<uint32_t, ClassInfo> classes_info_;

        uint32_t next_var_id_ = 1;
        uint32_t next_fun_id_ = 1;
        uint32_t next_class_id_ = 1;

        std::unordered_map<FunDecl*,
            std::unordered_map<std::string, uint32_t>> fun_locals_;

        std::vector<uint8_t> out_;
        std::vector<uint8_t> funcs_section_;
        std::vector<uint8_t> classes_section_;
        std::vector<uint8_t> vars_section_;

        void pass1_register_toplevel();
        void pass2_register_and_resolve();
        void resolve_int_sizes();
        void pass3_typecheck();

        void emit_switch(SwitchStmt* s, const std::string& cls,
            const std::unordered_map<std::string, uint32_t>* locals);

        DataType infer_type(Expr* e, const std::string& cls,
            const std::unordered_map<std::string, uint32_t>* locals);
        void check_stmt(Stmt* s, const std::string& cls,
            const std::unordered_map<std::string, uint32_t>* locals,
            DataType current_ret_type);

        void register_vars_in(Stmt* s, const std::string& cls,
            std::unordered_map<std::string, uint32_t>& locals,
            uint32_t owner_fun_id,
            bool in_block = false);

        void resolve_in_stmt(Stmt* s, const std::string& cls,
            std::unordered_map<std::string, uint32_t>* locals);
        void resolve_in_expr(Expr* e, const std::string& cls,
            std::unordered_map<std::string, uint32_t>* locals);

        void emit_program();
        void emit_fun_decl(FunDecl* f);
        void emit_class_decl(ClassDecl* c);
        void emit_main_stmt(Stmt* s);

        void emit_try(TryStmt* s, const std::string& cls,
            const std::unordered_map<std::string, uint32_t>* locals);
        void emit_throw(ThrowStmt* s, const std::string& cls,
            const std::unordered_map<std::string, uint32_t>* locals);

        void emit_stmt(Stmt* s, const std::string& cls,
            const std::unordered_map<std::string, uint32_t>* locals);
        void emit_expr(Expr* e, const std::string& cls,
            const std::unordered_map<std::string, uint32_t>* locals);

        void emit_if(IfStmt* s, const std::string& cls,
            const std::unordered_map<std::string, uint32_t>* locals);
        void emit_while(WhileStmt* s, const std::string& cls,
            const std::unordered_map<std::string, uint32_t>* locals);
        void emit_for(ForStmt* s, const std::string& cls,
            const std::unordered_map<std::string, uint32_t>* locals);

        void emit_new_object(CallExpr* c, const std::string& cls,
            const std::unordered_map<std::string, uint32_t>* locals);
        void emit_field_load(VarExpr* v, const std::string& cls,
            const std::unordered_map<std::string, uint32_t>* locals);
        void emit_field_store(AssignStmt* a, const std::string& cls,
            const std::unordered_map<std::string, uint32_t>* locals);
        void emit_method_call(CallExpr* c, const std::string& cls,
            const std::unordered_map<std::string, uint32_t>* locals);

        void push_u8(uint8_t b) { out_.push_back(b); }
        void push_u16(uint16_t v) { for (int i = 0; i < 2; ++i) out_.push_back((v >> (i * 8)) & 0xFF); }
        void push_u32(uint32_t v) { for (int i = 0; i < 4; ++i) out_.push_back((v >> (i * 8)) & 0xFF); }
        void push_u64(uint64_t v) { for (int i = 0; i < 8; ++i) out_.push_back((v >> (i * 8)) & 0xFF); }
        void push_str(const std::string& s) { out_.insert(out_.end(), s.begin(), s.end()); }

        static void append_u8(std::vector<uint8_t>& v, uint8_t  b);
        static void append_u16(std::vector<uint8_t>& v, uint16_t x);
        static void append_u32(std::vector<uint8_t>& v, uint32_t x);
        static void append_u64(std::vector<uint8_t>& v, uint64_t x);
        static void append_str(std::vector<uint8_t>& v, const std::string& s);
        void append_var_default(std::vector<uint8_t>& v, DataType t);

        void patch_u32(size_t pos, uint32_t val);

        static DataType smallest_int_for(int64_t v);
        static uint32_t int_type_size(DataType t);

        uint32_t lookup_var(const std::string& name, const std::string& cls,
            const std::unordered_map<std::string, uint32_t>* locals);
        uint32_t lookup_fun(const std::string& name, const std::string& cls);
    };

}