/**
 * Copyright 2026 forXsis
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /** Contact me!
 * Gmail: forxtrees@gmail.com
 * Git: https://github.com/forXsis
 * Askal GitHub project: https://github.com/forXsis/askal
 */

#include "askal_codegen.h"
#include "askal_optimizer.h"
#include <stdexcept>
#include <cstring>
#include <cmath>
#include <functional>

namespace {

    using askal::DataType;

    bool is_numeric(DataType t) {
        switch (t) {
        case DataType::INT8:
        case DataType::INT16:
        case DataType::INT32:
        case DataType::INT64:
        case DataType::INT:
        case DataType::FLOAT:
            return true;
        default:
            return false;
        }
    }

    bool is_boolish(DataType t) {
        switch (t) {
        case DataType::BOOL:
        case DataType::INT8:
        case DataType::INT16:
        case DataType::INT32:
        case DataType::INT64:
        case DataType::INT:
            return true;
        default:
            return false;
        }
    }

    DataType wider_numeric(DataType a, DataType b) {
        if (a == DataType::FLOAT || b == DataType::FLOAT) return DataType::FLOAT;
        auto rank = [](DataType t) -> int {
            switch (t) {
            case DataType::INT8:  return 1;
            case DataType::INT16: return 2;
            case DataType::INT32: return 3;
            case DataType::INT64: return 4;
            case DataType::INT:   return 4;
            default:              return 0;
            }
            };
        return rank(a) >= rank(b) ? a : b;
    }

    bool types_assignable(DataType target, DataType value) {
        if (target == DataType::AUTO) return true;
        if (value == DataType::AUTO) return true;
        if (value == DataType::NULL_) return true;
        if (target == value) return true;
        if (is_numeric(target) && is_numeric(value)) return true;
        if (target == DataType::BOOL && is_numeric(value)) return true;
        if (is_numeric(target) && value == DataType::BOOL) return true;
        if (target == DataType::LIST && (value == DataType::LIST || value == DataType::ARRAY)) return true;
        if (target == DataType::ARRAY && (value == DataType::ARRAY || value == DataType::LIST)) return true;
        if (target == DataType::DICT && value == DataType::DICT) return true;
        return false;
    }

    std::string type_name(DataType t) {
        switch (t) {
        case DataType::STR:   return "str";
        case DataType::BOOL:  return "bool";
        case DataType::FLOAT: return "float";
        case DataType::INT8:  return "int8";
        case DataType::INT16: return "int16";
        case DataType::INT32: return "int32";
        case DataType::INT64: return "int64";
        case DataType::INT:   return "int";
        case DataType::NULL_: return "null";
        case DataType::BIN:   return "bin";
        case DataType::HEX:   return "hex";
        case DataType::AUTO:  return "auto";
        case DataType::OBJECT:return "object";
        case DataType::ARRAY: return "array";
        case DataType::LIST:  return "list";
        case DataType::DICT:  return "dict";
        }
        return "?";
    }

}

namespace askal {

    Codegen::Codegen(Program* prog) : prog_(prog) {}

    void Codegen::append_u8(std::vector<uint8_t>& v, uint8_t  b) { v.push_back(b); }
    void Codegen::append_u16(std::vector<uint8_t>& v, uint16_t x) {
        for (int i = 0; i < 2; ++i) v.push_back((x >> (i * 8)) & 0xFF);
    }
    void Codegen::append_u32(std::vector<uint8_t>& v, uint32_t x) {
        for (int i = 0; i < 4; ++i) v.push_back((x >> (i * 8)) & 0xFF);
    }
    void Codegen::append_u64(std::vector<uint8_t>& v, uint64_t x) {
        for (int i = 0; i < 8; ++i) v.push_back((x >> (i * 8)) & 0xFF);
    }
    void Codegen::append_str(std::vector<uint8_t>& v, const std::string& s) {
        v.insert(v.end(), s.begin(), s.end());
    }

    DataType Codegen::smallest_int_for(int64_t v) {
        if (v >= INT8_MIN && v <= INT8_MAX)  return DataType::INT8;
        if (v >= INT16_MIN && v <= INT16_MAX) return DataType::INT16;
        if (v >= INT32_MIN && v <= INT32_MAX) return DataType::INT32;
        return DataType::INT64;
    }

    uint32_t Codegen::int_type_size(DataType t) {
        switch (t) {
        case DataType::INT8:  return 1;
        case DataType::INT16: return 2;
        case DataType::INT32: return 4;
        case DataType::INT64: return 8;
        case DataType::INT:   return 8;
        default:              return fixed_size(t);
        }
    }

    void Codegen::pass1_register_toplevel() {
        {
            uint32_t id = next_var_id_++;
            VarInfo info;
            info.id = id;
            info.name = "__self_temp";
            info.type = DataType::OBJECT;
            info.size = 8;
            info.global = true;
            vars_[id] = info;
            object_temp_id_ = id;
        }
        for (auto& stmt : prog_->statements) {
            if (auto* f = dynamic_cast<FunDecl*>(stmt.get())) {
                if (functions_.count(f->name))
                    throw std::runtime_error("Duplicate function '" + f->name + "'");
                f->id = next_fun_id_++;
                functions_[f->name] = f->id;
                FunInfo fi;
                fi.id = f->id; fi.name = f->name;
                fi.ret_type = f->return_type;
                fi.params = f->args;
                fi.ast = f;
                funs_[f->id] = std::move(fi);
            }
            else if (auto* c = dynamic_cast<ClassDecl*>(stmt.get())) {
                if (classes_.count(c->name))
                    throw std::runtime_error("Duplicate class '" + c->name + "'");
                c->id = next_class_id_++;
                classes_[c->name] = c->id;
                ClassInfo ci;
                ci.id = c->id; ci.name = c->name;
                classes_info_[c->id] = std::move(ci);

                for (auto& m : c->members) {
                    if (auto* f = dynamic_cast<FunDecl*>(m.get())) {
                        if (class_funs_[c->name].count(f->name))
                            throw std::runtime_error(
                                "Duplicate method '" + f->name + "' in class '" + c->name + "'");
                        f->id = next_fun_id_++;
                        class_funs_[c->name][f->name] = f->id;
                        FunInfo fi;
                        fi.id = f->id; fi.name = f->name;
                        fi.ret_type = f->return_type;
                        fi.params = f->args;
                        fi.ast = f;
                        fi.class_name = c->name;
                        fi.is_method = true;
                        funs_[f->id] = std::move(fi);
                    }
                }
            }
        }
    }

    void Codegen::register_vars_in(Stmt* s, const std::string& cls,
        std::unordered_map<std::string, uint32_t>& locals,
        uint32_t owner_fun_id, bool in_block) {

        if (dynamic_cast<BreakStmt*>(s) || dynamic_cast<ContinueStmt*>(s)) return;

        if (auto* v = dynamic_cast<VarDeclStmt*>(s)) {
            bool is_member = !cls.empty() && locals.empty();
            bool is_frame_local = (owner_fun_id != 0) && !is_member;
            bool is_top_global = !is_member && !is_frame_local && !in_block;

            uint32_t id = next_var_id_++;
            v->id = id;

            VarInfo info;
            info.id = id;
            info.name = v->name;
            info.type = v->type;
            info.size = int_type_size(v->type);
            info.global = is_top_global;
            info.is_class_member = is_member;
            info.is_frame_local = is_frame_local;
            info.owner_fun_id = owner_fun_id;
            info.class_name = cls;

            if (v->type == DataType::OBJECT) {
                info.is_class_object = true;
                info.size = 8;

                if (!v->class_type_name.empty()) {
                    auto cit = classes_.find(v->class_type_name);
                    if (cit == classes_.end()) {
                        throw std::runtime_error(
                            "Unknown class '" + v->class_type_name +
                            "' for variable '" + v->name + "'");
                    }
                    info.object_class_id = cit->second;
                }
            }

            vars_[id] = std::move(info);

            if (is_member) {
                if (class_vars_[cls].count(v->name))
                    throw std::runtime_error("Duplicate member '" + v->name +
                        "' in class '" + cls + "'");
                class_vars_[cls][v->name] = id;
                classes_info_[classes_[cls]].var_ids.push_back(id);
            }
            else if (is_frame_local) {
                if (locals.count(v->name))
                    throw std::runtime_error("Duplicate local variable '" + v->name + "'");
                locals[v->name] = id;

                FunInfo::LocalVar lv;
                lv.id = id;
                lv.type = v->type;
                lv.name = v->name;
                funs_[owner_fun_id].locals.push_back(std::move(lv));
            }
            else if (is_top_global) {
                if (global_vars_.count(v->name))
                    throw std::runtime_error("Duplicate global variable '" + v->name + "'");
                global_vars_[v->name] = id;
            }
            else {
                if (locals.count(v->name))
                    throw std::runtime_error("Duplicate local variable '" + v->name + "'");
                locals[v->name] = id;
            }
            return;
        }

        if (auto* f = dynamic_cast<FunDecl*>(s)) {
            (void)f;
            return;
        }

        if (auto* c = dynamic_cast<ClassDecl*>(s)) {
            for (auto& m : c->members) {
                std::unordered_map<std::string, uint32_t> empty;
                register_vars_in(m.get(), c->name, empty, 0, false);
            }
            return;
        }

        if (auto* i = dynamic_cast<IfStmt*>(s)) {
            auto then_locals = locals;
            for (auto& b : i->then_body)
                register_vars_in(b.get(), cls, then_locals, owner_fun_id, true);
            i->then_scope = std::move(then_locals);

            auto else_locals = locals;
            for (auto& b : i->else_body)
                register_vars_in(b.get(), cls, else_locals, owner_fun_id, true);
            i->else_scope = std::move(else_locals);
            return;
        }

        if (auto* w = dynamic_cast<WhileStmt*>(s)) {
            auto body_locals = locals;
            for (auto& b : w->body)
                register_vars_in(b.get(), cls, body_locals, owner_fun_id, true);
            w->body_scope = std::move(body_locals);
            return;
        }

        if (auto* f = dynamic_cast<ForStmt*>(s)) {
            auto init_locals = locals;
            if (f->init) {
                register_vars_in(f->init.get(), cls, init_locals, owner_fun_id, true);
            }
            f->for_scope = init_locals;

            auto body_locals = init_locals;
            for (auto& b : f->body)
                register_vars_in(b.get(), cls, body_locals, owner_fun_id, true);
            f->body_scope = std::move(body_locals);
            return;
        }

        if (auto* sw = dynamic_cast<SwitchStmt*>(s)) {
            auto body_locals = locals;
            for (auto& c : sw->cases) {
                for (auto& b : c.body) {
                    register_vars_in(b.get(), cls, body_locals, owner_fun_id, true);
                }
            }
            for (auto& b : sw->default_body) {
                register_vars_in(b.get(), cls, body_locals, owner_fun_id, true);
            }
            sw->body_scope = std::move(body_locals);
            return;
        }

        if (auto* t = dynamic_cast<TryStmt*>(s)) {
            auto try_locals = locals;
            for (auto& b : t->try_body)
                register_vars_in(b.get(), cls, try_locals, owner_fun_id, true);
            t->try_scope = std::move(try_locals);
            auto catch_locals = locals;
            if (!t->catch_var.empty()) {
                uint32_t id = next_var_id_++;
                t->catch_var_id = id;

                VarInfo info;
                info.id = id;
                info.name = t->catch_var;
                info.type = DataType::AUTO;
                info.size = 260;
                info.is_frame_local = (owner_fun_id != 0);
                info.owner_fun_id = owner_fun_id;
                vars_[id] = std::move(info);

                catch_locals[t->catch_var] = id;

                if (owner_fun_id != 0) {
                    FunInfo::LocalVar lv;
                    lv.id = id;
                    lv.type = DataType::AUTO;
                    lv.name = t->catch_var;
                    funs_[owner_fun_id].locals.push_back(std::move(lv));
                }
            }
            for (auto& b : t->catch_body)
                register_vars_in(b.get(), cls, catch_locals, owner_fun_id, true);
            t->catch_scope = std::move(catch_locals);

            auto finally_locals = locals;
            for (auto& b : t->finally_body)
                register_vars_in(b.get(), cls, finally_locals, owner_fun_id, true);
            t->finally_scope = std::move(finally_locals);
            return;
        }

        if (dynamic_cast<ThrowStmt*>(s)) return;
        if (dynamic_cast<AssignStmt*>(s)) return;
        if (dynamic_cast<AssignIndexStmt*>(s)) return;
        if (dynamic_cast<ExprStmt*>(s))   return;
        if (dynamic_cast<ReturnStmt*>(s)) return;

        throw std::runtime_error("Unknown statement node");
    }

    void Codegen::pass2_register_and_resolve() {
        for (auto& stmt : prog_->statements) {
            if (auto* f = dynamic_cast<FunDecl*>(stmt.get())) {
                auto& locals = fun_locals_[f];
                for (auto& a : f->args) {
                    uint32_t id = next_var_id_++;
                    a.id = id;
                    VarInfo info;
                    info.id = id; info.name = a.name;
                    info.type = a.type; info.size = int_type_size(a.type);
                    info.is_arg = true;
                    info.owner_fun_id = f->id;
                    if (a.type == DataType::OBJECT) {
                        info.is_class_object = true;
                        info.size = 8;
                        if (!a.class_type_name.empty()) {
                            auto cit = classes_.find(a.class_type_name);
                            if (cit == classes_.end()) {
                                throw std::runtime_error(
                                    "Unknown class '" + a.class_type_name +
                                    "' for argument '" + a.name + "'");
                            }
                            info.object_class_id = cit->second;
                        }
                    }
                    vars_[id] = std::move(info);
                    locals[a.name] = id;
                }
                for (auto& body_stmt : f->body) {
                    register_vars_in(body_stmt.get(), "", locals, f->id, false);
                }
            }
            else if (auto* c = dynamic_cast<ClassDecl*>(stmt.get())) {
                for (auto& m : c->members) {
                    if (auto* v = dynamic_cast<VarDeclStmt*>(m.get())) {
                        std::unordered_map<std::string, uint32_t> empty;
                        register_vars_in(v, c->name, empty, 0, false);
                    }
                }
                for (auto& m : c->members) {
                    if (auto* fm = dynamic_cast<FunDecl*>(m.get())) {
                        auto& locals = fun_locals_[fm];
                        for (auto& a : fm->args) {
                            uint32_t id = next_var_id_++;
                            a.id = id;
                            VarInfo info;
                            info.id = id; info.name = a.name;
                            info.type = a.type; info.size = int_type_size(a.type);
                            info.is_arg = true;
                            info.owner_fun_id = fm->id;
                            if (a.type == DataType::OBJECT) {
                                info.is_class_object = true;
                                info.size = 8;
                                if (!a.class_type_name.empty()) {
                                    auto cit = classes_.find(a.class_type_name);
                                    if (cit == classes_.end()) {
                                        throw std::runtime_error(
                                            "Unknown class '" + a.class_type_name +
                                            "' for argument '" + a.name + "'");
                                    }
                                    info.object_class_id = cit->second;
                                }
                            }
                            vars_[id] = std::move(info);
                            locals[a.name] = id;
                        }
                        for (auto& body_stmt : fm->body) {
                            register_vars_in(body_stmt.get(), c->name, locals, fm->id, false);
                        }
                    }
                }
            }
            else {
                std::unordered_map<std::string, uint32_t> empty;
                register_vars_in(stmt.get(), "", empty, 0, false);
            }
        }

        for (auto& stmt : prog_->statements) {
            if (auto* f = dynamic_cast<FunDecl*>(stmt.get())) {
                auto* locals = &fun_locals_[f];
                for (auto& body_stmt : f->body) {
                    resolve_in_stmt(body_stmt.get(), "", locals);
                }
            }
            else if (auto* c = dynamic_cast<ClassDecl*>(stmt.get())) {
                for (auto& m : c->members) {
                    if (auto* fm = dynamic_cast<FunDecl*>(m.get())) {
                        auto* locals = &fun_locals_[fm];
                        for (auto& body_stmt : fm->body) {
                            resolve_in_stmt(body_stmt.get(), c->name, locals);
                        }
                    }
                    else if (auto* v = dynamic_cast<VarDeclStmt*>(m.get())) {
                        if (v->init) {
                            std::unordered_map<std::string, uint32_t> empty;
                            resolve_in_expr(v->init.get(), c->name, &empty);
                        }
                    }
                }
            }
            else {
                std::unordered_map<std::string, uint32_t> empty;
                resolve_in_stmt(stmt.get(), "", &empty);
            }
        }
    }

    void Codegen::resolve_in_expr(Expr* e, const std::string& cls,
        std::unordered_map<std::string, uint32_t>* locals) {
        if (!e) return;
        if (auto* li = dynamic_cast<ListLitExpr*>(e)) {
            for (auto& it : li->items) resolve_in_expr(it.get(), cls, locals);
            return;
        }
        if (auto* di = dynamic_cast<DictLitExpr*>(e)) {
            for (auto& [k, v] : di->entries) resolve_in_expr(v.get(), cls, locals);
            return;
        }
        if (auto* ie = dynamic_cast<IndexExpr*>(e)) {
            resolve_in_expr(ie->container.get(), cls, locals);
            resolve_in_expr(ie->index.get(), cls, locals);
            return;
        }
        if (auto* v = dynamic_cast<VarExpr*>(e)) {
            if (v->class_name.empty()) {
                if (locals) {
                    auto lit = locals->find(v->name);
                    if (lit != locals->end()) {
                        v->id = lit->second;
                        return;
                    }
                }
                if (!cls.empty()) {
                    auto cit = class_vars_.find(cls);
                    if (cit != class_vars_.end()) {
                        auto cvit = cit->second.find(v->name);
                        if (cvit != cit->second.end()) {
                            v->is_field = true;
                            v->id = 0;
                            v->field_id = cvit->second;
                            return;
                        }
                    }
                }
                v->id = lookup_var(v->name, cls, locals);
                return;
            }

            if (v->class_name == "self") {
                if (cls.empty()) {
                    throw std::runtime_error(
                        "'self' can only be used inside a class method");
                }
                v->is_field = true;
                v->id = 0;

                auto cit = class_vars_.find(cls);
                if (cit == class_vars_.end() ||
                    cit->second.find(v->name) == cit->second.end()) {
                    throw std::runtime_error(
                        "Class '" + cls + "' has no field '" + v->name + "'");
                }
                v->field_id = cit->second[v->name];
                return;
            }

            uint32_t var_id = 0;
            bool found = false;

            if (locals) {
                auto lit = locals->find(v->class_name);
                if (lit != locals->end()) { var_id = lit->second; found = true; }
            }
            if (!found) {
                auto git = global_vars_.find(v->class_name);
                if (git != global_vars_.end()) { var_id = git->second; found = true; }
            }
            if (!found && !cls.empty()) {
                auto cit = class_vars_.find(cls);
                if (cit != class_vars_.end()) {
                    auto cvit = cit->second.find(v->class_name);
                    if (cvit != cit->second.end()) { var_id = cvit->second; found = true; }
                }
            }

            if (found) {
                auto vit = vars_.find(var_id);

                if (vit != vars_.end() && vit->second.is_class_object) {
                    v->is_field = true;
                    v->id = var_id;

                    uint32_t class_id = vit->second.object_class_id;
                    const std::string* class_name = nullptr;
                    for (auto& [cn, cid] : classes_) {
                        if (cid == class_id) { class_name = &cn; break; }
                    }
                    if (!class_name) {
                        throw std::runtime_error(
                            "Internal: object class id " + std::to_string(class_id) +
                            " not found");
                    }
                    auto cvit = class_vars_.find(*class_name);
                    if (cvit == class_vars_.end() ||
                        cvit->second.find(v->name) == cvit->second.end()) {
                        throw std::runtime_error(
                            "Class '" + *class_name + "' has no field '" + v->name + "'");
                    }
                    v->field_id = cvit->second[v->name];
                    return;
                }
            }

            v->id = lookup_var(v->name, v->class_name, nullptr);
            return;
        }
        if (auto* t = dynamic_cast<TernaryExpr*>(e)) {
            resolve_in_expr(t->cond.get(), cls, locals);
            resolve_in_expr(t->then_expr.get(), cls, locals);
            resolve_in_expr(t->else_expr.get(), cls, locals);
            return;
        }
        if (auto* b = dynamic_cast<BinaryExpr*>(e)) {
            resolve_in_expr(b->lhs.get(), cls, locals);
            resolve_in_expr(b->rhs.get(), cls, locals);
            return;
        }
        if (auto* u = dynamic_cast<UnaryExpr*>(e)) {
            resolve_in_expr(u->operand.get(), cls, locals);
            return;
        }
        if (auto* c = dynamic_cast<CallExpr*>(e)) {
            if (c->class_name == "thread") {
                c->is_builtin = true;
                c->builtin_name = c->name;

                if (c->name == "run") {
                    if (c->args.size() >= 2) {
                        resolve_in_expr(c->args[1].get(), cls, locals);
                    }
                }
                else {
                    for (auto& a : c->args) resolve_in_expr(a.get(), cls, locals);
                }
                return;
            }

            for (auto& a : c->args) resolve_in_expr(a.get(), cls, locals);

            if (c->class_name.empty() && c->name == "len") {
                if (c->args.size() != 1) {
                    throw std::runtime_error("len() takes exactly 1 argument");
                }
                c->is_builtin = true;
                c->builtin_name = "len";
                return;
            }

            if (!c->class_name.empty() && used_libs_set_.count(c->class_name)) {
                c->is_native = true;
                return;
            }

            if (!cls.empty()) {
                auto cit = class_vars_.find(cls);
                if (cit != class_vars_.end()) {
                    auto cvit = cit->second.find(c->class_name);
                    if (cvit != cit->second.end()) {
                        uint32_t fid = cvit->second;
                        auto fit = vars_.find(fid);
                        if (fit != vars_.end() && fit->second.is_class_object) {
                            c->is_method = true;
                            c->is_field_method = true;
                            c->obj_var_id = 0;
                            c->field_id = fid;

                            if (c->name == "free") {
                                c->is_free_method = true;
                                return;
                            }

                            uint32_t class_id = fit->second.object_class_id;
                            const std::string* fclass = nullptr;
                            for (auto& [cn, cid] : classes_) {
                                if (cid == class_id) { fclass = &cn; break; }
                            }
                            if (!fclass) {
                                throw std::runtime_error(
                                    "Internal: object class id not found for field '" +
                                    c->class_name + "'");
                            }
                            auto fvit = class_funs_.find(*fclass);
                            if (fvit == class_funs_.end() ||
                                fvit->second.find(c->name) == fvit->second.end()) {
                                throw std::runtime_error(
                                    "Class '" + *fclass + "' has no method '" + c->name + "'");
                            }
                            c->id = fvit->second[c->name];
                            return;
                        }
                    }
                }
            }

            if (c->class_name == "self") {
                if (cls.empty()) {
                    throw std::runtime_error(
                        "'self' can only be used inside a class method");
                }
                c->is_method = true;
                c->obj_var_id = 0;

                if (c->name == "free") {
                    c->is_free_method = true;
                    return;
                }

                auto fvit = class_funs_.find(cls);
                if (fvit == class_funs_.end() ||
                    fvit->second.find(c->name) == fvit->second.end()) {
                    throw std::runtime_error(
                        "Class '" + cls + "' has no method '" + c->name + "'");
                }
                c->id = fvit->second[c->name];
                return;
            }

            if (c->class_name.empty()) {
                auto cit = classes_.find(c->name);
                if (cit != classes_.end()) {
                    c->is_new_object = true;
                    c->id = cit->second;

                    if (!c->args.empty()) {
                        auto fvit = class_funs_.find(c->name);
                        if (fvit == class_funs_.end()) {
                            throw std::runtime_error(
                                "Constructor with arguments requires 'init' method in class '" +
                                c->name + "'");
                        }
                        auto iit = fvit->second.find("init");
                        if (iit == fvit->second.end()) {
                            throw std::runtime_error(
                                "Class '" + c->name + "' has no 'init' method");
                        }
                        c->init_id = iit->second;
                    }
                    return;
                }

                if (!cls.empty()) {
                    auto fvit = class_funs_.find(cls);
                    if (fvit != class_funs_.end()) {
                        auto it = fvit->second.find(c->name);
                        if (it != fvit->second.end()) {
                            c->is_method = true;
                            c->obj_var_id = 0;
                            c->id = it->second;
                            return;
                        }
                    }
                }

                c->id = lookup_fun(c->name, cls);
                return;
            }

            uint32_t var_id = 0;
            bool found = false;
            if (locals) {
                auto lit = locals->find(c->class_name);
                if (lit != locals->end()) { var_id = lit->second; found = true; }
            }
            if (!found) {
                auto git = global_vars_.find(c->class_name);
                if (git != global_vars_.end()) { var_id = git->second; found = true; }
            }
            if (!found && !cls.empty()) {
                auto cit = class_vars_.find(cls);
                if (cit != class_vars_.end()) {
                    auto cvit = cit->second.find(c->class_name);
                    if (cvit != cit->second.end()) { var_id = cvit->second; found = true; }
                }
            }

            if (found) {
                auto vit = vars_.find(var_id);
                if (vit != vars_.end() &&
                    (vit->second.type == DataType::LIST ||
                        vit->second.type == DataType::ARRAY ||
                        vit->second.type == DataType::DICT ||
                        vit->second.type == DataType::AUTO)) {
                    const std::string& mn = c->name;
                    if (mn == "push" || mn == "pop" || mn == "insert" ||
                        mn == "remove" || mn == "clear" || mn == "len" ||
                        mn == "has" || mn == "keys" || mn == "values" ||
                        mn == "fill") {
                        c->is_builtin = true;
                        c->builtin_name = mn;
                        c->obj_var_id = var_id;
                        return;
                    }
                }
                if (vit != vars_.end() && vit->second.is_class_object) {
                    c->is_method = true;
                    c->obj_var_id = var_id;

                    if (c->name == "free") {
                        c->is_free_method = true;
                        return;
                    }

                    uint32_t class_id = vit->second.object_class_id;
                    const std::string* class_name = nullptr;
                    for (auto& [cn, cid] : classes_) {
                        if (cid == class_id) { class_name = &cn; break; }
                    }
                    if (!class_name) {
                        throw std::runtime_error(
                            "Internal: object class id not found for '" + c->class_name + "'");
                    }
                    auto fvit = class_funs_.find(*class_name);
                    if (fvit == class_funs_.end() ||
                        fvit->second.find(c->name) == fvit->second.end()) {
                        throw std::runtime_error(
                            "Class '" + *class_name + "' has no method '" + c->name + "'");
                    }
                    c->id = fvit->second[c->name];
                    return;
                }
            }

            c->id = lookup_fun(c->name, c->class_name);
            return;
        }
    }

    void Codegen::resolve_in_stmt(Stmt* s, const std::string& cls,
        std::unordered_map<std::string, uint32_t>* locals) {
        if (dynamic_cast<BreakStmt*>(s) || dynamic_cast<ContinueStmt*>(s)) return;
        if (auto* v = dynamic_cast<VarDeclStmt*>(s)) {
            if (v->init) resolve_in_expr(v->init.get(), cls, locals);
            return;
        }
        if (auto* a = dynamic_cast<AssignStmt*>(s)) {
            if (!a->class_name.empty()) {
                if (a->class_name == "self") {
                    if (cls.empty()) {
                        throw std::runtime_error(
                            "'self' can only be used inside a class method");
                    }
                    a->is_field = true;
                    a->obj_var_id = 0;

                    auto cit = class_vars_.find(cls);
                    if (cit == class_vars_.end() ||
                        cit->second.find(a->name) == cit->second.end()) {
                        throw std::runtime_error(
                            "Class '" + cls + "' has no field '" + a->name + "'");
                    }
                    a->field_id = cit->second[a->name];
                    resolve_in_expr(a->value.get(), cls, locals);
                    return;
                }

                uint32_t var_id = 0;
                bool found = false;
                if (locals) {
                    auto lit = locals->find(a->class_name);
                    if (lit != locals->end()) { var_id = lit->second; found = true; }
                }
                if (!found) {
                    auto git = global_vars_.find(a->class_name);
                    if (git != global_vars_.end()) { var_id = git->second; found = true; }
                }
                if (!found && !cls.empty()) {
                    auto cit = class_vars_.find(cls);
                    if (cit != class_vars_.end()) {
                        auto cvit = cit->second.find(a->class_name);
                        if (cvit != cit->second.end()) { var_id = cvit->second; found = true; }
                    }
                }
                if (found) {
                    auto vit = vars_.find(var_id);
                    if (vit != vars_.end() && vit->second.is_class_object) {
                        a->is_field = true;
                        a->obj_var_id = var_id;

                        uint32_t class_id = vit->second.object_class_id;
                        const std::string* class_name = nullptr;
                        for (auto& [cn, cid] : classes_) {
                            if (cid == class_id) { class_name = &cn; break; }
                        }
                        if (!class_name) {
                            throw std::runtime_error(
                                "Internal: object class id not found for '" + a->class_name + "'");
                        }
                        auto cvit = class_vars_.find(*class_name);
                        if (cvit == class_vars_.end() ||
                            cvit->second.find(a->name) == cvit->second.end()) {
                            throw std::runtime_error(
                                "Class '" + *class_name + "' has no field '" + a->name + "'");
                        }
                        a->field_id = cvit->second[a->name];
                        resolve_in_expr(a->value.get(), cls, locals);
                        return;
                    }
                }
            }

            if (!cls.empty()) {
                bool is_local = false;
                if (locals) {
                    is_local = locals->count(a->name) > 0;
                }
                if (!is_local) {
                    auto cit = class_vars_.find(cls);
                    if (cit != class_vars_.end()) {
                        auto cvit = cit->second.find(a->name);
                        if (cvit != cit->second.end()) {
                            a->is_field = true;
                            a->obj_var_id = 0;
                            a->field_id = cvit->second;
                            resolve_in_expr(a->value.get(), cls, locals);
                            return;
                        }
                    }
                }
            }

            a->id = lookup_var(a->name,
                a->class_name.empty() ? cls : a->class_name,
                a->class_name.empty() ? locals : nullptr);
            resolve_in_expr(a->value.get(), cls, locals);
            return;
        }
        if (auto* e = dynamic_cast<ExprStmt*>(s)) {
            resolve_in_expr(e->expr.get(), cls, locals);
            return;
        }
        if (auto* r = dynamic_cast<ReturnStmt*>(s)) {
            if (r->value) resolve_in_expr(r->value.get(), cls, locals);
            return;
        }
        if (auto* i = dynamic_cast<IfStmt*>(s)) {
            resolve_in_expr(i->cond.get(), cls, locals);
            for (auto& b : i->then_body)
                resolve_in_stmt(b.get(), cls, &i->then_scope);
            for (auto& b : i->else_body)
                resolve_in_stmt(b.get(), cls, &i->else_scope);
            return;
        }
        if (auto* w = dynamic_cast<WhileStmt*>(s)) {
            resolve_in_expr(w->cond.get(), cls, locals);
            for (auto& b : w->body)
                resolve_in_stmt(b.get(), cls, &w->body_scope);
            return;
        }
        if (auto* f = dynamic_cast<ForStmt*>(s)) {
            if (f->init) resolve_in_stmt(f->init.get(), cls, &f->for_scope);
            if (f->cond) resolve_in_expr(f->cond.get(), cls, &f->for_scope);
            if (f->step) resolve_in_stmt(f->step.get(), cls, &f->for_scope);
            for (auto& b : f->body)
                resolve_in_stmt(b.get(), cls, &f->body_scope);
            return;
        }
        if (dynamic_cast<FunDecl*>(s) || dynamic_cast<ClassDecl*>(s)) {
            return;
        }
        if (auto* sw = dynamic_cast<SwitchStmt*>(s)) {
            resolve_in_expr(sw->expr.get(), cls, locals);
            for (auto& c : sw->cases) {
                resolve_in_expr(c.value.get(), cls, locals);
                for (auto& b : c.body) resolve_in_stmt(b.get(), cls, &sw->body_scope);
            }
            for (auto& b : sw->default_body) resolve_in_stmt(b.get(), cls, &sw->body_scope);
            return;
        }
        if (auto* t = dynamic_cast<TryStmt*>(s)) {
            for (auto& b : t->try_body)
                resolve_in_stmt(b.get(), cls, &t->try_scope);
            for (auto& b : t->catch_body)
                resolve_in_stmt(b.get(), cls, &t->catch_scope);
            for (auto& b : t->finally_body)
                resolve_in_stmt(b.get(), cls, &t->finally_scope);
            return;
        }

        if (auto* t = dynamic_cast<ThrowStmt*>(s)) {
            if (t->value) resolve_in_expr(t->value.get(), cls, locals);
            return;
        }

        if (auto* ai = dynamic_cast<AssignIndexStmt*>(s)) {
            resolve_in_expr(ai->container.get(), cls, locals);
            resolve_in_expr(ai->index.get(), cls, locals);
            resolve_in_expr(ai->value.get(), cls, locals);
            return;
        }

        throw std::runtime_error("Unknown err on SRSIS");
    }

    uint32_t Codegen::lookup_var(const std::string& name, const std::string& cls,
        const std::unordered_map<std::string, uint32_t>* locals) {
        if (locals) {
            auto it = locals->find(name);
            if (it != locals->end()) return it->second;
        }
        if (!cls.empty()) {
            auto cit = class_vars_.find(cls);
            if (cit != class_vars_.end()) {
                auto it = cit->second.find(name);
                if (it != cit->second.end()) return it->second;
            }
        }
        auto git = global_vars_.find(name);
        if (git != global_vars_.end()) return git->second;
        throw std::runtime_error("Unknown variable '" + name + "'");
    }

    uint32_t Codegen::lookup_fun(const std::string& name, const std::string& cls) {
        if (!cls.empty()) {
            auto cit = class_funs_.find(cls);
            if (cit != class_funs_.end()) {
                auto it = cit->second.find(name);
                if (it != cit->second.end()) return it->second;
            }
        }
        auto it = functions_.find(name);
        if (it != functions_.end()) return it->second;
        throw std::runtime_error("Unknown function '" + name + "'");
    }

    static void scan_init_for_int(VarDeclStmt* v, std::unordered_map<uint32_t, int64_t>& maxvals) {
        if (!v->init) return;
        if (auto* lit = dynamic_cast<LiteralExpr*>(v->init.get())) {
            if (lit->type == DataType::INT) {
                int64_t a = lit->int_val < 0 ? -lit->int_val : lit->int_val;
                auto it = maxvals.find(v->id);
                if (it == maxvals.end() || a > it->second) maxvals[v->id] = a;
            }
        }
    }

    static void scan_assign(AssignStmt* a, std::unordered_map<uint32_t, int64_t>& maxvals) {
        if (!a->value) return;
        if (auto* lit = dynamic_cast<LiteralExpr*>(a->value.get())) {
            if (lit->type == DataType::INT) {
                int64_t v = lit->int_val < 0 ? -lit->int_val : lit->int_val;
                auto it = maxvals.find(a->id);
                if (it == maxvals.end() || v > it->second) maxvals[a->id] = v;
            }
        }
    }

    static void scan_stmt_for_int(Stmt* s, std::unordered_map<uint32_t, int64_t>& maxvals) {
        if (auto* v = dynamic_cast<VarDeclStmt*>(s)) { scan_init_for_int(v, maxvals); return; }
        if (auto* a = dynamic_cast<AssignStmt*>(s)) { scan_assign(a, maxvals); return; }
        if (dynamic_cast<AssignIndexStmt*>(s)) return;
        if (auto* i = dynamic_cast<IfStmt*>(s)) {
            for (auto& b : i->then_body) scan_stmt_for_int(b.get(), maxvals);
            for (auto& b : i->else_body) scan_stmt_for_int(b.get(), maxvals);
            return;
        }
        if (auto* w = dynamic_cast<WhileStmt*>(s)) {
            for (auto& b : w->body) scan_stmt_for_int(b.get(), maxvals);
            return;
        }
        if (auto* f = dynamic_cast<FunDecl*>(s)) {
            for (auto& b : f->body) scan_stmt_for_int(b.get(), maxvals);
            return;
        }
        if (auto* c = dynamic_cast<ClassDecl*>(s)) {
            for (auto& m : c->members) scan_stmt_for_int(m.get(), maxvals);
            return;
        }
    }

    void Codegen::resolve_int_sizes() {
        for (auto& [id, fi] : funs_) {
            if (fi.ret_type == DataType::INT) {
                fi.ret_type = DataType::INT64;
                if (fi.ast) fi.ast->return_type = DataType::INT64;
            }
            if (fi.ast) {
                for (auto& a : fi.ast->args) {
                    if (a.type == DataType::INT) {
                        a.type = DataType::INT64;
                        auto vit = vars_.find(a.id);
                        if (vit != vars_.end()) {
                            vit->second.type = DataType::INT64;
                            vit->second.size = 8;
                        }
                    }
                }
            }
        }

        std::unordered_map<uint32_t, int64_t> maxvals;
        for (auto& s : prog_->statements) scan_stmt_for_int(s.get(), maxvals);

        for (auto& [id, info] : vars_) {
            if (info.type != DataType::INT) continue;
            auto it = maxvals.find(id);
            int64_t v = (it != maxvals.end()) ? it->second : 0;
            bool has_nonliteral_init = (info.global && it == maxvals.end() && v == 0);
            DataType chosen = has_nonliteral_init ? DataType::INT64 : smallest_int_for(v);
            info.type = chosen;
            info.size = int_type_size(chosen);
        }

        for (auto& [fid, fi] : funs_) {
            for (auto& lv : fi.locals) {
                auto it = vars_.find(lv.id);
                if (it != vars_.end()) {
                    lv.type = it->second.type;
                }
            }
        }
    }

    DataType Codegen::infer_type(Expr* e, const std::string& cls,
        const std::unordered_map<std::string, uint32_t>* locals) {
        (void)cls; (void)locals;
        if (!e) throw std::runtime_error("infer_type: null expression");

        if (auto* li = dynamic_cast<ListLitExpr*>(e)) {
            return DataType::LIST;
        }
        if (auto* de = dynamic_cast<DictLitExpr*>(e)) {
            return DataType::DICT;
        }
        if (auto* ie = dynamic_cast<IndexExpr*>(e)) {
            (void)ie;
            return DataType::AUTO;
        }

        if (auto* lit = dynamic_cast<LiteralExpr*>(e)) {
            return lit->type;
        }

        if (auto* t = dynamic_cast<TernaryExpr*>(e)) {
            DataType tt = infer_type(t->then_expr.get(), cls, locals);
            DataType et = infer_type(t->else_expr.get(), cls, locals);
            if (tt == et) return tt;
            if (is_numeric(tt) && is_numeric(et)) return wider_numeric(tt, et);
            return DataType::AUTO;
        }

        if (auto* v = dynamic_cast<VarExpr*>(e)) {
            if (v->is_field) {
                auto fit = vars_.find(v->field_id);
                if (fit == vars_.end())
                    throw std::runtime_error("Internal: unknown field id " +
                        std::to_string(v->field_id));
                return fit->second.type;
            }
            if (v->id == 0)
                throw std::runtime_error("Internal: unresolved variable '" + v->name + "'");
            auto it = vars_.find(v->id);
            if (it == vars_.end())
                throw std::runtime_error("Internal: unknown var id " + std::to_string(v->id));
            return it->second.type;
        }

        if (auto* u = dynamic_cast<UnaryExpr*>(e)) {
            DataType t = infer_type(u->operand.get(), cls, locals);
            if (u->op == "-") {
                if (!is_numeric(t))
                    throw std::runtime_error("Unary '-' requires numeric, got " + type_name(t));
                return t;
            }
            if (u->op == "!") {
                if (!is_boolish(t))
                    throw std::runtime_error("Unary '!' requires bool, got " + type_name(t));
                return DataType::BOOL;
            }
            throw std::runtime_error("Unknown unary op '" + u->op + "'");
        }

        if (auto* b = dynamic_cast<BinaryExpr*>(e)) {
            DataType lt = infer_type(b->lhs.get(), cls, locals);
            DataType rt = infer_type(b->rhs.get(), cls, locals);
            const std::string& op = b->op;

            if (op == "+") {
                if (lt == DataType::AUTO || rt == DataType::AUTO)
                    return DataType::AUTO;
                if (lt == DataType::STR && rt == DataType::STR) return DataType::STR;
                if (lt == DataType::STR || rt == DataType::STR) return DataType::STR;
                if (is_numeric(lt) && is_numeric(rt)) return wider_numeric(lt, rt);
                throw std::runtime_error("'+' requires both numeric or both str, got " +
                    type_name(lt) + " and " + type_name(rt));
            }
            if (op == "-" || op == "*" || op == "/" || op == "%") {
                if (lt == DataType::AUTO || rt == DataType::AUTO)
                    return DataType::AUTO;
                if (!is_numeric(lt) || !is_numeric(rt))
                    throw std::runtime_error("'" + op + "' requires numeric operands, got " +
                        type_name(lt) + " and " + type_name(rt));
                return wider_numeric(lt, rt);
            }
            if (op == "<" || op == ">" || op == "<=" || op == ">=") {
                if (lt == DataType::AUTO || rt == DataType::AUTO)
                    return DataType::BOOL;
                bool ok = (is_numeric(lt) && is_numeric(rt)) ||
                    (lt == DataType::STR && rt == DataType::STR);
                if (!ok)
                    throw std::runtime_error("'" + op + "' requires both numeric or both str, got " +
                        type_name(lt) + " and " + type_name(rt));
                return DataType::BOOL;
            }
            if (op == "==" || op == "!=") {
                if (lt == DataType::AUTO || rt == DataType::AUTO)
                    return DataType::BOOL;
                if (is_numeric(lt) && is_numeric(rt)) return DataType::BOOL;
                if (lt == rt) return DataType::BOOL;
                if (lt == DataType::NULL_ || rt == DataType::NULL_) return DataType::BOOL;
                throw std::runtime_error("'" + op + "' requires matching types, got " +
                    type_name(lt) + " and " + type_name(rt));
            }
            if (op == "&&" || op == "||") {
                if (lt == DataType::AUTO || rt == DataType::AUTO)
                    return DataType::BOOL;
                if (!is_boolish(lt) || !is_boolish(rt))
                    throw std::runtime_error("'" + op + "' requires bool operands, got " +
                        type_name(lt) + " and " + type_name(rt));
                return DataType::BOOL;
            }
            throw std::runtime_error("Unknown binary op '" + op + "'");
        }

        if (auto* c = dynamic_cast<CallExpr*>(e)) {
            if (c->is_builtin) {
                if (c->builtin_name == "len")   return DataType::INT64;
                if (c->builtin_name == "has")   return DataType::BOOL;
                if (c->builtin_name == "keys")  return DataType::LIST;
                if (c->builtin_name == "values") return DataType::LIST;
                if (c->builtin_name == "pop")   return DataType::AUTO;
                return DataType::NULL_;
            }
            if (c->is_native) {
                return DataType::AUTO;
            }

            if (c->is_new_object) {
                return DataType::OBJECT;
            }

            if (c->is_free_method) return DataType::NULL_;

            auto it = funs_.find(c->id);
            if (it == funs_.end())
                throw std::runtime_error("Internal: unknown function/method id " +
                    std::to_string(c->id));
            const FunInfo& fn = it->second;

            if (c->args.size() != fn.params.size()) {
                const char* kind = c->is_method ? "Method" : "Function";
                throw std::runtime_error(std::string(kind) + " '" + fn.name + "' expects " +
                    std::to_string(fn.params.size()) + " arg(s), got " +
                    std::to_string(c->args.size()));
            }
            for (size_t i = 0; i < c->args.size(); ++i) {
                DataType at = infer_type(c->args[i].get(), cls, locals);
                if (!types_assignable(fn.params[i].type, at)) {
                    throw std::runtime_error("Argument " + std::to_string(i + 1) +
                        " of '" + fn.name + "': expected " + type_name(fn.params[i].type) +
                        ", got " + type_name(at));
                }
            }
            return fn.ret_type;
        }

        throw std::runtime_error("Internal: unknown expression node in typecheck");
    }

    void Codegen::check_stmt(Stmt* s, const std::string& cls,
        const std::unordered_map<std::string, uint32_t>* locals,
        DataType current_ret_type) {

        if (auto* v = dynamic_cast<VarDeclStmt*>(s)) {
            DataType var_t = vars_[v->id].type;
            if (var_t == DataType::AUTO) return;
            if (v->init) {
                DataType expr_t = infer_type(v->init.get(), cls, locals);
                if (!types_assignable(var_t, expr_t)) {
                    throw std::runtime_error("Cannot assign " + type_name(expr_t) +
                        " to variable '" + v->name + "' of type " + type_name(var_t));
                }
            }
            return;
        }

        if (auto* a = dynamic_cast<AssignStmt*>(s)) {
            if (a->is_field) {
                auto fit = vars_.find(a->field_id);
                if (fit == vars_.end()) {
                    throw std::runtime_error("Internal: unknown field id " +
                        std::to_string(a->field_id));
                }
                DataType field_t = fit->second.type;
                DataType expr_t = infer_type(a->value.get(), cls, locals);
                if (!types_assignable(field_t, expr_t)) {
                    throw std::runtime_error("Cannot assign " + type_name(expr_t) +
                        " to field '" + a->name + "' of type " + type_name(field_t));
                }
                return;
            }

            DataType var_t = vars_[a->id].type;
            if (var_t == DataType::AUTO) return;
            DataType expr_t = infer_type(a->value.get(), cls, locals);
            if (!types_assignable(var_t, expr_t)) {
                throw std::runtime_error("Cannot assign " + type_name(expr_t) +
                    " to variable '" + a->name + "' of type " + type_name(var_t));
            }
            return;
        }

        if (auto* e = dynamic_cast<ExprStmt*>(s)) {
            infer_type(e->expr.get(), cls, locals);
            return;
        }

        if (auto* r = dynamic_cast<ReturnStmt*>(s)) {
            if (current_ret_type == DataType::AUTO) return;
            DataType expr_t = r->value
                ? infer_type(r->value.get(), cls, locals)
                : DataType::NULL_;
            if (current_ret_type != DataType::NULL_ &&
                !types_assignable(current_ret_type, expr_t)) {
                throw std::runtime_error("Return type mismatch: function returns " +
                    type_name(current_ret_type) + ", but got " + type_name(expr_t));
            }
            return;
        }

        if (auto* i = dynamic_cast<IfStmt*>(s)) {
            DataType t = infer_type(i->cond.get(), cls, locals);
            if (!is_boolish(t))
                throw std::runtime_error("if condition must be bool, got " + type_name(t));
            for (auto& b : i->then_body)
                check_stmt(b.get(), cls, &i->then_scope, current_ret_type);
            for (auto& b : i->else_body)
                check_stmt(b.get(), cls, &i->else_scope, current_ret_type);
            return;
        }

        if (auto* w = dynamic_cast<WhileStmt*>(s)) {
            DataType t = infer_type(w->cond.get(), cls, locals);
            if (!is_boolish(t))
                throw std::runtime_error("while condition must be bool, got " + type_name(t));
            for (auto& b : w->body)
                check_stmt(b.get(), cls, &w->body_scope, current_ret_type);
            return;
        }

        if (auto* f = dynamic_cast<ForStmt*>(s)) {
            if (f->init) check_stmt(f->init.get(), cls, &f->for_scope, current_ret_type);
            if (f->cond) {
                DataType t = infer_type(f->cond.get(), cls, &f->for_scope);
                if (t != DataType::AUTO && !is_boolish(t))
                    throw std::runtime_error("for condition must be bool, got " + type_name(t));
            }
            if (f->step) check_stmt(f->step.get(), cls, &f->for_scope, current_ret_type);
            for (auto& b : f->body)
                check_stmt(b.get(), cls, &f->body_scope, current_ret_type);
            return;
        }

        if (auto* sw = dynamic_cast<SwitchStmt*>(s)) {
            infer_type(sw->expr.get(), cls, locals);
            for (auto& c : sw->cases) {
                infer_type(c.value.get(), cls, locals);
                for (auto& b : c.body) {
                    check_stmt(b.get(), cls, &sw->body_scope, current_ret_type);
                }
            }
            for (auto& b : sw->default_body) {
                check_stmt(b.get(), cls, &sw->body_scope, current_ret_type);
            }
            return;
        }
        if (auto* t = dynamic_cast<TryStmt*>(s)) {
            for (auto& b : t->try_body)
                check_stmt(b.get(), cls, &t->try_scope, current_ret_type);
            for (auto& b : t->catch_body)
                check_stmt(b.get(), cls, &t->catch_scope, current_ret_type);
            for (auto& b : t->finally_body)
                check_stmt(b.get(), cls, &t->finally_scope, current_ret_type);
            return;
        }

        if (dynamic_cast<BreakStmt*>(s) || dynamic_cast<ContinueStmt*>(s)) return;

        if (auto* t = dynamic_cast<ThrowStmt*>(s)) {
            if (t->value) infer_type(t->value.get(), cls, locals);
            return;
        }

        if (auto* ai = dynamic_cast<AssignIndexStmt*>(s)) {
            infer_type(ai->container.get(), cls, locals);
            infer_type(ai->index.get(), cls, locals);
            infer_type(ai->value.get(), cls, locals);
            return;
        }

        throw std::runtime_error("Err on CHK_STMT");
    }

    void Codegen::pass3_typecheck() {
        std::unordered_map<std::string, uint32_t> empty;
        for (auto& stmt : prog_->statements) {
            if (dynamic_cast<FunDecl*>(stmt.get()))   continue;
            if (dynamic_cast<ClassDecl*>(stmt.get())) continue;
            check_stmt(stmt.get(), "", &empty, DataType::NULL_);
        }

        for (auto& stmt : prog_->statements) {
            if (auto* f = dynamic_cast<FunDecl*>(stmt.get())) {
                auto& locals = fun_locals_[f];
                DataType ret = funs_[f->id].ret_type;
                for (auto& body : f->body)
                    check_stmt(body.get(), "", &locals, ret);
            }
        }

        for (auto& stmt : prog_->statements) {
            if (auto* c = dynamic_cast<ClassDecl*>(stmt.get())) {
                for (auto& m : c->members) {
                    if (auto* fm = dynamic_cast<FunDecl*>(m.get())) {
                        auto& locals = fun_locals_[fm];
                        DataType ret = funs_[fm->id].ret_type;
                        for (auto& body : fm->body)
                            check_stmt(body.get(), c->name, &locals, ret);
                    }
                }
            }
        }
    }

    void Codegen::patch_u32(size_t pos, uint32_t val) {
        out_[pos + 0] = (val) & 0xFF;
        out_[pos + 1] = (val >> 8) & 0xFF;
        out_[pos + 2] = (val >> 16) & 0xFF;
        out_[pos + 3] = (val >> 24) & 0xFF;
    }

    void Codegen::emit_expr(Expr* e, const std::string& cls,
        const std::unordered_map<std::string, uint32_t>* locals) {
        static bool printed = false;
        if (!printed) {
            printed = true;
            std::runtime_error("[MARKER] emit_expr THREAD_FIRST v3\n");
        }
        (void)cls; (void)locals;

        if (auto* li = dynamic_cast<ListLitExpr*>(e)) {
            push_u8((uint8_t)Op::NEW_LIST);
            for (auto& it : li->items) {
                push_u8((uint8_t)Op::DUP);
                emit_expr(it.get(), cls, locals);
                push_u8((uint8_t)Op::PUSH_ITEM);
            }
            return;
        }
        if (auto* di = dynamic_cast<DictLitExpr*>(e)) {
            push_u8((uint8_t)Op::NEW_DICT);
            for (auto& [k, v] : di->entries) {
                push_u8((uint8_t)Op::DUP);
                push_u8((uint8_t)Op::PUSH);
                push_u8((uint8_t)DataType::STR);
                push_u32((uint32_t)k.size());
                push_str(k);
                emit_expr(v.get(), cls, locals);
                push_u8((uint8_t)Op::INDEX_SET);
            }
            return;
        }
        if (auto* ie = dynamic_cast<IndexExpr*>(e)) {
            emit_expr(ie->container.get(), cls, locals);
            emit_expr(ie->index.get(), cls, locals);
            push_u8((uint8_t)Op::INDEX_GET);
            return;
        }

        if (auto* t = dynamic_cast<TernaryExpr*>(e)) {

            emit_expr(t->cond.get(), cls, locals);

            push_u8((uint8_t)Op::JZ);
            size_t jz_pos = out_.size();
            push_u32(0);

            emit_expr(t->then_expr.get(), cls, locals);

            push_u8((uint8_t)Op::JMP);
            size_t jmp_pos = out_.size();
            push_u32(0);

            patch_u32(jz_pos, (uint32_t)out_.size());

            emit_expr(t->else_expr.get(), cls, locals);

            patch_u32(jmp_pos, (uint32_t)out_.size());
            return;
        }

        if (auto* lit = dynamic_cast<LiteralExpr*>(e)) {
            if (lit->type == DataType::INT) {
                DataType t = smallest_int_for(lit->int_val);
                push_u8((uint8_t)Op::PUSH);
                push_u8((uint8_t)t);
                switch (t) {
                case DataType::INT8:  push_u8((uint8_t)lit->int_val); break;
                case DataType::INT16: push_u16((uint16_t)lit->int_val); break;
                case DataType::INT32: push_u32((uint32_t)lit->int_val); break;
                default:              push_u64((uint64_t)lit->int_val); break;
                }
                return;
            }
            if (lit->type == DataType::FLOAT) {
                push_u8((uint8_t)Op::PUSH);
                push_u8((uint8_t)DataType::FLOAT);
                uint64_t bits; std::memcpy(&bits, &lit->float_val, 8);
                push_u64(bits);
                return;
            }
            if (lit->type == DataType::STR) {
                push_u8((uint8_t)Op::PUSH);
                push_u8((uint8_t)DataType::STR);
                push_u32((uint32_t)lit->str_val.size());
                push_str(lit->str_val);
                return;
            }
            if (lit->type == DataType::BOOL) {
                push_u8((uint8_t)Op::PUSH);
                push_u8((uint8_t)DataType::BOOL);
                push_u8(lit->bool_val ? 1 : 0);
                return;
            }
            if (lit->type == DataType::NULL_) {
                push_u8((uint8_t)Op::PUSH);
                push_u8((uint8_t)DataType::NULL_);
                return;
            }
            if (lit->type == DataType::HEX || lit->type == DataType::BIN) {
                std::vector<uint8_t> bytes;
                if (lit->type == DataType::HEX) {
                    std::string s = lit->str_val;
                    if (s.size() % 2) s = "0" + s;
                    for (size_t i = 0; i < s.size(); i += 2) {
                        auto hv = [](char c) -> int {
                            if (c >= '0' && c <= '9') return c - '0';
                            if (c >= 'a' && c <= 'f') return c - 'a' + 10;
                            if (c >= 'A' && c <= 'F') return c - 'A' + 10;
                            return 0;
                            };
                        bytes.push_back((uint8_t)((hv(s[i]) << 4) | hv(s[i + 1])));
                    }
                }
                else {
                    std::string s = lit->str_val;
                    for (size_t i = 0; i < s.size(); i += 8) {
                        uint8_t b = 0;
                        for (size_t j = 0; j < 8 && i + j < s.size(); ++j) {
                            if (s[i + j] == '1') b |= (1 << (7 - j));
                        }
                        bytes.push_back(b);
                    }
                }
                push_u8((uint8_t)Op::PUSH);
                push_u8((uint8_t)lit->type);
                push_u32((uint32_t)bytes.size());
                out_.insert(out_.end(), bytes.begin(), bytes.end());
                return;
            }
            throw std::runtime_error("Unsupported literal type");
        }

        if (auto* v = dynamic_cast<VarExpr*>(e)) {
            if (v->is_field) {
                push_u8((uint8_t)Op::LOAD_VAR);
                push_u32(v->id);
                push_u8((uint8_t)Op::LOAD_FIELD);
                push_u32(v->field_id);
                return;
            }
            push_u8((uint8_t)Op::LOAD_VAR);
            push_u32(v->id);
            return;
        }

        if (auto* u = dynamic_cast<UnaryExpr*>(e)) {
            if (opt_level_ >= 1) {
                if (auto* lit = dynamic_cast<LiteralExpr*>(u->operand.get())) {
                    if (u->op == "-") {
                        if (lit->type == DataType::FLOAT) {
                            double r = -lit->float_val;
                            push_u8((uint8_t)Op::PUSH);
                            push_u8((uint8_t)DataType::FLOAT);
                            uint64_t bits; std::memcpy(&bits, &r, 8);
                            push_u64(bits);
                            return;
                        }
                        if (is_numeric(lit->type)) {
                            int64_t r = -lit->int_val;
                            DataType t = smallest_int_for(r);
                            push_u8((uint8_t)Op::PUSH);
                            push_u8((uint8_t)t);
                            switch (t) {
                            case DataType::INT8:  push_u8((uint8_t)r); break;
                            case DataType::INT16: push_u16((uint16_t)r); break;
                            case DataType::INT32: push_u32((uint32_t)r); break;
                            default:              push_u64((uint64_t)r); break;
                            }
                            return;
                        }
                    }
                    if (u->op == "!") {
                        bool b = (lit->type == DataType::BOOL) ? lit->bool_val : (lit->int_val != 0);
                        push_u8((uint8_t)Op::PUSH);
                        push_u8((uint8_t)DataType::BOOL);
                        push_u8(b ? 0 : 1);
                        return;
                    }
                }
            }
            emit_expr(u->operand.get(), cls, locals);
            if (u->op == "-") push_u8((uint8_t)Op::NEG);
            else if (u->op == "!") push_u8((uint8_t)Op::NOT);
            else throw std::runtime_error("Unknown unary op " + u->op);
            return;
        }

        if (auto* b = dynamic_cast<BinaryExpr*>(e)) {
            if (opt_level_ >= 1) {
                auto* ll = dynamic_cast<LiteralExpr*>(b->lhs.get());
                auto* rr = dynamic_cast<LiteralExpr*>(b->rhs.get());
                if (ll && rr) {
                    const std::string& o = b->op;

                    bool l_num = is_numeric(ll->type);
                    bool r_num = is_numeric(rr->type);

                    if (l_num && r_num) {
                        bool use_f = (ll->type == DataType::FLOAT ||
                            rr->type == DataType::FLOAT);
                        double lv = (ll->type == DataType::FLOAT) ? ll->float_val : (double)ll->int_val;
                        double rv = (rr->type == DataType::FLOAT) ? rr->float_val : (double)rr->int_val;
                        int64_t li = (ll->type == DataType::FLOAT) ? (int64_t)ll->float_val : ll->int_val;
                        int64_t ri = (rr->type == DataType::FLOAT) ? (int64_t)rr->float_val : rr->int_val;

                        if (o == "+" || o == "-" || o == "*" || o == "/" || o == "%") {
                            if (use_f) {
                                double res = 0;
                                if (o == "+") res = lv + rv;
                                else if (o == "-") res = lv - rv;
                                else if (o == "*") res = lv * rv;
                                else if (o == "/") res = (rv != 0.0) ? lv / rv : 0.0;
                                else if (o == "%") res = (rv != 0.0) ? std::fmod(lv, rv) : 0.0;
                                push_u8((uint8_t)Op::PUSH);
                                push_u8((uint8_t)DataType::FLOAT);
                                uint64_t bits; std::memcpy(&bits, &res, 8);
                                push_u64(bits);
                            }
                            else {
                                int64_t res = 0;
                                if (o == "+") res = li + ri;
                                else if (o == "-") res = li - ri;
                                else if (o == "*") res = li * ri;
                                else if (o == "/") res = (ri != 0) ? li / ri : 0;
                                else if (o == "%") res = (ri != 0) ? li % ri : 0;
                                DataType t = smallest_int_for(res);
                                push_u8((uint8_t)Op::PUSH);
                                push_u8((uint8_t)t);
                                switch (t) {
                                case DataType::INT8:  push_u8((uint8_t)res); break;
                                case DataType::INT16: push_u16((uint16_t)res); break;
                                case DataType::INT32: push_u32((uint32_t)res); break;
                                default:              push_u64((uint64_t)res); break;
                                }
                            }
                            return;
                        }

                        if (o == "==" || o == "!=" || o == "<" || o == ">" || o == "<=" || o == ">=") {
                            bool res = false;
                            if (use_f) {
                                if (o == "==") res = (lv == rv);
                                else if (o == "!=") res = (lv != rv);
                                else if (o == "<")  res = (lv < rv);
                                else if (o == ">")  res = (lv > rv);
                                else if (o == "<=") res = (lv <= rv);
                                else if (o == ">=") res = (lv >= rv);
                            }
                            else {
                                if (o == "==") res = (li == ri);
                                else if (o == "!=") res = (li != ri);
                                else if (o == "<")  res = (li < ri);
                                else if (o == ">")  res = (li > ri);
                                else if (o == "<=") res = (li <= ri);
                                else if (o == ">=") res = (li >= ri);
                            }
                            push_u8((uint8_t)Op::PUSH);
                            push_u8((uint8_t)DataType::BOOL);
                            push_u8(res ? 1 : 0);
                            return;
                        }
                    }

                    if (ll->type == DataType::STR && rr->type == DataType::STR) {
                        if (o == "+") {
                            std::string res = ll->str_val + rr->str_val;
                            push_u8((uint8_t)Op::PUSH);
                            push_u8((uint8_t)DataType::STR);
                            push_u32((uint32_t)res.size());
                            push_str(res);
                            return;
                        }
                        if (o == "==" || o == "!=") {
                            bool res = (o == "==") ? (ll->str_val == rr->str_val)
                                : (ll->str_val != rr->str_val);
                            push_u8((uint8_t)Op::PUSH);
                            push_u8((uint8_t)DataType::BOOL);
                            push_u8(res ? 1 : 0);
                            return;
                        }
                        if (o == "<" || o == ">" || o == "<=" || o == ">=") {
                            int cmp = ll->str_val.compare(rr->str_val);
                            bool res = false;
                            if (o == "<")  res = (cmp < 0);
                            else if (o == ">")  res = (cmp > 0);
                            else if (o == "<=") res = (cmp <= 0);
                            else if (o == ">=") res = (cmp >= 0);
                            push_u8((uint8_t)Op::PUSH);
                            push_u8((uint8_t)DataType::BOOL);
                            push_u8(res ? 1 : 0);
                            return;
                        }
                    }

                    if (o == "&&" || o == "||") {
                        bool lb = (ll->type == DataType::BOOL) ? ll->bool_val : (ll->int_val != 0);
                        bool rb = (rr->type == DataType::BOOL) ? rr->bool_val : (rr->int_val != 0);
                        bool res = (o == "&&") ? (lb && rb) : (lb || rb);
                        push_u8((uint8_t)Op::PUSH);
                        push_u8((uint8_t)DataType::BOOL);
                        push_u8(res ? 1 : 0);
                        return;
                    }
                }
            }

            emit_expr(b->lhs.get(), cls, locals);
            emit_expr(b->rhs.get(), cls, locals);
            uint8_t op;
            const std::string& o = b->op;
            if (o == "+")  op = (uint8_t)Op::ADD;
            else if (o == "-")  op = (uint8_t)Op::SUB;
            else if (o == "*")  op = (uint8_t)Op::MUL;
            else if (o == "/")  op = (uint8_t)Op::DIV;
            else if (o == "%")  op = (uint8_t)Op::MOD;
            else if (o == "==") op = (uint8_t)Op::EQ;
            else if (o == "!=") op = (uint8_t)Op::NE;
            else if (o == "<")  op = (uint8_t)Op::LT;
            else if (o == ">")  op = (uint8_t)Op::GT;
            else if (o == "<=") op = (uint8_t)Op::LE;
            else if (o == ">=") op = (uint8_t)Op::GE;
            else if (o == "&&") op = (uint8_t)Op::AND;
            else if (o == "||") op = (uint8_t)Op::OR;
            else throw std::runtime_error("Unknown binary op " + o);
            push_u8(op);
            return;
        }

        if (auto* c = dynamic_cast<CallExpr*>(e)) {
            if (c->is_builtin && c->class_name == "thread") {
                if (c->builtin_name == "run") {
                    if (c->args.size() != 2) {
                        throw std::runtime_error("thread::run expects 2 arguments");
                    }
                    auto* ve = dynamic_cast<VarExpr*>(c->args[0].get());
                    if (!ve) {
                        throw std::runtime_error("thread::run: first argument must be a function name");
                    }
                    auto fit = functions_.find(ve->name);
                    if (fit == functions_.end()) {
                        throw std::runtime_error("thread::run: unknown function '" + ve->name + "'");
                    }
                    uint32_t func_id = fit->second;

                    push_u8((uint8_t)Op::PUSH);
                    push_u8((uint8_t)DataType::INT64);
                    push_u64(func_id);

                    emit_expr(c->args[1].get(), cls, locals);

                    push_u8((uint8_t)Op::THREAD_RUN);
                    return;
                }
                if (c->builtin_name == "await") {
                    emit_expr(c->args[0].get(), cls, locals);
                    push_u8((uint8_t)Op::THREAD_AWAIT);
                    return;
                }
                if (c->builtin_name == "alive") {
                    emit_expr(c->args[0].get(), cls, locals);
                    push_u8((uint8_t)Op::THREAD_ALIVE);
                    return;
                }
                if (c->builtin_name == "kill") {
                    emit_expr(c->args[0].get(), cls, locals);
                    push_u8((uint8_t)Op::THREAD_KILL);
                    return;
                }
                throw std::runtime_error(
                    "thread: unknown method '" + c->builtin_name +
                    "' (expected run/await/alive/kill)");
            }

            if (c->is_builtin) {
                if (c->builtin_name == "len" && c->obj_var_id == 0) {
                    for (auto& a : c->args) emit_expr(a.get(), cls, locals);
                    push_u8((uint8_t)Op::LEN);
                    return;
                }
                if (c->builtin_name == "len") {
                    push_u8((uint8_t)Op::LOAD_VAR);
                    push_u32(c->obj_var_id);
                    push_u8((uint8_t)Op::LEN);
                    return;
                }
                if (c->builtin_name == "push") {
                    push_u8((uint8_t)Op::LOAD_VAR);
                    push_u32(c->obj_var_id);
                    for (auto& a : c->args) emit_expr(a.get(), cls, locals);
                    push_u8((uint8_t)Op::PUSH_ITEM);
                    push_u8((uint8_t)Op::PUSH);
                    push_u8((uint8_t)DataType::NULL_);
                    return;
                }
                if (c->builtin_name == "pop") {
                    push_u8((uint8_t)Op::LOAD_VAR);
                    push_u32(c->obj_var_id);
                    push_u8((uint8_t)Op::POP_ITEM);
                    return;
                }
                if (c->builtin_name == "clear") {
                    push_u8((uint8_t)Op::LOAD_VAR);
                    push_u32(c->obj_var_id);
                    push_u8((uint8_t)Op::LIST_CLEAR);
                    push_u8((uint8_t)Op::PUSH);
                    push_u8((uint8_t)DataType::NULL_);
                    return;
                }
                if (c->builtin_name == "insert") {
                    push_u8((uint8_t)Op::LOAD_VAR);
                    push_u32(c->obj_var_id);
                    for (auto& a : c->args) emit_expr(a.get(), cls, locals);
                    push_u8((uint8_t)Op::LIST_INSERT);
                    push_u8((uint8_t)Op::PUSH);
                    push_u8((uint8_t)DataType::NULL_);
                    return;
                }
                if (c->builtin_name == "remove") {
                    push_u8((uint8_t)Op::LOAD_VAR);
                    push_u32(c->obj_var_id);
                    for (auto& a : c->args) emit_expr(a.get(), cls, locals);
                    push_u8((uint8_t)Op::LIST_REMOVE);
                    push_u8((uint8_t)Op::PUSH);
                    push_u8((uint8_t)DataType::NULL_);
                    return;
                }
                if (c->builtin_name == "has") {
                    push_u8((uint8_t)Op::LOAD_VAR);
                    push_u32(c->obj_var_id);
                    for (auto& a : c->args) emit_expr(a.get(), cls, locals);
                    push_u8((uint8_t)Op::DICT_HAS);
                    return;
                }
                if (c->builtin_name == "keys") {
                    push_u8((uint8_t)Op::LOAD_VAR);
                    push_u32(c->obj_var_id);
                    push_u8((uint8_t)Op::DICT_KEYS);
                    return;
                }
                if (c->builtin_name == "values") {
                    push_u8((uint8_t)Op::LOAD_VAR);
                    push_u32(c->obj_var_id);
                    push_u8((uint8_t)Op::DICT_VALUES);
                    return;
                }
                if (c->builtin_name == "fill") {
                    push_u8((uint8_t)Op::LOAD_VAR);
                    push_u32(c->obj_var_id);
                    for (auto& a : c->args) emit_expr(a.get(), cls, locals);
                    push_u8((uint8_t)Op::ARRAY_FILL);
                    push_u8((uint8_t)Op::PUSH);
                    push_u8((uint8_t)DataType::NULL_);
                    return;
                }
                throw std::runtime_error(
                    "Internal: unknown builtin '" + c->builtin_name + "'");
            }
            if (c->is_new_object) {
                if (c->init_id == 0) {
                    push_u8((uint8_t)Op::NEW_CLASS);
                    push_u32(c->id);
                    return;
                }

                push_u8((uint8_t)Op::NEW_CLASS);
                push_u32(c->id);

                push_u8((uint8_t)Op::STORE_VAR);
                push_u32(object_temp_id_);

                push_u8((uint8_t)Op::LOAD_VAR);
                push_u32(object_temp_id_);

                for (auto& a : c->args) emit_expr(a.get(), cls, locals);

                push_u8((uint8_t)Op::CALL_METHOD);
                push_u32(c->init_id);
                push_u8((uint8_t)c->args.size());

                push_u8((uint8_t)Op::POP);

                push_u8((uint8_t)Op::LOAD_VAR);
                push_u32(object_temp_id_);
                return;
            }

            if (c->is_free_method) {
                push_u8((uint8_t)Op::PUSH);
                push_u8((uint8_t)DataType::NULL_);
                push_u8((uint8_t)Op::STORE_VAR);
                push_u32(c->obj_var_id);
                push_u8((uint8_t)Op::PUSH);
                push_u8((uint8_t)DataType::NULL_);
                return;
            }

            if (c->is_field_method) {
                push_u8((uint8_t)Op::LOAD_VAR);
                push_u32(0);
                push_u8((uint8_t)Op::LOAD_FIELD);
                push_u32(c->field_id);
                for (auto& a : c->args) emit_expr(a.get(), cls, locals);
                push_u8((uint8_t)Op::CALL_METHOD);
                push_u32(c->id);
                push_u8((uint8_t)c->args.size());
                return;
            }

            if (c->is_method) {
                push_u8((uint8_t)Op::LOAD_VAR);
                push_u32(c->obj_var_id);
                for (auto& a : c->args) emit_expr(a.get(), cls, locals);
                push_u8((uint8_t)Op::CALL_METHOD);
                push_u32(c->id);
                push_u8((uint8_t)c->args.size());
                return;
            }

            for (auto& a : c->args) emit_expr(a.get(), cls, locals);
            if (c->is_native) {
                push_u8((uint8_t)Op::CALL_NATIVE);
                push_u32((uint32_t)c->class_name.size());
                push_str(c->class_name);
                push_u32((uint32_t)c->name.size());
                push_str(c->name);
                push_u8((uint8_t)c->args.size());
                return;
            }

            push_u8((uint8_t)Op::CALL);
            push_u32(c->id);
            push_u8((uint8_t)c->args.size());
            return;
        }

        throw std::runtime_error("Unknown expression node");
    }

    void Codegen::emit_if(IfStmt* s, const std::string& cls,
        const std::unordered_map<std::string, uint32_t>* locals) {
        emit_expr(s->cond.get(), cls, locals);

        push_u8((uint8_t)Op::JZ);
        size_t jz_pos = out_.size();
        push_u32(0);

        for (auto& st : s->then_body) emit_stmt(st.get(), cls, locals);

        if (s->else_body.empty()) {
            patch_u32(jz_pos, (uint32_t)out_.size());
        }
        else {
            push_u8((uint8_t)Op::JMP);
            size_t jmp_pos = out_.size();
            push_u32(0);

            patch_u32(jz_pos, (uint32_t)out_.size());

            for (auto& st : s->else_body) emit_stmt(st.get(), cls, locals);

            patch_u32(jmp_pos, (uint32_t)out_.size());
        }
    }

    void Codegen::emit_while(WhileStmt* s, const std::string& cls,
        const std::unordered_map<std::string, uint32_t>* locals) {
        LoopCtx ctx;
        ctx.start_ip = (uint32_t)out_.size();
        loop_stack_.push_back(std::move(ctx));

        uint32_t start = (uint32_t)out_.size();
        emit_expr(s->cond.get(), cls, locals);

        push_u8((uint8_t)Op::JZ);
        size_t jz_pos = out_.size();
        push_u32(0);

        for (auto& st : s->body) emit_stmt(st.get(), cls, locals);

        push_u8((uint8_t)Op::JMP);
        push_u32(start);

        uint32_t after = (uint32_t)out_.size();
        patch_u32(jz_pos, after);

        LoopCtx done = std::move(loop_stack_.back());
        loop_stack_.pop_back();
        for (size_t pos : done.break_patches) patch_u32(pos, after);

        for (size_t pos : done.continue_patches) patch_u32(pos, start);
    }

    void Codegen::emit_for(ForStmt* s, const std::string& cls,
        const std::unordered_map<std::string, uint32_t>* locals) {
        if (s->init) {
            emit_stmt(s->init.get(), cls, &s->for_scope);
        }

        LoopCtx ctx;
        ctx.start_ip = (uint32_t)out_.size();
        loop_stack_.push_back(std::move(ctx));

        uint32_t cond_start = (uint32_t)out_.size();

        if (s->cond) {
            emit_expr(s->cond.get(), cls, &s->for_scope);
        }
        else {
            push_u8((uint8_t)Op::PUSH);
            push_u8((uint8_t)DataType::BOOL);
            push_u8(1);
        }

        push_u8((uint8_t)Op::JZ);
        size_t jz_pos = out_.size();
        push_u32(0);

        for (auto& st : s->body) {
            emit_stmt(st.get(), cls, &s->body_scope);
        }

        uint32_t continue_target = (uint32_t)out_.size();

        if (s->step) {
            emit_stmt(s->step.get(), cls, &s->for_scope);
        }

        push_u8((uint8_t)Op::JMP);
        push_u32(cond_start);

        uint32_t after = (uint32_t)out_.size();
        patch_u32(jz_pos, after);

        LoopCtx done = std::move(loop_stack_.back());
        loop_stack_.pop_back();
        for (size_t pos : done.break_patches) patch_u32(pos, after);
        for (size_t pos : done.continue_patches) patch_u32(pos, continue_target);
    }

    void Codegen::emit_stmt(Stmt* s, const std::string& cls,
        const std::unordered_map<std::string, uint32_t>* locals) {
        if (auto* v = dynamic_cast<VarDeclStmt*>(s)) {
            if (v->init) {
                emit_expr(v->init.get(), cls, locals);
                push_u8((uint8_t)Op::STORE_VAR);
                push_u32(v->id);
            }
            return;
        }
        if (auto* a = dynamic_cast<AssignStmt*>(s)) {
            if (a->is_field) {
                push_u8((uint8_t)Op::LOAD_VAR);
                push_u32(a->obj_var_id);
                emit_expr(a->value.get(), cls, locals);
                push_u8((uint8_t)Op::STORE_FIELD);
                push_u32(a->field_id);
                return;
            }
            emit_expr(a->value.get(), cls, locals);
            push_u8((uint8_t)Op::STORE_VAR);
            push_u32(a->id);
            return;
        }
        if (auto* e = dynamic_cast<ExprStmt*>(s)) {
            emit_expr(e->expr.get(), cls, locals);
            push_u8((uint8_t)Op::POP);
            return;
        }
        if (auto* ai = dynamic_cast<AssignIndexStmt*>(s)) {
            emit_expr(ai->container.get(), cls, locals);
            emit_expr(ai->index.get(), cls, locals);
            emit_expr(ai->value.get(), cls, locals);
            push_u8((uint8_t)Op::INDEX_SET);
            return;
        }
        if (auto* r = dynamic_cast<ReturnStmt*>(s)) {
            if (r->value) emit_expr(r->value.get(), cls, locals);
            else {
                push_u8((uint8_t)Op::PUSH);
                push_u8((uint8_t)DataType::NULL_);
            }

            for (size_t i = 0; i < try_stack_.size(); ++i) {
                push_u8((uint8_t)Op::POP_HANDLER);
            }

            push_u8((uint8_t)Op::RET);
            return;
        }
        if (auto* i = dynamic_cast<IfStmt*>(s)) { emit_if(i, cls, locals); return; }
        if (auto* w = dynamic_cast<WhileStmt*>(s)) { emit_while(w, cls, locals); return; }
        if (auto* f = dynamic_cast<ForStmt*>(s)) { emit_for(f, cls, locals); return; }

        if (dynamic_cast<FunDecl*>(s) || dynamic_cast<ClassDecl*>(s)) return;

        if (auto* sw = dynamic_cast<SwitchStmt*>(s)) { emit_switch(sw, cls, locals); return; }

        if (dynamic_cast<BreakStmt*>(s)) {
            if (loop_stack_.empty())
                throw std::runtime_error("'break' outside of loop");
            push_u8((uint8_t)Op::JMP);
            loop_stack_.back().break_patches.push_back(out_.size());
            push_u32(0);
            return;
        }
        if (dynamic_cast<ContinueStmt*>(s)) {
            if (loop_stack_.empty())
                throw std::runtime_error("'continue' outside of loop");
            push_u8((uint8_t)Op::JMP);
            loop_stack_.back().continue_patches.push_back(out_.size());
            push_u32(0);
            return;
        }

        if (auto* t = dynamic_cast<TryStmt*>(s)) { emit_try(t, cls, locals); return; }
        if (auto* t = dynamic_cast<ThrowStmt*>(s)) { emit_throw(t, cls, locals); return; }

        throw std::runtime_error("Unknown statement node");
    }

    void Codegen::emit_fun_decl(FunDecl* f) {
        std::vector<uint8_t> saved = std::move(out_);
        out_.clear();

        auto& fun_locals = fun_locals_[f];
        for (auto& st : f->body) {
            emit_stmt(st.get(), funs_[f->id].class_name, &fun_locals);
        }
        push_u8((uint8_t)Op::PUSH);
        push_u8((uint8_t)DataType::NULL_);
        push_u8((uint8_t)Op::RET);

        auto body_bytes = std::move(out_);
        out_ = std::move(saved);

        append_u8(funcs_section_, (uint8_t)Op::DECL_FUN);
        append_u32(funcs_section_, f->id);
        append_u32(funcs_section_, (uint32_t)f->name.size());
        append_str(funcs_section_, f->name);
        append_u8(funcs_section_, (uint8_t)f->return_type);
        append_u8(funcs_section_, funs_[f->id].is_method ? 1 : 0);
        append_u8(funcs_section_, (uint8_t)f->args.size());
        for (auto& a : f->args) {
            append_u32(funcs_section_, a.id);
            append_u8(funcs_section_, (uint8_t)a.type);
            append_u32(funcs_section_, (uint32_t)a.name.size());
            append_str(funcs_section_, a.name);
        }

        auto& fi = funs_[f->id];
        append_u32(funcs_section_, (uint32_t)fi.locals.size());
        for (auto& lv : fi.locals) {
            append_u32(funcs_section_, lv.id);
            append_u8(funcs_section_, (uint8_t)lv.type);
            append_u32(funcs_section_, (uint32_t)lv.name.size());
            append_str(funcs_section_, lv.name);
        }

        append_u8(funcs_section_, (uint8_t)Op::START_DATA);
        funcs_section_.insert(funcs_section_.end(), body_bytes.begin(), body_bytes.end());
        append_u8(funcs_section_, (uint8_t)Op::END_DATA);
    }

    void Codegen::emit_switch(SwitchStmt* s, const std::string& cls,
        const std::unordered_map<std::string, uint32_t>* locals) {

        emit_expr(s->expr.get(), cls, locals);

        std::vector<size_t> jnz_patches;
        std::vector<size_t> jmp_end_patches;

        for (auto& c : s->cases) {
            push_u8((uint8_t)Op::DUP);
            emit_expr(c.value.get(), cls, locals);
            push_u8((uint8_t)Op::EQ);
            push_u8((uint8_t)Op::JNZ);
            jnz_patches.push_back(out_.size());
            push_u32(0);
        }

        push_u8((uint8_t)Op::POP);
        push_u8((uint8_t)Op::JMP);
        size_t jmp_default = out_.size();
        push_u32(0);

        std::vector<size_t> case_starts;
        for (size_t i = 0; i < s->cases.size(); ++i) {
            case_starts.push_back(out_.size());
            push_u8((uint8_t)Op::POP);
            for (auto& st : s->cases[i].body) {
                emit_stmt(st.get(), cls, &s->body_scope);
            }
            push_u8((uint8_t)Op::JMP);
            jmp_end_patches.push_back(out_.size());
            push_u32(0);
        }

        size_t default_start = out_.size();
        if (s->has_default) {
            for (auto& st : s->default_body) {
                emit_stmt(st.get(), cls, &s->body_scope);
            }
        }

        size_t end = out_.size();

        for (size_t i = 0; i < jnz_patches.size(); ++i) {
            patch_u32(jnz_patches[i], (uint32_t)case_starts[i]);
        }
        patch_u32(jmp_default, (uint32_t)default_start);
        for (size_t pos : jmp_end_patches) {
            patch_u32(pos, (uint32_t)end);
        }
    }

    void Codegen::emit_class_decl(ClassDecl* c) {
        append_u8(classes_section_, (uint8_t)Op::DECL_CLASS);
        append_u32(classes_section_, c->id);
        append_u32(classes_section_, (uint32_t)c->name.size());
        append_str(classes_section_, c->name);

        auto& ci = classes_info_[c->id];
        append_u32(classes_section_, (uint32_t)ci.var_ids.size());
        for (uint32_t vid : ci.var_ids) append_u32(classes_section_, vid);

        std::vector<uint32_t> mids;
        for (auto& m : c->members) {
            if (auto* fm = dynamic_cast<FunDecl*>(m.get())) mids.push_back(fm->id);
        }
        append_u32(classes_section_, (uint32_t)mids.size());
        for (uint32_t fid : mids) append_u32(classes_section_, fid);
    }

    void Codegen::emit_main_stmt(Stmt* s) {
        if (auto* v = dynamic_cast<VarDeclStmt*>(s)) {
            if (v->init) {
                emit_expr(v->init.get(), "", nullptr);
                push_u8((uint8_t)Op::STORE_VAR);
                push_u32(v->id);
            }
            return;
        }
        if (dynamic_cast<FunDecl*>(s) || dynamic_cast<ClassDecl*>(s)) return;
        emit_stmt(s, "", nullptr);
    }

    void Codegen::emit_program() {
        for (auto& stmt : prog_->statements) {
            if (auto* f = dynamic_cast<FunDecl*>(stmt.get())) {
                emit_fun_decl(f);
            }
            else if (auto* c = dynamic_cast<ClassDecl*>(stmt.get())) {
                for (auto& m : c->members) {
                    if (auto* fm = dynamic_cast<FunDecl*>(m.get())) emit_fun_decl(fm);
                }
                emit_class_decl(c);
            }
        }

        for (auto& [id, info] : vars_) {
            if (info.is_arg || info.is_frame_local) continue;

            append_u8(vars_section_, (uint8_t)Op::DECL_VAR);
            append_u32(vars_section_, id);
            append_u8(vars_section_, (uint8_t)info.type);
            append_u32(vars_section_, (uint32_t)info.name.size());
            append_str(vars_section_, info.name);

            append_var_default(vars_section_, info.type);
        }

        out_.clear();

        for (auto& stmt : prog_->statements) {
            if (auto* c = dynamic_cast<ClassDecl*>(stmt.get())) {
                for (auto& m : c->members) {
                    if (auto* v = dynamic_cast<VarDeclStmt*>(m.get())) {
                        if (v->init) {
                            emit_expr(v->init.get(), c->name, nullptr);
                            push_u8((uint8_t)Op::STORE_VAR);
                            push_u32(v->id);
                        }
                    }
                }
            }
        }

        for (auto& stmt : prog_->statements) {
            if (dynamic_cast<ClassDecl*>(stmt.get())) continue;
            emit_main_stmt(stmt.get());
        }
        push_u8((uint8_t)Op::HALT);
    }

    std::vector<uint8_t> Codegen::build() {
        for (auto& lib : prog_->used_libs) {
            used_libs_set_.insert(lib);
        }

        pass1_register_toplevel();
        pass2_register_and_resolve();
        resolve_int_sizes();
        pass3_typecheck();
        emit_program();

        if (opt_level_ >= 2) {
            Optimizer opt;
            out_ = opt.run(out_, opt_level_);
        }

        std::vector<uint8_t> result;

        if (!prog_->used_libs.empty()) {
            result.push_back((uint8_t)Op::SEC_LIBS);
            append_u32(result, (uint32_t)prog_->used_libs.size());
            for (auto& lib : prog_->used_libs) {
                append_u32(result, (uint32_t)lib.size());
                append_str(result, lib);
            }
        }

        result.push_back((uint8_t)Op::SEC_VARS);
        result.insert(result.end(), vars_section_.begin(), vars_section_.end());

        result.push_back((uint8_t)Op::SEC_FUNCS);
        result.insert(result.end(), funcs_section_.begin(), funcs_section_.end());

        result.push_back((uint8_t)Op::SEC_CLASSES);
        result.insert(result.end(), classes_section_.begin(), classes_section_.end());

        result.push_back((uint8_t)Op::SEC_MAIN);
        result.insert(result.end(), out_.begin(), out_.end());

        return result;
    }

    void Codegen::append_var_default(std::vector<uint8_t>& v, DataType t) {
        v.push_back((uint8_t)t);
        switch (t) {
        case DataType::INT8:  v.push_back(0); break;
        case DataType::INT16: for (int i = 0; i < 2; ++i) v.push_back(0); break;
        case DataType::INT32: for (int i = 0; i < 4; ++i) v.push_back(0); break;
        case DataType::INT64:
        case DataType::INT:   for (int i = 0; i < 8; ++i) v.push_back(0); break;
        case DataType::FLOAT: for (int i = 0; i < 8; ++i) v.push_back(0); break;
        case DataType::BOOL:  v.push_back(0); break;
        case DataType::STR:
        case DataType::BIN:
        case DataType::HEX:
        case DataType::AUTO:
        case DataType::OBJECT:
        case DataType::NULL_:
            for (int i = 0; i < 4; ++i) v.push_back(0);
            break;
        }
    }

    void Codegen::emit_try(TryStmt* s, const std::string& cls,
        const std::unordered_map<std::string, uint32_t>* locals) {

        TryContext ctx;
        try_stack_.push_back(std::move(ctx));
        size_t ctx_index = try_stack_.size() - 1;

        push_u8((uint8_t)Op::PUSH_HANDLER);
        size_t handler_patch_pos = out_.size();
        push_u32(0);

        for (auto& b : s->try_body) {
            emit_stmt(b.get(), cls, &s->try_scope);
        }

        push_u8((uint8_t)Op::POP_HANDLER);

        push_u8((uint8_t)Op::JMP);
        size_t jmp_to_end_pos = out_.size();
        push_u32(0);

        size_t catch_label = out_.size();
        patch_u32(handler_patch_pos, (uint32_t)catch_label);

        if (!s->catch_var.empty()) {
            push_u8((uint8_t)Op::STORE_VAR);
            push_u32(s->catch_var_id);
        }
        else {
            push_u8((uint8_t)Op::POP);
        }

        for (auto& b : s->catch_body) {
            emit_stmt(b.get(), cls, &s->catch_scope);
        }

        size_t finally_label = out_.size();
        patch_u32(jmp_to_end_pos, (uint32_t)finally_label);

        for (auto& b : s->finally_body) {
            emit_stmt(b.get(), cls, &s->finally_scope);
        }

        size_t end = out_.size();

        try_stack_.pop_back();

        for (size_t pos : try_stack_.empty() ? std::vector<size_t>{} : std::vector<size_t>{}) {
            (void)pos;
        }

        (void)ctx_index;
        (void)end;
    }

    void Codegen::emit_throw(ThrowStmt* s, const std::string& cls,
        const std::unordered_map<std::string, uint32_t>* locals) {
        if (s->value) {
            emit_expr(s->value.get(), cls, locals);
        }
        else {
            push_u8((uint8_t)Op::PUSH);
            push_u8((uint8_t)DataType::NULL_);
        }

        push_u8((uint8_t)Op::THROW);
    }

}