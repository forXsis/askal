/**
 * Copyright 2026 forXsis
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /** Contact me!
 * Gmail: forxtrees@gmail.com
 * Git: https://github.com/forXsis
 * Askal GitHub project: https://github.com/forXsis/askal
 */

#pragma once
#include "askal_token.h"
#include <vector>
#include <string>

namespace askal {

    class Lexer {
    public:
        explicit Lexer(std::string src);
        std::vector<Token> tokenize();

    private:
        std::string src_;
        size_t      pos_ = 0;
        uint32_t    line_ = 1;
        uint32_t    col_ = 1;

        char  peek(int offset = 0) const;
        char  advance();
        bool  match(char c);
        void  skip_ws_and_comments();

        Token make(TokKind k, std::string v = "");
        Token lex_ident();
        Token lex_number();
        Token lex_string();
        Token lex_hex();
        Token lex_bin();

        [[noreturn]] void error(const std::string& msg) const;
    };

}