/**
 * Copyright 2026 forXsis
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /** Contact me!
 * Gmail: forxtrees@gmail.com
 * Git: https://github.com/forXsis
 * Askal GitHub project: https://github.com/forXsis/askal
 */

#include "askal_parser.h"
#include <stdexcept>

namespace askal {

    Parser::Parser(std::vector<Token> tokens) : toks_(std::move(tokens)) {}

    const Token& Parser::peek(int off) const {
        size_t p = pos_ + off;
        if (p >= toks_.size()) return toks_.back();
        return toks_[p];
    }

    bool Parser::check(TokKind k) const { return cur().kind == k; }

    bool Parser::match(TokKind k) {
        if (check(k)) { ++pos_; return true; }
        return false;
    }

    const Token& Parser::consume() { return toks_[pos_++]; }

    const Token& Parser::expect(TokKind k, const std::string& what) {
        if (!check(k)) error("Expected " + what);
        return toks_[pos_++];
    }

    void Parser::error(const std::string& msg) const {
        throw std::runtime_error(
            "Parser error at " + std::to_string(cur().line) + ":" +
            std::to_string(cur().col) + " — " + msg +
            " (got '" + cur().value + "')");
    }

    Program Parser::parse() {
        Program p;

        while (check(TokKind::KW_USE) || check(TokKind::KW_INCLUDE)) {
            if (check(TokKind::KW_USE)) {
                consume();
                const Token& n = expect(TokKind::IDENT, "library name");
                p.used_libs.push_back(n.value);
                expect(TokKind::SEMI, "';'");
            }
            else {
                Token kw = consume();
                const Token& path_tok = expect(TokKind::STRING, "file path string");
                IncludeDirective inc;
                inc.path = path_tok.value;
                inc.line = kw.line;
                inc.col = kw.col;
                p.includes.push_back(inc);
                expect(TokKind::SEMI, "';'");
            }
        }

        while (!check(TokKind::END)) {
            p.statements.push_back(parse_statement());
        }
        return p;
    }

    StmtPtr Parser::parse_statement() {
        if (check(TokKind::KW_VAR))   return parse_var_decl();
        if (check(TokKind::KW_FUN))   return parse_fun_decl();
        if (check(TokKind::KW_CLASS)) return parse_class_decl();
        if (check(TokKind::KW_RETURN))return parse_return();
        if (check(TokKind::KW_IF))    return parse_if();
        if (check(TokKind::KW_WHILE)) return parse_while();
        if (check(TokKind::KW_FOR)) return parse_for();
        if (check(TokKind::KW_SWITCH)) return parse_switch();
        if (check(TokKind::KW_TRY))   return parse_try();
        if (check(TokKind::KW_THROW)) return parse_throw();
        if (check(TokKind::KW_BREAK)) {
            auto s = std::make_unique<BreakStmt>();
            s->line = cur().line; s->col = cur().col;
            consume();
            expect(TokKind::SEMI, "';'");
            return s;
        }
        if (check(TokKind::KW_CONTINUE)) {
            auto s = std::make_unique<ContinueStmt>();
            s->line = cur().line; s->col = cur().col;
            consume();
            expect(TokKind::SEMI, "';'");
            return s;
        }
        return parse_assign_or_expr();
    }

    StmtPtr Parser::parse_switch() {
        auto s = std::make_unique<SwitchStmt>();
        s->line = cur().line; s->col = cur().col;
        consume();

        expect(TokKind::LPAREN, "'('");
        s->expr = parse_expr();
        expect(TokKind::RPAREN, "')'");
        expect(TokKind::LBRACE, "'{'");

        while (!check(TokKind::RBRACE) && !check(TokKind::END)) {
            if (check(TokKind::KW_CASE)) {
                consume();
                SwitchCase sc;
                sc.value = parse_expr();
                expect(TokKind::COLON, "':'");

                while (!check(TokKind::KW_CASE) &&
                    !check(TokKind::KW_DEFAULT) &&
                    !check(TokKind::RBRACE) &&
                    !check(TokKind::END)) {
                    sc.body.push_back(parse_statement());
                }
                s->cases.push_back(std::move(sc));
            }
            else if (check(TokKind::KW_DEFAULT)) {
                consume();
                expect(TokKind::COLON, "':'");
                s->has_default = true;

                while (!check(TokKind::KW_CASE) &&
                    !check(TokKind::KW_DEFAULT) &&
                    !check(TokKind::RBRACE) &&
                    !check(TokKind::END)) {
                    s->default_body.push_back(parse_statement());
                }
            }
            else {
                error("Expected 'case' or 'default' inside switch");
            }
        }
        expect(TokKind::RBRACE, "'}'");
        return s;
    }

    std::vector<StmtPtr> Parser::parse_block() {
        expect(TokKind::LBRACE, "'{'");
        std::vector<StmtPtr> body;
        while (!check(TokKind::RBRACE) && !check(TokKind::END)) {
            body.push_back(parse_statement());
        }
        expect(TokKind::RBRACE, "'}'");
        return body;
    }

    StmtPtr Parser::parse_var_decl() {
        auto s = std::make_unique<VarDeclStmt>();
        s->line = cur().line; s->col = cur().col;
        consume();

        bool is_auto = false;

        if (check(TokKind::IDENT)) {
            s->class_type_name = cur().value;
            s->type = DataType::OBJECT;
            consume();
        }
        else {
            s->type = parse_type();
        }
        const Token& n = expect(TokKind::IDENT, "variable name");

        s->name = n.value;

        if (match(TokKind::ASSIGN)) {
            s->init = parse_expr();
        }
        else if (is_auto) {
            error("'auto' requires an initializer");
        }

        expect(TokKind::SEMI, "';'");
        return s;
    }

    StmtPtr Parser::parse_fun_decl() {
        auto s = std::make_unique<FunDecl>();
        s->line = cur().line; s->col = cur().col;
        consume();
        const Token& n = expect(TokKind::IDENT, "function name");
        s->name = n.value;
        s->args = parse_args();

        if (match(TokKind::ARROW_RET)) {
            if (check(TokKind::IDENT)) {
                s->return_class_name = cur().value;
                s->return_type = DataType::OBJECT;
                consume();
            }
            else {
                s->return_type = parse_type();
            }
        }
        else {
            s->return_type = DataType::NULL_;
        }
        s->body = parse_block();
        return s;
    }

    StmtPtr Parser::parse_class_decl() {
        auto s = std::make_unique<ClassDecl>();
        s->line = cur().line; s->col = cur().col;
        consume();
        const Token& n = expect(TokKind::IDENT, "class name");
        s->name = n.value;
        expect(TokKind::LBRACE, "'{'");
        while (!check(TokKind::RBRACE) && !check(TokKind::END)) {
            if (check(TokKind::KW_VAR))      s->members.push_back(parse_var_decl());
            else if (check(TokKind::KW_FUN)) s->members.push_back(parse_fun_decl());
            else error("Expected 'var' or 'fun' inside class body");
        }
        expect(TokKind::RBRACE, "'}'");
        return s;
    }

    StmtPtr Parser::parse_return() {
        auto s = std::make_unique<ReturnStmt>();
        s->line = cur().line; s->col = cur().col;
        consume();
        if (!check(TokKind::SEMI)) {
            s->value = parse_expr();
        }
        expect(TokKind::SEMI, "';'");
        return s;
    }

    StmtPtr Parser::parse_try() {
        auto s = std::make_unique<TryStmt>();
        s->line = cur().line; s->col = cur().col;

        consume();
        s->try_body = parse_block();

        bool has_catch = false;
        bool has_finally = false;

        if (check(TokKind::KW_CATCH)) {
            has_catch = true;
            consume();
            expect(TokKind::LPAREN, "'('");
            const Token& var = expect(TokKind::IDENT, "exception variable");
            s->catch_var = var.value;
            expect(TokKind::RPAREN, "')'");
            s->catch_body = parse_block();
        }

        if (check(TokKind::KW_FINALLY)) {
            has_finally = true;
            consume();
            s->finally_body = parse_block();
        }

        if (!has_catch && !has_finally) {
            error("'try' requires either 'catch' or 'finally'");
        }

        return s;
    }

    StmtPtr Parser::parse_throw() {
        auto s = std::make_unique<ThrowStmt>();
        s->line = cur().line; s->col = cur().col;

        consume();
        s->value = parse_expr();
        expect(TokKind::SEMI, "';'");

        return s;
    }

    StmtPtr Parser::parse_if() {
        auto s = std::make_unique<IfStmt>();
        s->line = cur().line; s->col = cur().col;
        consume();
        expect(TokKind::LPAREN, "'('");
        s->cond = parse_expr();
        expect(TokKind::RPAREN, "')'");
        s->then_body = parse_block();

        if (match(TokKind::KW_ELSE)) {
            if (check(TokKind::KW_IF)) {
                s->else_body.push_back(parse_if());
            }
            else {
                s->else_body = parse_block();
            }
        }
        return s;
    }

    StmtPtr Parser::parse_for() {
        auto s = std::make_unique<ForStmt>();
        s->line = cur().line; s->col = cur().col;
        consume();

        expect(TokKind::LPAREN, "'('");

        if (!check(TokKind::SEMI)) {
            if (check(TokKind::KW_VAR)) {
                s->init = parse_var_decl();
            }
            else {
                const Token& id = expect(TokKind::IDENT, "identifier in for-init");
                auto assign = std::make_unique<AssignStmt>();
                assign->name = id.value;
                expect(TokKind::ASSIGN, "'='");
                assign->value = parse_expr();
                expect(TokKind::SEMI, "';'");
                s->init = std::move(assign);
            }
        }
        else {
            consume();
        }

        if (!check(TokKind::SEMI)) {
            s->cond = parse_expr();
        }
        expect(TokKind::SEMI, "';'");

        if (!check(TokKind::RPAREN)) {
            if (check(TokKind::IDENT)) {
                size_t save = pos_;
                std::string name = cur().value;
                consume();

                if (check(TokKind::PLUS_PLUS) || check(TokKind::MINUS_MINUS)) {
                    bool is_inc = check(TokKind::PLUS_PLUS);
                    consume();
                    auto lhs = std::make_unique<VarExpr>();
                    lhs->name = name;
                    auto one = std::make_unique<LiteralExpr>();
                    one->type = DataType::INT;
                    one->int_val = 1;
                    auto bin = std::make_unique<BinaryExpr>();
                    bin->op = is_inc ? "+" : "-";
                    bin->lhs = std::move(lhs);
                    bin->rhs = std::move(one);
                    auto assign = std::make_unique<AssignStmt>();
                    assign->name = name;
                    assign->value = std::move(bin);
                    s->step = std::move(assign);
                }
                else if (check(TokKind::ASSIGN)) {
                    consume();
                    auto assign = std::make_unique<AssignStmt>();
                    assign->name = name;
                    assign->value = parse_expr();
                    s->step = std::move(assign);
                }
                else if (check(TokKind::PLUS_ASSIGN) || check(TokKind::MINUS_ASSIGN) ||
                    check(TokKind::STAR_ASSIGN) || check(TokKind::SLASH_ASSIGN) ||
                    check(TokKind::PERCENT_ASSIGN)) {
                    std::string op;
                    if (check(TokKind::PLUS_ASSIGN))    op = "+";
                    else if (check(TokKind::MINUS_ASSIGN))   op = "-";
                    else if (check(TokKind::STAR_ASSIGN))    op = "*";
                    else if (check(TokKind::SLASH_ASSIGN))   op = "/";
                    else if (check(TokKind::PERCENT_ASSIGN)) op = "%";
                    consume();

                    auto lhs = std::make_unique<VarExpr>();
                    lhs->name = name;
                    auto rhs = parse_expr();
                    auto bin = std::make_unique<BinaryExpr>();
                    bin->op = op;
                    bin->lhs = std::move(lhs);
                    bin->rhs = std::move(rhs);
                    auto assign = std::make_unique<AssignStmt>();
                    assign->name = name;
                    assign->value = std::move(bin);
                    s->step = std::move(assign);
                }
                else {
                    pos_ = save;
                    auto es = std::make_unique<ExprStmt>();
                    es->expr = parse_expr();
                    s->step = std::move(es);
                }
            }
            else {
                auto es = std::make_unique<ExprStmt>();
                es->expr = parse_expr();
                s->step = std::move(es);
            }
        }
        expect(TokKind::RPAREN, "')'");

        s->body = parse_block();
        return s;
    }

    StmtPtr Parser::parse_while() {
        auto s = std::make_unique<WhileStmt>();
        s->line = cur().line; s->col = cur().col;
        consume();
        expect(TokKind::LPAREN, "'('");
        s->cond = parse_expr();
        expect(TokKind::RPAREN, "')'");
        s->body = parse_block();
        return s;
    }

    StmtPtr Parser::parse_assign_or_expr() {

        auto e = parse_expr();

        if (check(TokKind::PLUS_PLUS) || check(TokKind::MINUS_MINUS)) {
            auto* ve = dynamic_cast<VarExpr*>(e.get());
            if (!ve) error("++ or -- requires a variable");
            bool is_inc = check(TokKind::PLUS_PLUS);
            consume();
            expect(TokKind::SEMI, "';'");

            auto lhs = std::make_unique<VarExpr>();
            lhs->name = ve->name;
            lhs->class_name = ve->class_name;

            auto one = std::make_unique<LiteralExpr>();
            one->type = DataType::INT;
            one->int_val = 1;

            auto bin = std::make_unique<BinaryExpr>();
            bin->op = is_inc ? "+" : "-";
            bin->lhs = std::move(lhs);
            bin->rhs = std::move(one);

            auto s = std::make_unique<AssignStmt>();
            s->name = ve->name;
            s->class_name = ve->class_name;
            s->value = std::move(bin);
            return s;
        }

        TokKind tk = cur().kind;
        std::string compound_op;
        bool is_assign = false;

        if (tk == TokKind::ASSIGN) {
            is_assign = true;
        }
        else if (tk == TokKind::PLUS_ASSIGN) { is_assign = true; compound_op = "+"; }
        else if (tk == TokKind::MINUS_ASSIGN) { is_assign = true; compound_op = "-"; }
        else if (tk == TokKind::STAR_ASSIGN) { is_assign = true; compound_op = "*"; }
        else if (tk == TokKind::SLASH_ASSIGN) { is_assign = true; compound_op = "/"; }
        else if (tk == TokKind::PERCENT_ASSIGN) { is_assign = true; compound_op = "%"; }

        if (is_assign) {
            consume();

            if (auto* ie = dynamic_cast<IndexExpr*>(e.get())) {
                auto s = std::make_unique<AssignIndexStmt>();
                s->container = std::move(ie->container);
                s->index = std::move(ie->index);

                if (compound_op.empty()) {
                    s->value = parse_expr();
                }
                else {
                    auto idx_copy = std::make_unique<IndexExpr>();
                    error("Compound assignment on index is not supported");
                }
                expect(TokKind::SEMI, "';'");
                return s;
            }

            auto* ve = dynamic_cast<VarExpr*>(e.get());
            if (!ve) error("Invalid assignment target");

            auto s = std::make_unique<AssignStmt>();
            s->name = ve->name;
            s->class_name = ve->class_name;

            if (compound_op.empty()) {
                s->value = parse_expr();
            }
            else {
                auto lhs = std::make_unique<VarExpr>();
                lhs->name = ve->name;
                lhs->class_name = ve->class_name;

                auto rhs = parse_expr();

                auto bin = std::make_unique<BinaryExpr>();
                bin->op = compound_op;
                bin->lhs = std::move(lhs);
                bin->rhs = std::move(rhs);

                s->value = std::move(bin);
            }
            expect(TokKind::SEMI, "';'");
            return s;
        }

        auto s = std::make_unique<ExprStmt>();
        s->expr = std::move(e);
        expect(TokKind::SEMI, "';'");
        return s;
    }

    ExprPtr Parser::parse_expr() {
        auto cond = parse_logic_or();
        if (check(TokKind::QUESTION)) {
            consume();
            auto t = std::make_unique<TernaryExpr>();
            t->cond = std::move(cond);
            t->then_expr = parse_expr();
            expect(TokKind::COLON, "':'");
            t->else_expr = parse_expr();
            return t;
        }
        return cond;
    }


    ExprPtr Parser::parse_logic_or() {
        auto lhs = parse_logic_and();
        while (check(TokKind::OR_OP)) {
            consume();
            auto e = std::make_unique<BinaryExpr>();
            e->op = "||";
            e->lhs = std::move(lhs);
            e->rhs = parse_logic_and();
            lhs = std::move(e);
        }
        return lhs;
    }

    ExprPtr Parser::parse_logic_and() {
        auto lhs = parse_equality();
        while (check(TokKind::AND_OP)) {
            consume();
            auto e = std::make_unique<BinaryExpr>();
            e->op = "&&";
            e->lhs = std::move(lhs);
            e->rhs = parse_equality();
            lhs = std::move(e);
        }
        return lhs;
    }

    ExprPtr Parser::parse_equality() {
        auto lhs = parse_comparison();
        while (check(TokKind::EQ) || check(TokKind::NE)) {
            std::string op = check(TokKind::EQ) ? "==" : "!=";
            consume();
            auto e = std::make_unique<BinaryExpr>();
            e->op = op;
            e->lhs = std::move(lhs);
            e->rhs = parse_comparison();
            lhs = std::move(e);
        }
        return lhs;
    }

    ExprPtr Parser::parse_comparison() {
        auto lhs = parse_term();
        while (check(TokKind::LT) || check(TokKind::GT) ||
            check(TokKind::LE) || check(TokKind::GE)) {
            std::string op;
            switch (cur().kind) {
            case TokKind::LT: op = "<";  break;
            case TokKind::GT: op = ">";  break;
            case TokKind::LE: op = "<="; break;
            case TokKind::GE: op = ">="; break;
            default: break;
            }
            consume();
            auto e = std::make_unique<BinaryExpr>();
            e->op = op;
            e->lhs = std::move(lhs);
            e->rhs = parse_term();
            lhs = std::move(e);
        }
        return lhs;
    }

    ExprPtr Parser::parse_term() {
        auto lhs = parse_factor();
        while (check(TokKind::PLUS) || check(TokKind::MINUS)) {
            std::string op = check(TokKind::PLUS) ? "+" : "-";
            consume();
            auto e = std::make_unique<BinaryExpr>();
            e->op = op;
            e->lhs = std::move(lhs);
            e->rhs = parse_factor();
            lhs = std::move(e);
        }
        return lhs;
    }

    ExprPtr Parser::parse_factor() {
        auto lhs = parse_unary();
        while (check(TokKind::STAR) || check(TokKind::SLASH) ||
            check(TokKind::PERCENT)) {
            std::string op;
            switch (cur().kind) {
            case TokKind::STAR:    op = "*"; break;
            case TokKind::SLASH:   op = "/"; break;
            case TokKind::PERCENT: op = "%"; break;
            default: break;
            }
            consume();
            auto e = std::make_unique<BinaryExpr>();
            e->op = op;
            e->lhs = std::move(lhs);
            e->rhs = parse_unary();
            lhs = std::move(e);
        }
        return lhs;
    }

    ExprPtr Parser::parse_unary() {
        if (check(TokKind::MINUS) || check(TokKind::NOT_OP)) {
            auto e = std::make_unique<UnaryExpr>();
            e->op = check(TokKind::MINUS) ? "-" : "!";
            consume();
            e->operand = parse_unary();
            return e;
        }
        return parse_primary();
    }

    ExprPtr Parser::parse_primary() {
        const Token& t = cur();
        switch (t.kind) {
        case TokKind::NUMBER: {
            auto e = std::make_unique<LiteralExpr>();
            e->type = DataType::INT;
            e->int_val = std::stoll(t.value);
            consume();
            return e;
        }
        case TokKind::FLOAT: {
            auto e = std::make_unique<LiteralExpr>();
            e->type = DataType::FLOAT;
            e->float_val = std::stod(t.value);
            consume();
            return e;
        }
        case TokKind::STRING: {
            auto e = std::make_unique<LiteralExpr>();
            e->type = DataType::STR;
            e->str_val = t.value;
            consume();
            return e;
        }
        case TokKind::TRUE_:
        case TokKind::FALSE_: {
            auto e = std::make_unique<LiteralExpr>();
            e->type = DataType::BOOL;
            e->bool_val = (t.kind == TokKind::TRUE_);
            consume();
            return e;
        }
        case TokKind::NULL_: {
            auto e = std::make_unique<LiteralExpr>();
            e->type = DataType::NULL_;
            consume();
            return e;
        }
        case TokKind::HEX: {
            auto e = std::make_unique<LiteralExpr>();
            e->type = DataType::HEX;
            e->str_val = t.value;
            consume();
            return e;
        }
        case TokKind::BIN: {
            auto e = std::make_unique<LiteralExpr>();
            e->type = DataType::BIN;
            e->str_val = t.value;
            consume();
            return e;
        }
        case TokKind::IDENT: {
            auto e = std::make_unique<VarExpr>();
            e->name = t.value;
            consume();
            return parse_postfix(std::move(e));
        }
        case TokKind::LPAREN: {
            consume();
            auto e = parse_expr();
            expect(TokKind::RPAREN, "')'");
            return parse_postfix(std::move(e));
        }

        case TokKind::LBRACKET: {
            return parse_postfix(parse_list_literal());
        }
        case TokKind::LBRACE: {
            return parse_postfix(parse_dict_literal());
        }

        default:
            error("Unexpected token in expression");
        }
    }

    ExprPtr Parser::parse_postfix(ExprPtr base) {
        if (check(TokKind::LPAREN)) {
            auto* ve = dynamic_cast<VarExpr*>(base.get());
            if (!ve) error("Expected function name before '('");
            auto call = std::make_unique<CallExpr>();
            call->name = ve->name;
            consume();
            if (!check(TokKind::RPAREN)) {
                call->args.push_back(parse_expr());
                while (match(TokKind::COMMA)) call->args.push_back(parse_expr());
            }
            expect(TokKind::RPAREN, "')'");
            return parse_postfix(std::move(call));
        }
        if (check(TokKind::ARROW)) {
            auto* ve = dynamic_cast<VarExpr*>(base.get());
            if (!ve) error("Expected class name before '>>'");
            consume();
            const Token& m = expect(TokKind::IDENT, "member name");
            if (check(TokKind::LPAREN)) {
                consume();
                auto call = std::make_unique<CallExpr>();
                call->class_name = ve->name;
                call->name = m.value;
                if (!check(TokKind::RPAREN)) {
                    call->args.push_back(parse_expr());
                    while (match(TokKind::COMMA)) call->args.push_back(parse_expr());
                }
                expect(TokKind::RPAREN, "')'");
                return parse_postfix(std::move(call));
            }
            auto v = std::make_unique<VarExpr>();
            v->class_name = ve->name;
            v->name = m.value;
            return parse_postfix(std::move(v));
        }

        if (check(TokKind::LBRACKET)) {
            consume();
            auto idx = parse_expr();
            expect(TokKind::RBRACKET, "']'");
            auto e = std::make_unique<IndexExpr>();
            e->container = std::move(base);
            e->index = std::move(idx);
            return parse_postfix(std::move(e));
        }
        return base;
    }

    DataType Parser::parse_type() {
        if (check(TokKind::TY_AUTO)) {
            consume();
            return DataType::AUTO;
        }
        switch (cur().kind) {
        case TokKind::TY_STR:   consume(); return DataType::STR;
        case TokKind::TY_BOOL:  consume(); return DataType::BOOL;
        case TokKind::TY_FLOAT: consume(); return DataType::FLOAT;
        case TokKind::TY_INT8:  consume(); return DataType::INT8;
        case TokKind::TY_INT16: consume(); return DataType::INT16;
        case TokKind::TY_INT32: consume(); return DataType::INT32;
        case TokKind::TY_INT64: consume(); return DataType::INT64;
        case TokKind::TY_INT:   consume(); return DataType::INT;
        case TokKind::TY_BIN:   consume(); return DataType::BIN;
        case TokKind::TY_HEX:   consume(); return DataType::HEX;
        case TokKind::TY_ARRAY: consume(); return DataType::ARRAY;
        case TokKind::TY_LIST:  consume(); return DataType::LIST;
        case TokKind::TY_DICT:  consume(); return DataType::DICT;
        default: error("Expected type name");
        }
    }

    std::vector<FunDecl::Arg> Parser::parse_args() {
        std::vector<FunDecl::Arg> args;
        expect(TokKind::LPAREN, "'('");
        if (!check(TokKind::RPAREN)) {
            do {
                FunDecl::Arg a;
                if (check(TokKind::IDENT)) {
                    a.class_type_name = cur().value;
                    a.type = DataType::OBJECT;
                    consume();
                }
                else {
                    a.type = parse_type();
                }
                const Token& n = expect(TokKind::IDENT, "argument name");
                a.name = n.value;
                args.push_back(std::move(a));
            } while (match(TokKind::COMMA));
        }
        expect(TokKind::RPAREN, "')'");
        return args;
    }

    ExprPtr Parser::parse_list_literal() {
        auto e = std::make_unique<ListLitExpr>();
        expect(TokKind::LBRACKET, "'['");

        if (!check(TokKind::RBRACKET)) {
            e->items.push_back(parse_expr());
            while (match(TokKind::COMMA)) {
                if (check(TokKind::RBRACKET)) break;
                e->items.push_back(parse_expr());
            }
        }
        expect(TokKind::RBRACKET, "']'");
        return e;
    }

    ExprPtr Parser::parse_dict_literal() {
        auto e = std::make_unique<DictLitExpr>();
        expect(TokKind::LBRACE, "'{'");

        if (!check(TokKind::RBRACE)) {
            const Token& k = expect(TokKind::STRING, "string key");
            expect(TokKind::COLON, "':'");
            auto v = parse_expr();
            e->entries.push_back({ k.value, std::move(v) });

            while (match(TokKind::COMMA)) {
                if (check(TokKind::RBRACE)) break;
                const Token& k2 = expect(TokKind::STRING, "string key");
                expect(TokKind::COLON, "':'");
                auto v2 = parse_expr();
                e->entries.push_back({ k2.value, std::move(v2) });
            }
        }
        expect(TokKind::RBRACE, "'}'");
        return e;
    }

}