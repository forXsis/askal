/**
 * Copyright 2026 forXsis
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /** Contact me!
 * Gmail: forxtrees@gmail.com
 * Git: https://github.com/forXsis
 * Askal GitHub project: https://github.com/forXsis/askal
 */

#pragma once
#include "askal_opcodes.h"
#include <string>
#include <vector>
#include <memory>
#include <cstdint>
#include <unordered_map>

namespace askal {

    enum class ExprKind {
        LITERAL, VAR, BINARY, UNARY, CALL, TERNARY, NEW_OBJECT,
        INDEX,
        LIST_LIT,
        DICT_LIT
    };

    struct Expr {
        ExprKind kind;
        uint32_t line = 0, col = 0;
        virtual ~Expr() = default;
    };
    using ExprPtr = std::unique_ptr<Expr>;

    struct LiteralExpr : Expr {
        DataType    type;
        std::string str_val;
        int64_t     int_val = 0;
        double      float_val = 0;
        bool        bool_val = false;
        LiteralExpr() { kind = ExprKind::LITERAL; }
    };

    struct VarExpr : Expr {
        std::string name;
        std::string class_name;
        uint32_t    id = 0;
        bool        is_field = false;
        uint32_t    field_id = 0;
        VarExpr() { kind = ExprKind::VAR; }
    };

    struct BinaryExpr : Expr {
        std::string op;
        ExprPtr lhs, rhs;
        BinaryExpr() { kind = ExprKind::BINARY; }
    };

    struct UnaryExpr : Expr {
        std::string op;
        ExprPtr operand;
        UnaryExpr() { kind = ExprKind::UNARY; }
    };

    struct CallExpr : Expr {
        std::string name;
        std::string class_name;
        std::vector<ExprPtr> args;
        uint32_t    id = 0;
        bool        is_native = false;
        bool        is_new_object = false;
        bool        is_method = false;
        uint32_t    obj_var_id = 0;
        uint32_t    init_id = 0;
        bool        is_free_method = false;
        bool        is_field_method = false;
        uint32_t    field_id = 0;
        bool        is_builtin = false;
        std::string builtin_name;
        CallExpr() { kind = ExprKind::CALL; }
    };

    struct TernaryExpr : Expr {
        ExprPtr cond;
        ExprPtr then_expr;
        ExprPtr else_expr;
        TernaryExpr() { kind = ExprKind::TERNARY; }
    };

    struct NewObjectExpr : Expr {
        std::string class_name;
        uint32_t    class_id = 0;
        NewObjectExpr() { kind = ExprKind::NEW_OBJECT; }
    };

    struct IndexExpr : Expr {
        ExprPtr container;
        ExprPtr index;
        IndexExpr() { kind = ExprKind::INDEX; }
    };

    struct ListLitExpr : Expr {
        std::vector<ExprPtr> items;
        bool is_fixed = false;
        ListLitExpr() { kind = ExprKind::LIST_LIT; }
    };

    struct DictLitExpr : Expr {
        std::vector<std::pair<std::string, ExprPtr>> entries;
        DictLitExpr() { kind = ExprKind::DICT_LIT; }
    };

    enum class StmtKind {
        VAR_DECL, ASSIGN, ASSIGN_INDEX, EXPR_STMT, RETURN,
        IF, WHILE, FOR, SWITCH,
        BREAK, CONTINUE,
        FUN_DECL, CLASS_DECL, TRY,
        THROW
    };

    struct Stmt {
        StmtKind kind;
        uint32_t line = 0, col = 0;
        virtual ~Stmt() = default;
    };
    using StmtPtr = std::unique_ptr<Stmt>;

    struct VarDeclStmt : Stmt {
        DataType    type;
        std::string class_type_name;
        std::string name;
        ExprPtr     init;
        uint32_t    id = 0;
        bool        type_inferred = false;
        VarDeclStmt() { kind = StmtKind::VAR_DECL; }
    };

    struct AssignStmt : Stmt {
        std::string name;
        std::string class_name;
        ExprPtr     value;
        uint32_t    id = 0;
        bool        is_field = false;
        uint32_t    obj_var_id = 0;
        uint32_t    field_id = 0;
        AssignStmt() { kind = StmtKind::ASSIGN; }
    };

    struct AssignIndexStmt : Stmt {
        ExprPtr container;
        ExprPtr index;
        ExprPtr value;
        AssignIndexStmt() { kind = StmtKind::ASSIGN_INDEX; }
    };

    struct ExprStmt : Stmt {
        ExprPtr expr;
        ExprStmt() { kind = StmtKind::EXPR_STMT; }
    };

    struct ReturnStmt : Stmt {
        ExprPtr value;
        ReturnStmt() { kind = StmtKind::RETURN; }
    };

    struct IfStmt : Stmt {
        ExprPtr              cond;
        std::vector<StmtPtr> then_body;
        std::vector<StmtPtr> else_body;
        std::unordered_map<std::string, uint32_t> then_scope;
        std::unordered_map<std::string, uint32_t> else_scope;
        IfStmt() { kind = StmtKind::IF; }
    };

    struct WhileStmt : Stmt {
        ExprPtr              cond;
        std::vector<StmtPtr> body;
        std::unordered_map<std::string, uint32_t> body_scope;
        WhileStmt() { kind = StmtKind::WHILE; }
    };

    struct ForStmt : Stmt {
        StmtPtr              init;
        ExprPtr              cond;
        StmtPtr              step;
        std::vector<StmtPtr> body;
        std::unordered_map<std::string, uint32_t> for_scope;
        std::unordered_map<std::string, uint32_t> body_scope;
        ForStmt() { kind = StmtKind::FOR; }
    };

    struct SwitchCase {
        ExprPtr              value;
        std::vector<StmtPtr> body;
    };

    struct SwitchStmt : Stmt {
        ExprPtr                 expr;
        std::vector<SwitchCase> cases;
        std::vector<StmtPtr>    default_body;
        bool                    has_default = false;
        std::unordered_map<std::string, uint32_t> body_scope;
        SwitchStmt() { kind = StmtKind::SWITCH; }
    };

    struct BreakStmt : Stmt {
        BreakStmt() { kind = StmtKind::BREAK; }
    };

    struct ContinueStmt : Stmt {
        ContinueStmt() { kind = StmtKind::CONTINUE; }
    };

    struct TryStmt : Stmt {
        std::vector<StmtPtr> try_body;
        std::string          catch_var;
        uint32_t             catch_var_id = 0;
        std::vector<StmtPtr> catch_body;
        std::vector<StmtPtr> finally_body;

        std::unordered_map<std::string, uint32_t> try_scope;
        std::unordered_map<std::string, uint32_t> catch_scope;
        std::unordered_map<std::string, uint32_t> finally_scope;

        TryStmt() { kind = StmtKind::TRY; }
    };

    struct ThrowStmt : Stmt {
        ExprPtr value;
        ThrowStmt() { kind = StmtKind::THROW; }
    };

    struct FunDecl : Stmt {
        struct Arg {
            DataType    type;
            std::string class_type_name;
            std::string name;
            uint32_t    id = 0;
        };
        std::string          name;
        std::vector<Arg>     args;
        DataType             return_type = DataType::NULL_;
        std::string          return_class_name;
        std::vector<StmtPtr> body;
        uint32_t             id = 0;
        FunDecl() { kind = StmtKind::FUN_DECL; }
    };

    struct ClassDecl : Stmt {
        std::string          name;
        std::vector<StmtPtr> members;
        uint32_t             id = 0;
        ClassDecl() { kind = StmtKind::CLASS_DECL; }
    };

    struct IncludeDirective {
        std::string path;
        uint32_t    line = 0;
        uint32_t    col = 0;
    };

    struct Program {
        std::vector<StmtPtr> statements;
        std::vector<std::string> used_libs;
        std::vector<IncludeDirective> includes;
    };

}