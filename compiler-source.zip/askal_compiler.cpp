﻿/**
 * Copyright 2026 forXsis
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /** Contact me!
 * Gmail: forxtrees@gmail.com
 * Git: https://github.com/forXsis
 * Askal GitHub project: https://github.com/forXsis/askal
 */

#include "askal_lexer.h"
#include "askal_parser.h"
#include "askal_codegen.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <stdexcept>
#include <unordered_set>
#include <filesystem>

namespace fs = std::filesystem;

namespace askal {

    static void dump_bytes(const std::vector<uint8_t>& b) {
        std::cout << "\n--- bytecode dump (" << b.size() << " bytes) ---\n";
        for (size_t i = 0; i < b.size(); i += 16) {
            std::cout << std::hex << std::setw(4) << std::setfill('0') << i << "  ";
            for (size_t j = 0; j < 16; ++j) {
                if (i + j < b.size()) {
                    std::cout << std::setw(2) << std::setfill('0')
                        << (int)b[i + j] << ' ';
                }
                else {
                    std::cout << "   ";
                }
                if (j == 7) std::cout << ' ';
            }
            std::cout << " |";
            for (size_t j = 0; j < 16 && i + j < b.size(); ++j) {
                uint8_t c = b[i + j];
                std::cout << (char)((c >= 32 && c < 127) ? c : '.');
            }
            std::cout << "|\n";
        }
        std::cout << std::dec << "\n";
    }

    namespace {
        std::string absolute_path(const std::string& p) {
            try {
                return fs::weakly_canonical(fs::absolute(p)).string();
            }
            catch (...) {
                return p;
            }
        }

        std::string resolve_include_path(const std::string& inc_path,
            const std::string& current_dir) {
            try {
                fs::path p(inc_path);
                if (p.is_absolute()) {
                    return fs::exists(p) ? p.string() : "";
                }
            }
            catch (...) {}
            fs::path candidate = fs::path(current_dir) / inc_path;
            if (fs::exists(candidate)) {
                return candidate.string();
            }

            return "";
        }

        void process_includes(askal::Program& prog,
            const std::string& current_dir,
            std::unordered_set<std::string>& seen)
        {
            std::vector<askal::StmtPtr> merged;

            for (auto& inc : prog.includes) {
                std::string resolved = resolve_include_path(inc.path, current_dir);
                if (resolved.empty()) {
                    throw std::runtime_error(
                        "Cannot find included file '" + inc.path + "' at line " +
                        std::to_string(inc.line) + ":" + std::to_string(inc.col));
                }

                std::string abs = absolute_path(resolved);
                if (seen.count(abs)) {
                    continue;
                }
                seen.insert(abs);

                std::ifstream f(resolved);
                if (!f) {
                    throw std::runtime_error("Cannot open include: " + resolved);
                }
                std::stringstream ss;
                ss << f.rdbuf();
                std::string src = ss.str();
                f.close();

                askal::Lexer lex(src);
                auto toks = lex.tokenize();

                askal::Parser parser(std::move(toks));
                askal::Program sub = parser.parse();

                std::string sub_dir = fs::path(resolved).parent_path().string();
                if (sub_dir.empty()) sub_dir = ".";
                process_includes(sub, sub_dir, seen);

                for (auto& lib : sub.used_libs) {
                    bool found = false;
                    for (auto& existing : prog.used_libs) {
                        if (existing == lib) { found = true; break; }
                    }
                    if (!found) prog.used_libs.push_back(lib);
                }

                for (auto& st : sub.statements) {
                    merged.push_back(std::move(st));
                }
            }

            if (!merged.empty()) {
                std::vector<askal::StmtPtr> new_stmts;
                new_stmts.reserve(merged.size() + prog.statements.size());
                for (auto& m : merged) new_stmts.push_back(std::move(m));
                for (auto& s : prog.statements) new_stmts.push_back(std::move(s));
                prog.statements = std::move(new_stmts);
            }

            prog.includes.clear();
        }

    }

    bool compile_file(const std::string& input,
        const std::string& output,
        bool verbose,
        bool dump,
        int opt_level) {
        try {
            std::ifstream f(input, std::ios::binary);
            if (!f) {
                std::cerr << "Cannot open " << input << "\n";
                return false;
            }
            std::stringstream ss;
            ss << f.rdbuf();
            std::string src = ss.str();
            f.close();

            if (verbose) std::cout << "[1/4] Lexing...\n";
            Lexer lex(src);
            auto toks = lex.tokenize();
            if (verbose) std::cout << "      " << toks.size() << " tokens\n";

            if (verbose) std::cout << "[2/4] Parsing...\n";
            Parser parser(std::move(toks));
            Program prog = parser.parse();

            if (!prog.includes.empty()) {
                std::unordered_set<std::string> seen;
                seen.insert(absolute_path(input));

                std::string main_dir = fs::path(input).parent_path().string();
                if (main_dir.empty()) main_dir = ".";

                if (verbose) std::cout << "      processing "
                    << prog.includes.size() << " include(s)...\n";
                process_includes(prog, main_dir, seen);
            }

            if (verbose) std::cout << "      " << prog.statements.size()
                << " top-level statements\n";

            if (verbose) std::cout << "[3/4] Analyzing & generating...\n";
            Codegen cg(&prog);
            cg.set_opt_level(opt_level);
            auto bytes = cg.build();
            if (verbose) std::cout << "      " << bytes.size() << " bytes\n";

            if (dump) dump_bytes(bytes);

            if (verbose) std::cout << "[4/4] Writing " << output << "\n";
            std::ofstream out(output, std::ios::binary);
            if (!out) {
                std::cerr << "Cannot write " << output << "\n";
                return false;
            }
            out.write(reinterpret_cast<const char*>(bytes.data()), bytes.size());
            out.close();

            std::cout << "OK: " << output << " (" << bytes.size() << " bytes)\n";
            return true;
        }
        catch (const std::exception& e) {
            std::cerr << "Compile error: " << e.what() << "\n";
            return false;
        }
    }

}