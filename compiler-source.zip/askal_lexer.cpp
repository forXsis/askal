/**
 * Copyright 2026 forXsis
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /** Contact me!
 * Gmail: forxtrees@gmail.com
 * Git: https://github.com/forXsis
 * Askal GitHub project: https://github.com/forXsis/askal
 */

#include "askal_lexer.h"
#include <cctype>
#include <unordered_map>
#include <stdexcept>

namespace askal {

    Lexer::Lexer(std::string src) : src_(std::move(src)) {}

    char Lexer::peek(int offset) const {
        size_t p = pos_ + offset;
        return p < src_.size() ? src_[p] : '\0';
    }

    char Lexer::advance() {
        char c = src_[pos_++];
        if (c == '\n') { ++line_; col_ = 1; }
        else { ++col_; }
        return c;
    }

    bool Lexer::match(char c) {
        if (peek() == c) { advance(); return true; }
        return false;
    }

    void Lexer::error(const std::string& msg) const {
        throw std::runtime_error(
            "Lexer error at " + std::to_string(line_) + ":" +
            std::to_string(col_) + " — " + msg);
    }

    Token Lexer::make(TokKind k, std::string v) {
        return Token{ k, std::move(v), line_, col_ };
    }

    void Lexer::skip_ws_and_comments() {
        while (pos_ < src_.size()) {
            char c = peek();
            if (isspace(static_cast<unsigned char>(c))) { advance(); continue; }
            if (c == '/' && peek(1) == '/') {
                while (pos_ < src_.size() && peek() != '\n') advance();
                continue;
            }
            if (c == '/' && peek(1) == '*') {
                advance(); advance();
                while (pos_ < src_.size() &&
                    !(peek() == '*' && peek(1) == '/')) advance();
                if (pos_ >= src_.size()) error("Unterminated block comment");
                advance(); advance();
                continue;
            }
            break;
        }
    }

    Token Lexer::lex_ident() {
        size_t start = pos_;
        while (pos_ < src_.size() &&
            (isalnum(static_cast<unsigned char>(peek())) || peek() == '_'))
            advance();
        std::string word = src_.substr(start, pos_ - start);

        static const std::unordered_map<std::string, TokKind> kw = {
            {"var",    TokKind::KW_VAR},
            {"fun",    TokKind::KW_FUN},
            {"class",  TokKind::KW_CLASS},
            {"return", TokKind::KW_RETURN},
            {"true",   TokKind::TRUE_},
            {"false",  TokKind::FALSE_},
            {"null",   TokKind::NULL_},
            {"if",     TokKind::KW_IF},
            {"else",   TokKind::KW_ELSE},
            {"while",  TokKind::KW_WHILE},
            {"for",    TokKind::KW_FOR},
            {"use",    TokKind::KW_USE},
            {"include", TokKind::KW_INCLUDE},
            {"break",    TokKind::KW_BREAK},
            {"continue", TokKind::KW_CONTINUE},
            {"switch",  TokKind::KW_SWITCH},
            {"case",    TokKind::KW_CASE},
            {"default", TokKind::KW_DEFAULT},
            {"try",     TokKind::KW_TRY},
            {"catch",   TokKind::KW_CATCH},
            {"finally", TokKind::KW_FINALLY},
            {"throw",   TokKind::KW_THROW},
            {"str",    TokKind::TY_STR},
            {"bool",   TokKind::TY_BOOL},
            {"float",  TokKind::TY_FLOAT},
            {"int8",   TokKind::TY_INT8},
            {"int16",  TokKind::TY_INT16},
            {"int32",  TokKind::TY_INT32},
            {"int64",  TokKind::TY_INT64},
            {"int",    TokKind::TY_INT},
            {"bin",    TokKind::TY_BIN},
            {"hex",    TokKind::TY_HEX},
            {"auto",   TokKind::TY_AUTO},
            {"array",  TokKind::TY_ARRAY},
            {"list",   TokKind::TY_LIST},
            {"dict",   TokKind::TY_DICT},
        };
        auto it = kw.find(word);
        if (it != kw.end()) return make(it->second, word);
        return make(TokKind::IDENT, word);
    }

    Token Lexer::lex_number() {
        size_t start = pos_;
        bool is_float = false;
        while (pos_ < src_.size() && isdigit(static_cast<unsigned char>(peek()))) advance();
        if (peek() == '.' && isdigit(static_cast<unsigned char>(peek(1)))) {
            is_float = true;
            advance();
            while (pos_ < src_.size() && isdigit(static_cast<unsigned char>(peek()))) advance();
        }
        return make(is_float ? TokKind::FLOAT : TokKind::NUMBER,
            src_.substr(start, pos_ - start));
    }

    Token Lexer::lex_string() {
        advance();
        std::string out;
        while (pos_ < src_.size() && peek() != '"') {
            char c = advance();
            if (c == '\\' && pos_ < src_.size()) {
                char e = advance();
                switch (e) {
                case 'n':  out += '\n'; break;
                case 't':  out += '\t'; break;
                case '\\': out += '\\'; break;
                case '"':  out += '"';  break;
                case '0':  out += '\0'; break;
                default:   out += e;    break;
                }
            }
            else {
                out += c;
            }
        }
        if (pos_ >= src_.size()) error("Unterminated string literal");
        advance();
        return make(TokKind::STRING, out);
    }

    Token Lexer::lex_hex() {
        size_t start = pos_;
        while (pos_ < src_.size() && isxdigit(static_cast<unsigned char>(peek()))) advance();
        std::string raw = src_.substr(start, pos_ - start);
        std::string clean;
        for (char c : raw) if (c != '_') clean += c;
        if (clean.empty()) error("Empty hex literal");
        return make(TokKind::HEX, clean);
    }

    Token Lexer::lex_bin() {
        size_t start = pos_;
        while (pos_ < src_.size() && (peek() == '0' || peek() == '1' || peek() == '_'))
            advance();
        std::string raw = src_.substr(start, pos_ - start);
        std::string clean;
        for (char c : raw) if (c != '_') clean += c;
        if (clean.empty()) error("Empty binary literal");
        return make(TokKind::BIN, clean);
    }

    std::vector<Token> Lexer::tokenize() {
        std::vector<Token> out;

        while (true) {
            skip_ws_and_comments();
            if (pos_ >= src_.size()) break;

            char c = peek();

            if (isalpha(static_cast<unsigned char>(c)) || c == '_') {
                out.push_back(lex_ident());
                continue;
            }

            if (isdigit(static_cast<unsigned char>(c))) {
                if (c == '0' && (peek(1) == 'x' || peek(1) == 'X')) {
                    advance(); advance();
                    out.push_back(lex_hex());
                    continue;
                }
                if (c == '0' && (peek(1) == 'b' || peek(1) == 'B')) {
                    advance(); advance();
                    out.push_back(lex_bin());
                    continue;
                }
                out.push_back(lex_number());
                continue;
            }

            if (c == '"') {
                out.push_back(lex_string());
                continue;
            }

            switch (c) {
            case '(': advance(); out.push_back(make(TokKind::LPAREN)); continue;
            case ')': advance(); out.push_back(make(TokKind::RPAREN)); continue;
            case '{': advance(); out.push_back(make(TokKind::LBRACE)); continue;
            case '}': advance(); out.push_back(make(TokKind::RBRACE)); continue;
            case ';': advance(); out.push_back(make(TokKind::SEMI));   continue;
            case ',': advance(); out.push_back(make(TokKind::COMMA));  continue;
            case '?': advance(); out.push_back(make(TokKind::QUESTION)); continue;
            case ':': advance(); out.push_back(make(TokKind::COLON));    continue;
            case '[': advance(); out.push_back(make(TokKind::LBRACKET)); continue;
            case ']': advance(); out.push_back(make(TokKind::RBRACKET)); continue;
            case '=':
                advance();
                if (match('=')) out.push_back(make(TokKind::EQ));
                else            out.push_back(make(TokKind::ASSIGN));
                continue;

            case '!':
                advance();
                if (match('=')) out.push_back(make(TokKind::NE));
                else            out.push_back(make(TokKind::NOT_OP));
                continue;

            case '<':
                advance();
                if (match('=')) out.push_back(make(TokKind::LE));
                else            out.push_back(make(TokKind::LT));
                continue;

            case '>':
                advance();
                if (match('>')) out.push_back(make(TokKind::ARROW));
                else if (match('=')) out.push_back(make(TokKind::GE));
                else                 out.push_back(make(TokKind::GT));
                continue;

            case '&':
                advance();
                if (match('&')) out.push_back(make(TokKind::AND_OP));
                else error("Expected '&&'");
                continue;

            case '|':
                advance();
                if (match('|')) out.push_back(make(TokKind::OR_OP));
                else error("Expected '||'");
                continue;

            case '-':
                advance();
                if (match('>')) out.push_back(make(TokKind::ARROW_RET));
                else if (match('=')) out.push_back(make(TokKind::MINUS_ASSIGN));
                else if (match('-')) out.push_back(make(TokKind::MINUS_MINUS));
                else            out.push_back(make(TokKind::MINUS));
                continue;

            case '*':
                advance();
                if (match('=')) out.push_back(make(TokKind::STAR_ASSIGN));
                else            out.push_back(make(TokKind::STAR));
                continue;

            case '/':
                advance();
                if (match('=')) out.push_back(make(TokKind::SLASH_ASSIGN));
                else            out.push_back(make(TokKind::SLASH));
                continue;

            case '%':
                advance();
                if (match('=')) out.push_back(make(TokKind::PERCENT_ASSIGN));
                else            out.push_back(make(TokKind::PERCENT));
                continue;

            case '+':
                advance();
                if (match('=')) out.push_back(make(TokKind::PLUS_ASSIGN));
                else if (match('+')) out.push_back(make(TokKind::PLUS_PLUS));
                else            out.push_back(make(TokKind::PLUS));
                continue;
            }

            error(std::string("Unexpected character '") + c + "'");
        }

        out.push_back(make(TokKind::END));
        return out;
    }

}