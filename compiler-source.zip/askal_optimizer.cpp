/**
 * Copyright 2026 forXsis
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /** Contact me!
 * Gmail: forxtrees@gmail.com
 * Git: https://github.com/forXsis
 * Askal GitHub project: https://github.com/forXsis/askal
 */

#include "askal_optimizer.h"
#include "askal_opcodes.h"
#include <cstring>
#include <unordered_map>
#include <unordered_set>

namespace askal {

    namespace {

        struct Instr {
            size_t start;
            size_t len;
            uint8_t op;
        };

        uint32_t read_u32_at(const std::vector<uint8_t>& b, size_t p) {
            return (uint32_t)b[p] | ((uint32_t)b[p + 1] << 8) |
                ((uint32_t)b[p + 2] << 16) | ((uint32_t)b[p + 3] << 24);
        }

        void write_u32_at(std::vector<uint8_t>& b, size_t p, uint32_t v) {
            b[p + 0] = (v) & 0xFF;
            b[p + 1] = (v >> 8) & 0xFF;
            b[p + 2] = (v >> 16) & 0xFF;
            b[p + 3] = (v >> 24) & 0xFF;
        }

        size_t instr_len(const std::vector<uint8_t>& b, size_t p) {
            uint8_t op = b[p];
            switch (op) {
            case (uint8_t)Op::HALT:
            case (uint8_t)Op::NOP:
            case (uint8_t)Op::START_DATA:
            case (uint8_t)Op::END_DATA:
            case (uint8_t)Op::POP:
            case (uint8_t)Op::DUP:
            case (uint8_t)Op::SWAP:
            case (uint8_t)Op::RET:
            case (uint8_t)Op::ADD:
            case (uint8_t)Op::SUB:
            case (uint8_t)Op::MUL:
            case (uint8_t)Op::DIV:
            case (uint8_t)Op::MOD:
            case (uint8_t)Op::NEG:
            case (uint8_t)Op::EQ:
            case (uint8_t)Op::NE:
            case (uint8_t)Op::LT:
            case (uint8_t)Op::GT:
            case (uint8_t)Op::LE:
            case (uint8_t)Op::GE:
            case (uint8_t)Op::AND:
            case (uint8_t)Op::OR:
            case (uint8_t)Op::NOT:
            case (uint8_t)Op::THROW:
            case (uint8_t)Op::POP_HANDLER:
            case (uint8_t)Op::NEW_LIST:
            case (uint8_t)Op::NEW_DICT:
            case (uint8_t)Op::INDEX_GET:
            case (uint8_t)Op::INDEX_SET:
            case (uint8_t)Op::LEN:
            case (uint8_t)Op::PUSH_ITEM:
            case (uint8_t)Op::POP_ITEM:
            case (uint8_t)Op::LIST_CLEAR:
            case (uint8_t)Op::LIST_INSERT:
            case (uint8_t)Op::LIST_REMOVE:
            case (uint8_t)Op::DICT_HAS:
            case (uint8_t)Op::DICT_KEYS:
            case (uint8_t)Op::DICT_REMOVE:
            case (uint8_t)Op::DICT_VALUES:
            case (uint8_t)Op::ARRAY_FILL:
            case (uint8_t)Op::FREE_OBJECT:
                return 1;

            case (uint8_t)Op::JMP:
            case (uint8_t)Op::JZ:
            case (uint8_t)Op::JNZ:
            case (uint8_t)Op::LOAD_VAR:
            case (uint8_t)Op::STORE_VAR:
            case (uint8_t)Op::PUSH_HANDLER:
            case (uint8_t)Op::NEW_CLASS:
            case (uint8_t)Op::LOAD_FIELD:
            case (uint8_t)Op::STORE_FIELD:
            case (uint8_t)Op::NEW_ARRAY:
                return 5;

            case (uint8_t)Op::CALL:
                return 6;

            case (uint8_t)Op::CALL_METHOD:
                return 6;

            case (uint8_t)Op::PUSH: {
                uint8_t t = b[p + 1];
                size_t len = 2;
                switch ((DataType)t) {
                case DataType::INT8:  len += 1; break;
                case DataType::INT16: len += 2; break;
                case DataType::INT32: len += 4; break;
                case DataType::INT64:
                case DataType::INT:
                case DataType::FLOAT: len += 8; break;
                case DataType::BOOL:  len += 1; break;
                case DataType::STR:
                case DataType::BIN:
                case DataType::HEX: {
                    uint32_t l = read_u32_at(b, p + 2);
                    len += 4 + l;
                    break;
                }
                case DataType::NULL_: break;
                default: break;
                }
                return len;
            }

            case (uint8_t)Op::CALL_NATIVE: {
                size_t q = p + 1;
                uint32_t ll = read_u32_at(b, q); q += 4 + ll;
                uint32_t fl = read_u32_at(b, q); q += 4 + fl;
                q += 1;
                return q - p;
            }

            default:
                return 1;
            }
        }

        std::vector<uint8_t> peephole(const std::vector<uint8_t>& code) {
            std::vector<Instr> instrs;
            size_t p = 0;
            while (p < code.size()) {
                size_t len = instr_len(code, p);
                if (p + len > code.size()) len = code.size() - p;
                instrs.push_back({ p, len, code[p] });
                p += len;
            }

            std::unordered_set<size_t> labels;
            for (auto& in : instrs) labels.insert(in.start);

            std::unordered_map<size_t, size_t> off_to_idx;
            for (size_t i = 0; i < instrs.size(); ++i)
                off_to_idx[instrs[i].start] = i;

            std::vector<bool> keep(instrs.size(), true);

            auto target_idx = [&](size_t at_off) -> size_t {
                auto it = off_to_idx.find(at_off);
                return (it == off_to_idx.end()) ? SIZE_MAX : it->second;
                };

            for (size_t i = 0; i < instrs.size(); ++i) {
                if (!keep[i]) continue;
                const auto& in = instrs[i];
                uint8_t op = in.op;

                if (op == (uint8_t)Op::JMP) {
                    uint32_t t = read_u32_at(code, in.start + 1);
                    size_t nxt = in.start + in.len;
                    if (t == nxt) {
                        keep[i] = false;
                        continue;
                    }
                    size_t ti = target_idx(t);
                    if (ti != SIZE_MAX && ti < instrs.size()) {
                        const auto& tgt = instrs[ti];
                        if (tgt.op == (uint8_t)Op::JMP && ti != i) {
                            uint32_t t2 = read_u32_at(code, tgt.start + 1);
                        }
                    }
                    continue;
                }

                if (op == (uint8_t)Op::PUSH) {
                    size_t nxt = in.start + in.len;
                    size_t ni = target_idx(nxt);
                    if (ni != SIZE_MAX && ni < instrs.size()) {
                        if (instrs[ni].op == (uint8_t)Op::POP && keep[ni]) {
                            keep[i] = false;
                            keep[ni] = false;
                            continue;
                        }
                    }
                    continue;
                }

                bool is_term = (op == (uint8_t)Op::RET ||
                    op == (uint8_t)Op::HALT ||
                    op == (uint8_t)Op::JMP);
                if (!is_term) continue;

                size_t j = i + 1;
                while (j < instrs.size()) {
                    size_t off = instrs[j].start;
                    bool is_label = false;
                    for (auto& other : instrs) {
                        if (!keep[&other - &instrs[0]]) continue;
                        uint8_t oop = other.op;
                        if (oop == (uint8_t)Op::JMP ||
                            oop == (uint8_t)Op::JZ ||
                            oop == (uint8_t)Op::JNZ) {
                            uint32_t t = read_u32_at(code, other.start + 1);
                            if (t == off) { is_label = true; break; }
                        }
                        if (oop == (uint8_t)Op::PUSH_HANDLER) {
                            uint32_t t = read_u32_at(code, other.start + 1);
                            if (t == off) { is_label = true; break; }
                        }
                    }
                    if (is_label) break;
                    keep[j] = false;
                    ++j;
                }
            }

            std::vector<uint8_t> out;
            std::vector<size_t> old_start;
            std::vector<size_t> new_start;

            for (size_t i = 0; i < instrs.size(); ++i) {
                if (!keep[i]) continue;
                old_start.push_back(instrs[i].start);
                new_start.push_back(out.size());
                out.insert(out.end(),
                    code.begin() + instrs[i].start,
                    code.begin() + instrs[i].start + instrs[i].len);
            }

            std::unordered_map<size_t, size_t> old_to_new;
            for (size_t i = 0; i < old_start.size(); ++i)
                old_to_new[old_start[i]] = new_start[i];

            size_t q = 0;
            while (q < out.size()) {
                size_t len = instr_len(out, q);
                uint8_t op = out[q];
                if (op == (uint8_t)Op::JMP ||
                    op == (uint8_t)Op::JZ ||
                    op == (uint8_t)Op::JNZ ||
                    op == (uint8_t)Op::PUSH_HANDLER) {
                    uint32_t old_t = read_u32_at(out, q + 1);
                    auto it = old_to_new.find((size_t)old_t);
                    if (it != old_to_new.end()) {
                        write_u32_at(out, q + 1, (uint32_t)it->second);
                    }
                }
                q += len;
            }

            return out;
        }

    }

    std::vector<uint8_t> Optimizer::run(const std::vector<uint8_t>& code, int opt_level) {
        if (opt_level < 2) return code;
        return peephole(code);
    }

}