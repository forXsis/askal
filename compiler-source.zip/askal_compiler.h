/**
 * Copyright 2026 forXsis
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /** Contact me!
 * Gmail: forxtrees@gmail.com
 * Git: https://github.com/forXsis
 * Askal GitHub project: https://github.com/forXsis/askal
 */

#pragma once
#include <string>

namespace askal {

    bool compile_file(const std::string& input,
        const std::string& output,
        bool verbose,
        bool dump = false,
        int opt_level = 1);

}