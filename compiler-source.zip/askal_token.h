/**
 * Copyright 2026 forXsis
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /** Contact me!
 * Gmail: forxtrees@gmail.com
 * Git: https://github.com/forXsis
 * Askal GitHub project: https://github.com/forXsis/askal
 */

#pragma once
#include <string>
#include <cstdint>

namespace askal {

    enum class TokKind {
        NUMBER,
        FLOAT,
        STRING,
        HEX,
        BIN,
        TRUE_,
        FALSE_,
        NULL_,

        IDENT,
        KW_VAR,
        KW_FUN,
        KW_CLASS,
        KW_RETURN,
        ARROW_RET,
        KW_IF,
        KW_ELSE,
        KW_WHILE,
        KW_FOR,
        KW_USE,
        KW_BREAK,
        KW_CONTINUE,
        KW_SWITCH,
        KW_CASE,
        KW_DEFAULT,
        KW_INCLUDE,
        KW_TRY,
        KW_CATCH,
        KW_FINALLY,
        KW_THROW,

        TY_STR,
        TY_BOOL,
        TY_FLOAT,
        TY_INT8,
        TY_INT16,
        TY_INT32,
        TY_INT64,
        TY_INT,
        TY_BIN,
        TY_HEX,
        TY_AUTO,
        TY_ARRAY,
        TY_LIST,
        TY_DICT,

        ASSIGN,
        PLUS, MINUS, STAR, SLASH, PERCENT,
        LT, GT, LE, GE, EQ, NE,
        AND_OP, OR_OP, NOT_OP,
        ARROW,
        LPAREN, RPAREN,
        LBRACE, RBRACE,
        LBRACKET, RBRACKET,
        SEMI, COMMA, COLON,
        PLUS_ASSIGN,
        MINUS_ASSIGN,
        STAR_ASSIGN,
        SLASH_ASSIGN,
        PERCENT_ASSIGN,
        PLUS_PLUS,
        MINUS_MINUS,
        QUESTION,
        END
    };

    struct Token {
        TokKind     kind;
        std::string value;
        uint32_t    line = 1;
        uint32_t    col = 1;
    };

}