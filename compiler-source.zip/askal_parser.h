/**
 * Copyright 2026 forXsis
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /** Contact me!
 * Gmail: forxtrees@gmail.com
 * Git: https://github.com/forXsis
 * Askal GitHub project: https://github.com/forXsis/askal
 */

#pragma once
#include "askal_token.h"
#include "askal_ast.h"
#include <vector>

namespace askal {

    class Parser {
    public:
        explicit Parser(std::vector<Token> tokens);
        Program parse();

    private:
        std::vector<Token> toks_;
        size_t pos_ = 0;

        const Token& peek(int off = 0) const;
        const Token& cur() const { return peek(0); }
        bool   check(TokKind k) const;
        bool   match(TokKind k);
        const Token& consume();
        const Token& expect(TokKind k, const std::string& what);
        [[noreturn]] void error(const std::string& msg) const;

        StmtPtr parse_statement();
        StmtPtr parse_var_decl();
        StmtPtr parse_fun_decl();
        StmtPtr parse_class_decl();
        StmtPtr parse_return();
        StmtPtr parse_if();
        StmtPtr parse_switch();
        StmtPtr parse_while();
        StmtPtr parse_for();
        StmtPtr parse_assign_or_expr();
        StmtPtr parse_try();
        StmtPtr parse_throw();
        std::vector<StmtPtr> parse_block();

        ExprPtr parse_expr();
        ExprPtr parse_logic_or();
        ExprPtr parse_logic_and();
        ExprPtr parse_equality();
        ExprPtr parse_comparison();
        ExprPtr parse_term();
        ExprPtr parse_factor();
        ExprPtr parse_unary();
        ExprPtr parse_primary();
        ExprPtr parse_postfix(ExprPtr base);
        ExprPtr parse_list_literal();
        ExprPtr parse_dict_literal();
        ExprPtr parse_ternary();

        DataType parse_type();
        std::vector<FunDecl::Arg> parse_args();
    };

}