/**
 * Copyright 2026 forXsis
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /** Contact me!
 * Gmail: forxtrees@gmail.com
 * Git: https://github.com/forXsis
 * Askal GitHub project: https://github.com/forXsis/askal
 */

#include "askal_compiler.h"
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

#ifdef _WIN32
#include <windows.h>
#endif

static void setup_console() {
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif
}

static void print_usage() {
    std::cout <<
        R"(Askal Compiler v2.0.0
=====================================================
Usage:
  askal-compiler --c <file.akl>           Compile file
  askal-compiler --c <file.akl> -o <out>  Compile to custom path
  askal-compiler --c <file.akl> -v        Verbose
  askal-compiler --h                      Show help
  askal-compiler --v                      Show version

Options:
  --c, -c        compile
  -o <path>      output path (default: alongside source as .aklp)
  -v             verbose
  --h, -h        help
  --v, -v        version
  -d, --dump     dump compiled bytecode as hex
  -O0            no optimization
  -O1            constant folding (default)
  -O2            constant folding + peephole
)";
}

static std::string default_output(const std::string& input) {
    auto slash = input.find_last_of("/\\");
    auto dot = input.find_last_of('.');
    std::string base = (dot == std::string::npos ||
        (slash != std::string::npos && dot < slash))
        ? input
        : input.substr(0, dot);
    return base + ".aklp";
}

int main(int argc, char** argv) {
    setup_console();

    if (argc < 2) { print_usage(); return 1; }

    std::string cmd = argv[1];

    if (cmd == "--h" || cmd == "-h" || cmd == "--help") {
        print_usage();
        return 0;
    }
    if (cmd == "--v" || cmd == "-v" || cmd == "--version") {
        std::cout << "Askal Compiler v1.8.1\n";
        return 0;
    }

    if (cmd == "--c" || cmd == "-c") {
        if (argc < 3) {
            std::cerr << "Error: no input file\n";
            return 1;
        }

        std::string input = argv[2];
        std::string output = default_output(input);
        bool        verbose = false;
        bool        dump = false;
        int         opt_level = 1;

        for (int i = 3; i < argc; ++i) {
            std::string a = argv[i];
            if (a == "-o" && i + 1 < argc) {
                output = argv[++i];
            }
            else if (a == "-v" || a == "--v") {
                verbose = true;
            }
            else if (a == "--dump" || a == "-d") {
                dump = true;
            }
            else if (a == "-O0") { opt_level = 0; }
            else if (a == "-O1") { opt_level = 1; }
            else if (a == "-O2") { opt_level = 2; }
            else {
                std::cerr << "Error: unknown option '" << a << "'\n";
                return 1;
            }
        }

        bool ok = askal::compile_file(input, output, verbose, dump, opt_level);
        return ok ? 0 : 1;
    }

    std::cerr << "Error: unknown command '" << cmd << "'\n";
    print_usage();
    return 1;
}