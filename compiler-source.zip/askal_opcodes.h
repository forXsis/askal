/**
 * Copyright 2026 forXsis
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /** Contact me!
 * Gmail: forxtrees@gmail.com
 * Git: https://github.com/forXsis
 * Askal GitHub project: https://github.com/forXsis/askal
 */

#pragma once
#include <cstdint>

namespace askal {

    enum class Op : uint8_t {
        HALT = 0x00,
        NOP = 0x01,
        START_DATA = 0x02,
        END_DATA = 0x03,

        T_STR = 0x10,
        T_BOOL = 0x11,
        T_FLOAT = 0x12,
        T_INT8 = 0x13,
        T_INT16 = 0x14,
        T_INT32 = 0x15,
        T_INT64 = 0x16,
        T_INT = 0x17,
        T_NULL = 0x18,
        T_BIN = 0x19,
        T_HEX = 0x1A,

        SEC_VARS = 0x20,
        SEC_FUNCS = 0x21,
        SEC_CLASSES = 0x22,
        SEC_MAIN = 0x23,
        SEC_LIBS = 0x24,

        DECL_VAR = 0x30,
        DECL_FUN = 0x31,
        DECL_CLASS = 0x32,
        DECL_ARG = 0x33,
        DECL_END = 0x34,

        PUSH = 0x40,
        POP = 0x41,
        DUP = 0x42,
        SWAP = 0x43,

        LOAD_VAR = 0x50,
        STORE_VAR = 0x51,

        CALL = 0x60,
        RET = 0x61,
        CALL_NATIVE = 0x62,

        NEW_CLASS = 0x70,
        LOAD_FIELD = 0x71,
        STORE_FIELD = 0x72,
        CALL_METHOD = 0x73,
        FREE_OBJECT = 0x74,

        ADD = 0x80,
        SUB = 0x81,
        MUL = 0x82,
        DIV = 0x83,
        MOD = 0x84,
        NEG = 0x85,

        EQ = 0x90,
        NE = 0x91,
        LT = 0x92,
        GT = 0x93,
        LE = 0x94,
        GE = 0x95,

        AND = 0xA0,
        OR = 0xA1,
        NOT = 0xA2,

        JMP = 0xB0,
        JZ = 0xB1,
        JNZ = 0xB2,
        PUSH_HANDLER = 0xB3,
        POP_HANDLER = 0xB4,
        THROW = 0xB5,
        THREAD_RUN = 0xD0,
        THREAD_AWAIT = 0xD1,
        THREAD_ALIVE = 0xD2,
        THREAD_KILL = 0xD3,

        NEW_ARRAY = 0xC0,
        NEW_LIST = 0xC1,
        NEW_DICT = 0xC2,
        INDEX_GET = 0xC3,
        INDEX_SET = 0xC4,
        LEN = 0xC5,
        PUSH_ITEM = 0xC6,
        POP_ITEM = 0xC7,
        LIST_CLEAR = 0xC8,
        LIST_INSERT = 0xC9,
        LIST_REMOVE = 0xCA,
        DICT_HAS = 0xCB,
        DICT_KEYS = 0xCC,
        DICT_REMOVE = 0xCD,
        DICT_VALUES = 0xCE,
        ARRAY_FILL = 0xCF,
    };

    enum class DataType : uint8_t {
        STR = 0x10,
        BOOL = 0x11,
        FLOAT = 0x12,
        INT8 = 0x13,
        INT16 = 0x14,
        INT32 = 0x15,
        INT64 = 0x16,
        INT = 0x17,
        NULL_ = 0x18,
        BIN = 0x19,
        HEX = 0x1A,
        AUTO = 0x1B,
        OBJECT = 0x1C,
        ARRAY = 0x1D,
        LIST = 0x1E,
        DICT = 0x1F,
    };

    inline uint32_t fixed_size(DataType t) {
        switch (t) {
        case DataType::BOOL:  return 1;
        case DataType::INT8:  return 1;
        case DataType::INT16: return 2;
        case DataType::INT32: return 4;
        case DataType::INT64: return 8;
        case DataType::FLOAT: return 8;
        case DataType::NULL_: return 0;
        case DataType::AUTO: return 280;
        case DataType::OBJECT: return 8;
        case DataType::ARRAY: return 8;
        case DataType::LIST:  return 8;
        case DataType::DICT:  return 8;
        default: return 0;
        }
    }

}