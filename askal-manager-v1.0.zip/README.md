# Askal v1.0

The first public release of **Askal**, a lightweight compiled programming language with its own compiler, bytecode format (`.aklp`) and virtual machine.

This version represents the initial working implementation of the language. While the feature set is intentionally small, it already allows writing simple programs, declaring variables and evaluating arithmetic expressions.

---

## Features

### Output

Askal currently supports two built-in output instructions.

Print with a newline:

```akl
print < "Hello, World!";
```

Print without a newline:

```akl
println < "Hello, ";
println < "User!";
```

---

### Variables

Static typing is currently supported.

Available types:

- `int`
- `float`
- `str`
- `bool`

Example:

```akl
var int age = 18;
var float weight = 74.5;
var str name = "Username";
var bool active = false;
```

---

### Arithmetic

Basic arithmetic operators are implemented.

Supported operations:

```text
+
-
*
/
```

Operator precedence is handled automati