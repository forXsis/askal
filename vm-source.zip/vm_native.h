// Askal — https://github.com/forXsis/askal
// Copyright (c) 2026 forXsis <forxtrees@gmail.com>
// Licensed under the Apache License, Version 2.0.

#pragma once
#include "vm.h"
#include "askal_plugin.h"
#include <string>
#include <vector>
#include <unordered_map>

namespace askal {

    class NativeRegistry {
    public:
        bool load_all(const std::vector<std::string>& libs);

        Value call(const std::string& lib,
            const std::string& fn,
            const std::vector<Value>& args);

        static bool log_out;

    private:
        struct Entry {
            void* handle = nullptr;
            AskDbFn db = nullptr;
        };

        std::unordered_map<std::string, Entry> loaded;

        bool load_one(const std::string& name);

        static std::string lib_path(const std::string& name);
        static std::vector<uint8_t> pack_args(const std::vector<Value>& args);
        static Value unpack_value(const std::vector<uint8_t>& buf, size_t& pos);
    };

}