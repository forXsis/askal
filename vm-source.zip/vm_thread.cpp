// Askal — https://github.com/forXsis/askal
// Copyright (c) 2026 forXsis <forxtrees@gmail.com>
// Licensed under the Apache License, Version 2.0.

#include "vm.h"
#include <stdexcept>
#include <cstring>
#include <string>
#include <vector>

#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#endif

namespace askal {

    static void blob_u8(std::string& s, uint8_t x) { s.push_back((char)x); }
    static void blob_u32(std::string& s, uint32_t x) {
        for (int i = 0; i < 4; ++i) s.push_back((char)((x >> (i * 8)) & 0xFF));
    }
    static void blob_u64(std::string& s, uint64_t x) {
        for (int i = 0; i < 8; ++i) s.push_back((char)((x >> (i * 8)) & 0xFF));
    }

    std::string VM::pack_value(const Value& v) {
        std::string s;
        switch (v.type) {
        case DataType::INT8:
        case DataType::INT16:
        case DataType::INT32:
        case DataType::INT64:
        case DataType::INT: {
            blob_u8(s, (uint8_t)DataType::INT64);
            blob_u64(s, (uint64_t)v.i);
            break;
        }
        case DataType::FLOAT: {
            blob_u8(s, (uint8_t)DataType::FLOAT);
            uint64_t bits; std::memcpy(&bits, &v.f, 8);
            blob_u64(s, bits);
            break;
        }
        case DataType::BOOL: {
            blob_u8(s, (uint8_t)DataType::BOOL);
            blob_u8(s, v.b ? 1 : 0);
            break;
        }
        case DataType::STR:
        case DataType::BIN:
        case DataType::HEX: {
            blob_u8(s, (uint8_t)v.type);
            blob_u32(s, (uint32_t)v.s.size());
            s.append(v.s);
            break;
        }
        case DataType::NULL_:
        default:
            blob_u8(s, (uint8_t)DataType::NULL_);
            break;
        }
        return s;
    }

    Value VM::unpack_value(const std::string& blob) {
        Value v;
        size_t p = 0;
        if (p >= blob.size()) { v.type = DataType::NULL_; return v; }

        v.type = (DataType)(uint8_t)blob[p++];
        auto take_u64 = [&]() -> uint64_t {
            uint64_t x = 0;
            for (int i = 0; i < 8; ++i) x |= (uint64_t)(uint8_t)blob[p++] << (i * 8);
            return x;
            };
        auto take_u32 = [&]() -> uint32_t {
            uint32_t x = 0;
            for (int i = 0; i < 4; ++i) x |= (uint32_t)(uint8_t)blob[p++] << (i * 8);
            return x;
            };

        switch (v.type) {
        case DataType::INT8:
        case DataType::INT16:
        case DataType::INT32:
        case DataType::INT64:
        case DataType::INT: {
            v.i = (int64_t)take_u64();
            break;
        }
        case DataType::FLOAT: {
            uint64_t bits = take_u64();
            std::memcpy(&v.f, &bits, 8);
            break;
        }
        case DataType::BOOL: {
            v.b = (uint8_t)blob[p++] != 0;
            v.i = v.b ? 1 : 0;
            break;
        }
        case DataType::STR:
        case DataType::BIN:
        case DataType::HEX: {
            uint32_t len = take_u32();
            v.s.assign(blob.data() + p, len);
            p += len;
            break;
        }
        case DataType::NULL_:
        default:
            v.type = DataType::NULL_;
            break;
        }
        return v;
    }

#ifdef _WIN32

    static std::wstring current_exe_path() {
        wchar_t buf[MAX_PATH];
        DWORD n = GetModuleFileNameW(NULL, buf, MAX_PATH);
        if (n == 0 || n == MAX_PATH) throw std::runtime_error("GetModuleFileNameW failed");
        return std::wstring(buf, n);
    }

    static std::wstring widen(const std::string& s) {
        if (s.empty()) return L"";
        int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), NULL, 0);
        std::wstring w(n, 0);
        MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), &w[0], n);
        return w;
    }

    Value VM::spawn_thread(uint32_t func_id, const Value& args) {
        if (current_aklp_path.empty()) {
            throw std::runtime_error("spawn_thread: current_aklp_path is empty "
                "(VM must be started with --r <file.aklp>)");
        }

        std::wstring exe = current_exe_path();
        std::wstring aklp = widen(current_aklp_path);

        SECURITY_ATTRIBUTES sa{};
        sa.nLength = sizeof(sa);
        sa.bInheritHandle = TRUE;
        sa.lpSecurityDescriptor = NULL;

        HANDLE child_stdin_r = NULL, child_stdin_w = NULL;
        HANDLE child_stdout_r = NULL, child_stdout_w = NULL;

        if (!CreatePipe(&child_stdin_r, &child_stdin_w, &sa, 0))
            throw std::runtime_error("spawn_thread: CreatePipe(stdin) failed");
        if (!SetHandleInformation(child_stdin_w, HANDLE_FLAG_INHERIT, 0))
            throw std::runtime_error("spawn_thread: SetHandleInformation(stdin_w) failed");

        if (!CreatePipe(&child_stdout_r, &child_stdout_w, &sa, 0))
            throw std::runtime_error("spawn_thread: CreatePipe(stdout) failed");
        if (!SetHandleInformation(child_stdout_r, HANDLE_FLAG_INHERIT, 0))
            throw std::runtime_error("spawn_thread: SetHandleInformation(stdout_r) failed");

        std::wstring cmdline = L"\"" + exe + L"\" --call-func " +
            std::to_wstring(func_id) + L" --aklp \"" + aklp + L"\"";
        std::vector<wchar_t> cmdbuf(cmdline.begin(), cmdline.end());
        cmdbuf.push_back(L'\0');

        STARTUPINFOW si{};
        si.cb = sizeof(si);
        si.dwFlags = STARTF_USESTDHANDLES;
        si.hStdInput = child_stdin_r;
        si.hStdOutput = child_stdout_w;
        si.hStdError = GetStdHandle(STD_ERROR_HANDLE);

        PROCESS_INFORMATION pi{};

        BOOL ok = CreateProcessW(
            NULL,
            cmdbuf.data(),
            NULL, NULL,
            TRUE,
            CREATE_NO_WINDOW,
            NULL, NULL,
            &si, &pi);

        CloseHandle(child_stdin_r);
        CloseHandle(child_stdout_w);

        if (!ok) {
            CloseHandle(child_stdin_w);
            CloseHandle(child_stdout_r);
            throw std::runtime_error("spawn_thread: CreateProcessW failed, err=" +
                std::to_string(GetLastError()));
        }

        CloseHandle(pi.hThread);

        std::string blob = pack_value(args);
        uint32_t len = (uint32_t)blob.size();
        std::string header;
        for (int i = 0; i < 4; ++i) header.push_back((char)((len >> (i * 8)) & 0xFF));

        DWORD written = 0;
        if (len > 0) {
            WriteFile(child_stdin_w, header.data(), 4, &written, NULL);
            WriteFile(child_stdin_w, blob.data(), (DWORD)blob.size(), &written, NULL);
        }
        else {
            WriteFile(child_stdin_w, header.data(), 4, &written, NULL);
        }
        CloseHandle(child_stdin_w);

        auto th = std::make_shared<VMThread>();
        th->handle = next_thread_handle++;
        th->func_id = func_id;
        th->args_blob = std::move(blob);
        th->process = (void*)pi.hProcess;
        th->stdin_w = nullptr;
        th->stdout_r = (void*)child_stdout_r;
        th->finished = false;

        threads[th->handle] = th;

        return Value::make_int((int64_t)th->handle);
    }

    Value VM::await_thread(uint64_t handle) {
        auto it = threads.find(handle);
        if (it == threads.end())
            throw std::runtime_error("await_thread: unknown handle " + std::to_string(handle));
        auto th = it->second;

        if (th->finished) return th->result;

        HANDLE hproc = (HANDLE)th->process;
        HANDLE hout = (HANDLE)th->stdout_r;

        std::string buf;
        char tmp[4096];
        DWORD got = 0;
        while (ReadFile(hout, tmp, sizeof(tmp), &got, NULL) && got > 0) {
            buf.append(tmp, got);
        }

        WaitForSingleObject(hproc, INFINITE);
        DWORD exit_code = 0;
        GetExitCodeProcess(hproc, &exit_code);

        CloseHandle(hproc);
        CloseHandle(hout);
        th->process = nullptr;
        th->stdout_r = nullptr;
        th->exit_code = (int)exit_code;
        th->finished = true;

        if (buf.size() < 4) {
            th->result = Value::make_null();
            return th->result;
        }
        uint32_t len = 0;
        for (int i = 0; i < 4; ++i) len |= (uint32_t)(uint8_t)buf[i] << (i * 8);
        if (buf.size() < 4 + (size_t)len) {
            th->result = Value::make_null();
            return th->result;
        }
        std::string blob = buf.substr(4, len);
        th->result = unpack_value(blob);
        return th->result;
    }

    bool VM::thread_alive(uint64_t handle) {
        auto it = threads.find(handle);
        if (it == threads.end()) return false;
        auto th = it->second;
        if (th->finished) return false;
        if (!th->process) return false;
        HANDLE hproc = (HANDLE)th->process;
        DWORD r = WaitForSingleObject(hproc, 0);
        if (r == WAIT_TIMEOUT) return true;
        return false;
    }

    void VM::thread_kill(uint64_t handle) {
        auto it = threads.find(handle);
        if (it == threads.end()) return;
        auto th = it->second;
        if (th->finished) return;
        if (!th->process) return;
        HANDLE hproc = (HANDLE)th->process;
        TerminateProcess(hproc, 1);
        WaitForSingleObject(hproc, INFINITE);
        CloseHandle(hproc);
        if (th->stdout_r) { CloseHandle((HANDLE)th->stdout_r); th->stdout_r = nullptr; }
        th->process = nullptr;
        th->killed = true;
        th->finished = true;
        th->result = Value::make_null();
    }

#else

#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <signal.h>
#include <limits.h>

static std::string current_exe_path_linux() {
    char buf[PATH_MAX];
    ssize_t n = readlink("/proc/self/exe", buf, sizeof(buf) - 1);
    if (n <= 0) throw std::runtime_error("readlink /proc/self/exe failed");
    buf[n] = '\0';
    return std::string(buf, n);
}

Value VM::spawn_thread(uint32_t func_id, const Value& args) {
    if (current_aklp_path.empty()) {
        throw std::runtime_error("spawn_thread: current_aklp_path is empty "
            "(VM must be started with --r <file.aklp>)");
    }

    std::string exe = current_exe_path_linux();

    int in_pipe[2];
    int out_pipe[2];

    if (pipe(in_pipe) != 0)
        throw std::runtime_error("spawn_thread: pipe(stdin) failed");
    if (pipe(out_pipe) != 0) {
        close(in_pipe[0]); close(in_pipe[1]);
        throw std::runtime_error("spawn_thread: pipe(stdout) failed");
    }

    pid_t pid = fork();
    if (pid < 0) {
        close(in_pipe[0]); close(in_pipe[1]);
        close(out_pipe[0]); close(out_pipe[1]);
        throw std::runtime_error("spawn_thread: fork failed");
    }

    if (pid == 0) {
        dup2(in_pipe[0], STDIN_FILENO);
        dup2(out_pipe[1], STDOUT_FILENO);

        close(in_pipe[0]);  close(in_pipe[1]);
        close(out_pipe[0]); close(out_pipe[1]);

        std::string fid_s = std::to_string(func_id);
        execl(exe.c_str(), exe.c_str(),
            "--call-func", fid_s.c_str(),
            "--aklp", current_aklp_path.c_str(),
            (char*)NULL);
        _exit(127);
    }

    close(in_pipe[0]);
    close(out_pipe[1]);

    std::string blob = pack_value(args);
    uint32_t len = (uint32_t)blob.size();
    char header[4] = {
        (char)((len) & 0xFF),
        (char)((len >> 8) & 0xFF),
        (char)((len >> 16) & 0xFF),
        (char)((len >> 24) & 0xFF)
    };

    {
        ssize_t w = write(in_pipe[1], header, 4);
        (void)w;
        if (len > 0) {
            w = write(in_pipe[1], blob.data(), blob.size());
            (void)w;
        }
    }
    close(in_pipe[1]);

    auto th = std::make_shared<VMThread>();
    th->handle = next_thread_handle++;
    th->func_id = func_id;
    th->args_blob = std::move(blob);
    th->pid = (int)pid;
    th->stdin_w = -1;
    th->stdout_r = out_pipe[0];
    th->finished = false;

    threads[th->handle] = th;
    return Value::make_int((int64_t)th->handle);
}

Value VM::await_thread(uint64_t handle) {
    auto it = threads.find(handle);
    if (it == threads.end())
        throw std::runtime_error("await_thread: unknown handle " + std::to_string(handle));
    auto th = it->second;

    if (th->finished) return th->result;

    std::string buf;
    char tmp[4096];
    ssize_t got;
    while ((got = read(th->stdout_r, tmp, sizeof(tmp))) > 0) {
        buf.append(tmp, got);
    }
    close(th->stdout_r);
    th->stdout_r = -1;

    int status = 0;
    waitpid(th->pid, &status, 0);
    int exit_code = WIFEXITED(status) ? WEXITSTATUS(status) : -1;

    th->exit_code = exit_code;
    th->finished = true;

    if (buf.size() < 4) {
        th->result = Value::make_null();
        return th->result;
    }
    uint32_t len = 0;
    for (int i = 0; i < 4; ++i) len |= (uint32_t)(uint8_t)buf[i] << (i * 8);
    if (buf.size() < 4 + (size_t)len) {
        th->result = Value::make_null();
        return th->result;
    }
    std::string blob = buf.substr(4, len);
    th->result = unpack_value(blob);
    return th->result;
}

bool VM::thread_alive(uint64_t handle) {
    auto it = threads.find(handle);
    if (it == threads.end()) return false;
    auto th = it->second;
    if (th->finished) return false;
    if (th->pid <= 0) return false;
    int status = 0;
    pid_t r = waitpid(th->pid, &status, WNOHANG);
    if (r == 0) return true;
    return false;
}

void VM::thread_kill(uint64_t handle) {
    auto it = threads.find(handle);
    if (it == threads.end()) return;
    auto th = it->second;
    if (th->finished) return;
    if (th->pid > 0) {
        kill(th->pid, SIGTERM);
        int status;
        waitpid(th->pid, &status, 0);
    }
    if (th->stdout_r >= 0) {
        close(th->stdout_r);
        th->stdout_r = -1;
    }
    th->pid = -1;
    th->killed = true;
    th->finished = true;
    th->result = Value::make_null();
}

#endif

}