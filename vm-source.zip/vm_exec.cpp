// Askal — https://github.com/forXsis/askal
// Copyright (c) 2026 forXsis <forxtrees@gmail.com>
// Licensed under the Apache License, Version 2.0.

#include "vm_exec.h"
#include <stdexcept>
#include <cstring>
#include <cmath>
#include <iostream>
#include <sstream>

namespace askal {

    Exec::Exec(VM& vm)
        : vm_(vm), stack_(vm), memory_(vm), frames_(vm) {
        native_.load_all(vm.used_libs);
    }

    uint8_t Exec::read_byte() {
        if (!vm_.cur_code || vm_.ip >= vm_.cur_code->size())
            throw std::runtime_error("Unexpected end of code (read_byte)");
        return (*vm_.cur_code)[vm_.ip++];
    }

    int64_t Exec::read_signed(int bytes) {
        if (!vm_.cur_code || vm_.ip + bytes > vm_.cur_code->size())
            throw std::runtime_error("Unexpected end of code (read_signed)");
        int64_t v = 0;
        for (int i = 0; i < bytes; ++i)
            v |= (int64_t)(*vm_.cur_code)[vm_.ip++] << (i * 8);
        if (bytes < 8) {
            int shift = 64 - bytes * 8;
            v = (v << shift) >> shift;
        }
        return v;
    }

    double Exec::read_double() {
        if (!vm_.cur_code || vm_.ip + 8 > vm_.cur_code->size())
            throw std::runtime_error("Unexpected end of code (read_double)");
        double d;
        std::memcpy(&d, vm_.cur_code->data() + vm_.ip, 8);
        vm_.ip += 8;
        return d;
    }

    uint32_t Exec::read_u32() {
        if (!vm_.cur_code || vm_.ip + 4 > vm_.cur_code->size())
            throw std::runtime_error("Unexpected end of code (read_u32)");
        uint32_t v = 0;
        for (int i = 0; i < 4; ++i)
            v |= (uint32_t)(*vm_.cur_code)[vm_.ip++] << (i * 8);
        return v;
    }

    std::string Exec::read_str(uint32_t len) {
        if (!vm_.cur_code || vm_.ip + len > vm_.cur_code->size())
            throw std::runtime_error("Unexpected end of code (read_str)");
        std::string s(reinterpret_cast<const char*>(vm_.cur_code->data() + vm_.ip), len);
        vm_.ip += len;
        return s;
    }

    Value Exec::read_literal(DataType t) {
        Value v; v.type = t;
        switch (t) {
        case DataType::INT8:  v.i = read_signed(1); break;
        case DataType::INT16: v.i = read_signed(2); break;
        case DataType::INT32: v.i = read_signed(4); break;
        case DataType::INT64:
        case DataType::INT:   v.i = read_signed(8); break;
        case DataType::FLOAT: v.f = read_double(); break;
        case DataType::BOOL:  v.b = read_byte() != 0; v.i = v.b ? 1 : 0; break;
        case DataType::STR:
        case DataType::BIN:
        case DataType::HEX: {
            uint32_t len = read_u32();
            v.s = read_str(len);
            break;
        }
        case DataType::NULL_: break;
        }
        return v;
    }


    Value Exec::do_arith(uint8_t op) {
        Value b = stack_.pop();
        Value a = stack_.pop();
        Value r;

        if (op == (uint8_t)Op::ADD &&
            (a.type == DataType::STR || b.type == DataType::STR)) {
            r.type = DataType::STR;
            std::string sa, sb;

            auto to_str = [](const Value& v) -> std::string {
                std::ostringstream o;
                switch (v.type) {
                case DataType::STR:
                case DataType::BIN:
                case DataType::HEX:   o << v.s; break;
                case DataType::BOOL:  o << (v.b ? "true" : "false"); break;
                case DataType::FLOAT: o << v.f; break;
                case DataType::NULL_: o << "null"; break;
                case DataType::INT8:
                case DataType::INT16:
                case DataType::INT32:
                case DataType::INT64:
                case DataType::INT:   o << v.i; break;
                case DataType::OBJECT:o << "<object #" << v.i << ">"; break;
                default: break;
                }
                return o.str();
                };

            r.s = to_str(a) + to_str(b);
            return r;
        }

        bool use_float = VM::is_float_type(a.type) || VM::is_float_type(b.type);

        if (use_float) {
            double da = VM::is_float_type(a.type) ? a.f : (double)a.i;
            double db = VM::is_float_type(b.type) ? b.f : (double)b.i;
            double res = 0;
            switch (op) {
            case (uint8_t)Op::ADD: res = da + db; break;
            case (uint8_t)Op::SUB: res = da - db; break;
            case (uint8_t)Op::MUL: res = da * db; break;
            case (uint8_t)Op::DIV: res = (db != 0.0) ? da / db : 0.0; break;
            case (uint8_t)Op::MOD: res = (db != 0.0) ? std::fmod(da, db) : 0.0; break;
            }
            r.type = DataType::FLOAT;
            r.f = res;
        }
        else {
            int64_t ia = a.i, ib = b.i, res = 0;
            switch (op) {
            case (uint8_t)Op::ADD: res = ia + ib; break;
            case (uint8_t)Op::SUB: res = ia - ib; break;
            case (uint8_t)Op::MUL: res = ia * ib; break;
            case (uint8_t)Op::DIV: res = (ib != 0) ? ia / ib : 0; break;
            case (uint8_t)Op::MOD: res = (ib != 0) ? ia % ib : 0; break;
            }
            r.type = DataType::INT64;
            r.i = res;
        }
        return r;
    }

    Value Exec::do_cmp(uint8_t op) {
        Value b = stack_.pop();
        Value a = stack_.pop();

        if (a.type == DataType::STR && b.type == DataType::STR) {
            int cmp = a.s.compare(b.s);
            bool res = false;
            switch (op) {
            case (uint8_t)Op::EQ: res = (cmp == 0); break;
            case (uint8_t)Op::NE: res = (cmp != 0); break;
            case (uint8_t)Op::LT: res = (cmp < 0); break;
            case (uint8_t)Op::GT: res = (cmp > 0); break;
            case (uint8_t)Op::LE: res = (cmp <= 0); break;
            case (uint8_t)Op::GE: res = (cmp >= 0); break;
            }
            return Value::make_bool(res);
        }

        bool use_float = VM::is_float_type(a.type) || VM::is_float_type(b.type);
        bool res = false;
        if (use_float) {
            double da = VM::is_float_type(a.type) ? a.f : (double)a.i;
            double db = VM::is_float_type(b.type) ? b.f : (double)b.i;
            switch (op) {
            case (uint8_t)Op::EQ: res = da == db; break;
            case (uint8_t)Op::NE: res = da != db; break;
            case (uint8_t)Op::LT: res = da < db; break;
            case (uint8_t)Op::GT: res = da > db; break;
            case (uint8_t)Op::LE: res = da <= db; break;
            case (uint8_t)Op::GE: res = da >= db; break;
            }
        }
        else {
            int64_t ia = a.i, ib = b.i;
            switch (op) {
            case (uint8_t)Op::EQ: res = ia == ib; break;
            case (uint8_t)Op::NE: res = ia != ib; break;
            case (uint8_t)Op::LT: res = ia < ib; break;
            case (uint8_t)Op::GT: res = ia > ib; break;
            case (uint8_t)Op::LE: res = ia <= ib; break;
            case (uint8_t)Op::GE: res = ia >= ib; break;
            }
        }
        return Value::make_bool(res);
    }

    void Exec::run() {
        stop_depth_ = SIZE_MAX;
        run_impl();
    }

    void Exec::run_until(size_t stop_depth) {
        stop_depth_ = stop_depth;
        run_impl();
    }

    void Exec::run_impl() {
        while (vm_.ip < vm_.cur_code->size()) {
            if (stop_depth_ != SIZE_MAX && vm_.frames.size() < stop_depth_) return;
            size_t op_ip = vm_.ip;
            uint8_t op = read_byte();

            if (VM::trace) {
                std::cerr << "[ip=" << op_ip << "] op=0x"
                    << std::hex << (int)op << std::dec << "\n";
            }

            switch (op) {
            case (uint8_t)Op::HALT: return;
            case (uint8_t)Op::NOP:  break;

            case (uint8_t)Op::PUSH: {
                DataType t = (DataType)read_byte();
                stack_.push(read_literal(t));
                break;
            }

            case (uint8_t)Op::POP:
                stack_.pop();
                break;

            case (uint8_t)Op::LOAD_VAR: {
                uint32_t id = read_u32();
                stack_.push(memory_.load_var(id));
                break;
            }

            case (uint8_t)Op::STORE_VAR: {
                uint32_t id = read_u32();
                Value v = stack_.pop();
                memory_.store_var(id, v);
                break;
            }

            case (uint8_t)Op::CALL: {
                uint32_t id = read_u32();
                uint8_t argc = read_byte();
                std::vector<Value> args(argc);
                for (int i = (int)argc - 1; i >= 0; --i) args[i] = stack_.pop();
                if (!frames_.enter_call(id, argc, args))
                    throw std::runtime_error("Function id=" + std::to_string(id) + " not found");
                break;
            }

            case (uint8_t)Op::RET: {
                Value ret = stack_.pop();
                frames_.leave_call(ret);
                if (stop_depth_ != SIZE_MAX && vm_.frames.size() < stop_depth_) return;
                break;
            }

            case (uint8_t)Op::ADD:
            case (uint8_t)Op::SUB:
            case (uint8_t)Op::MUL:
            case (uint8_t)Op::DIV:
            case (uint8_t)Op::MOD:
                stack_.push(do_arith(op));
                break;

            case (uint8_t)Op::NEG: {
                Value v = stack_.pop();
                if (VM::is_float_type(v.type)) v.f = -v.f;
                else                            v.i = -v.i;
                stack_.push(v);
                break;
            }

            case (uint8_t)Op::EQ:
            case (uint8_t)Op::NE:
            case (uint8_t)Op::LT:
            case (uint8_t)Op::GT:
            case (uint8_t)Op::LE:
            case (uint8_t)Op::GE:
                stack_.push(do_cmp(op));
                break;

            case (uint8_t)Op::THREAD_RUN: {
                Value args = stack_.pop();
                Value fid_v = stack_.pop();
                uint64_t func_id = (uint64_t)fid_v.i;
                stack_.push(vm_.spawn_thread((uint32_t)func_id, args));
                break;
            }
            case (uint8_t)Op::THREAD_AWAIT: {
                Value h = stack_.pop();
                stack_.push(vm_.await_thread((uint64_t)h.i));
                break;
            }
            case (uint8_t)Op::THREAD_ALIVE: {
                Value h = stack_.pop();
                stack_.push(Value::make_bool(vm_.thread_alive((uint64_t)h.i)));
                break;
            }
            case (uint8_t)Op::THREAD_KILL: {
                Value h = stack_.pop();
                vm_.thread_kill((uint64_t)h.i);
                stack_.push(Value::make_null());
                break;
            }

            case (uint8_t)Op::PUSH_HANDLER: {
                uint32_t target = read_u32();
                vm_.handler_stack.push_back({ target, vm_.cur_code, vm_.frames.size() });
                break;
            }

            case (uint8_t)Op::POP_HANDLER: {
                if (!vm_.handler_stack.empty()) {
                    vm_.handler_stack.pop_back();
                    if (VM::trace) std::cerr << "  [handler] pop\n";
                }
                break;
            }

            case (uint8_t)Op::THROW: {
                Value ex = stack_.pop();
                if (vm_.handler_stack.empty()) {
                    throw std::runtime_error("Uncaught exception: " + VM::value_to_string(ex));
                }
                auto h = vm_.handler_stack.back();
                vm_.handler_stack.pop_back();
                
                while (vm_.frames.size() > h.frame_depth) {
                    vm_.frames.pop_back();
                }

                stack_.push(ex);
                vm_.cur_code = h.code;
                vm_.ip = h.target;
                break;
            }

            case (uint8_t)Op::AND: {
                Value b = stack_.pop(), a = stack_.pop();
                stack_.push(Value::make_bool(a.b && b.b));
                break;
            }
            case (uint8_t)Op::OR: {
                Value b = stack_.pop(), a = stack_.pop();
                stack_.push(Value::make_bool(a.b || b.b));
                break;
            }
            case (uint8_t)Op::NOT: {
                Value a = stack_.pop();
                stack_.push(Value::make_bool(!a.b));
                break;
            }

            case (uint8_t)Op::JMP: {
                uint32_t target = read_u32();
                vm_.ip = target;
                break;
            }
            case (uint8_t)Op::JZ: {
                uint32_t target = read_u32();
                Value v = stack_.pop();
                bool is_zero = VM::is_float_type(v.type) ? (v.f == 0.0) : (v.i == 0);
                if (is_zero) vm_.ip = target;
                break;
            }
            case (uint8_t)Op::JNZ: {
                uint32_t target = read_u32();
                Value v = stack_.pop();
                bool is_zero = VM::is_float_type(v.type) ? (v.f == 0.0) : (v.i == 0);
                if (!is_zero) vm_.ip = target;
                break;
            }

            case (uint8_t)Op::DUP: {
                if (vm_.stack.empty())
                    throw std::runtime_error("Stack underflow on DUP");
                Value v = vm_.stack.back();
                vm_.stack.push_back(v);
                break;
            }

            case (uint8_t)Op::SWAP: {
                if (vm_.stack.size() < 2)
                    throw std::runtime_error("Stack underflow on SWAP");
                Value tmp = vm_.stack[vm_.stack.size() - 1];
                vm_.stack[vm_.stack.size() - 1] = vm_.stack[vm_.stack.size() - 2];
                vm_.stack[vm_.stack.size() - 2] = tmp;
                break;
            }

            case (uint8_t)Op::CALL_NATIVE: {
                uint32_t lib_len = read_u32();
                std::string lib = read_str(lib_len);
                uint32_t fn_len = read_u32();
                std::string fn = read_str(fn_len);
                uint8_t argc = read_byte();

                std::vector<Value> args(argc);
                for (int i = (int)argc - 1; i >= 0; --i)
                    args[i] = stack_.pop();

                Value r;
                try {
                    r = native_.call(lib, fn, args);
                }
                catch (const std::exception& e) {
                    if (vm_.handler_stack.empty()) {
                        throw;
                    }

                    Value ex;
                    ex.type = DataType::STR;
                    ex.s = e.what();

                    auto h = vm_.handler_stack.back();
                    vm_.handler_stack.pop_back();

                    while (vm_.frames.size() > h.frame_depth) {
                        vm_.frames.pop_back();
                    }

                    stack_.push(ex);
                    vm_.cur_code = h.code;
                    vm_.ip = h.target;
                    break;
                }
                stack_.push(r);
                break;
            }

            case (uint8_t)Op::NEW_CLASS: {
                uint32_t class_id = read_u32();

                auto cit = vm_.classes.find(class_id);
                if (cit == vm_.classes.end())
                    throw std::runtime_error("Class id " + std::to_string(class_id) + " not found");

                auto obj = std::make_shared<VMObject>();
                obj->class_id = class_id;

                for (uint32_t vid : cit->second.var_ids) {
                    auto vit = vm_.globals.find(vid);
                    if (vit != vm_.globals.end()) {
                        obj->fields[vid] = vit->second.value;
                    }
                }

                uint64_t handle = vm_.next_object_id++;
                vm_.objects[handle] = obj;

                stack_.push(Value::make_object(handle, obj));
                break;
            }

            case (uint8_t)Op::LOAD_FIELD: {
                uint32_t field_id = read_u32();
                Value obj_val = stack_.pop();

                if (obj_val.type != DataType::OBJECT)
                    throw std::runtime_error("LOAD_FIELD: not an object");

                if (!obj_val.obj)
                    throw std::runtime_error("LOAD_FIELD: null object");

                auto fit = obj_val.obj->fields.find(field_id);
                if (fit == obj_val.obj->fields.end())
                    throw std::runtime_error("Field id " + std::to_string(field_id) + " not found");

                stack_.push(fit->second);
                break;
            }

            case (uint8_t)Op::STORE_FIELD: {
                uint32_t field_id = read_u32();
                Value value = stack_.pop();
                Value obj_val = stack_.pop();

                if (obj_val.type != DataType::OBJECT)
                    throw std::runtime_error("STORE_FIELD: not an object");

                if (!obj_val.obj)
                    throw std::runtime_error("STORE_FIELD: null object");

                obj_val.obj->fields[field_id] = value;
                break;
            }

            case (uint8_t)Op::CALL_METHOD: {
                uint32_t method_id = read_u32();
                uint8_t argc = read_byte();

                std::vector<Value> args(argc);
                for (int i = (int)argc - 1; i >= 0; --i) args[i] = stack_.pop();
                Value self = stack_.pop();

                auto fit = vm_.functions.find(method_id);
                if (fit == vm_.functions.end())
                    throw std::runtime_error("Method id " + std::to_string(method_id) + " not found");
                FuncDef& fn = fit->second;

                if (fn.args.size() != argc)
                    throw std::runtime_error("Arg count mismatch for '" + fn.name +
                        "': expected " + std::to_string(fn.args.size()) +
                        ", got " + std::to_string(argc));

                Frame frame;
                frame.fun_id = method_id;
                frame.saved_ip = vm_.ip;
                frame.saved_code = vm_.cur_code;

                frame.locals[0] = self;

                for (size_t i = 0; i < argc; ++i)
                    frame.locals[fn.args[i].id] = args[i];
                for (auto& lv : fn.locals)
                    frame.locals[lv.id] = VM::default_value(lv.type);

                vm_.frames.push_back(std::move(frame));
                vm_.cur_code = &fn.body;
                vm_.ip = 0;

                if (VM::trace) std::cerr << "  [call_method] " << fn.name
                    << " argc=" << (int)argc
                    << " self=" << self.i << "\n";
                break;
            }

            case (uint8_t)Op::FREE_OBJECT: {
                Value obj_val = stack_.pop();
                if (obj_val.type != DataType::OBJECT) {
                    break;
                }
                if (obj_val.obj) {
                    uint64_t handle = (uint64_t)obj_val.i;
                    auto it = vm_.objects.find(handle);
                    if (it != vm_.objects.end() && it->second.expired()) {
                        vm_.objects.erase(it);
                    }
                }
                break;
            }

            case (uint8_t)Op::NEW_LIST: {
                auto l = std::make_shared<VMList>();
                l->is_fixed = false;
                stack_.push(Value::make_list(l, false));
                break;
            }

            case (uint8_t)Op::NEW_ARRAY: {
                uint32_t n = read_u32();
                auto l = std::make_shared<VMList>();
                l->is_fixed = true;
                l->items.resize(n);
                stack_.push(Value::make_list(l, true));
                break;
            }

            case (uint8_t)Op::NEW_DICT: {
                auto d = std::make_shared<VMDict>();
                stack_.push(Value::make_dict(d));
                break;
            }

            case (uint8_t)Op::PUSH_ITEM: {
                Value val = stack_.pop();
                Value coll = stack_.pop();
                if (coll.type != DataType::LIST && coll.type != DataType::ARRAY)
                    throw std::runtime_error("PUSH_ITEM: not a list/array");
                if (!coll.list)
                    throw std::runtime_error("PUSH_ITEM: null list");
                if (coll.list->is_fixed)
                    throw std::runtime_error("PUSH_ITEM: array is fixed (use list)");
                coll.list->items.push_back(val);
                break;
            }

            case (uint8_t)Op::POP_ITEM: {
                Value coll = stack_.pop();
                if (coll.type != DataType::LIST && coll.type != DataType::ARRAY)
                    throw std::runtime_error("POP_ITEM: not a list/array");
                if (!coll.list || coll.list->items.empty())
                    throw std::runtime_error("POP_ITEM: empty list");
                Value v = coll.list->items.back();
                coll.list->items.pop_back();
                stack_.push(v);
                break;
            }

            case (uint8_t)Op::INDEX_GET: {
                Value idx = stack_.pop();
                Value coll = stack_.pop();

                if (coll.type == DataType::LIST || coll.type == DataType::ARRAY) {
                    if (!coll.list)
                        throw std::runtime_error("INDEX_GET: null list");
                    if (idx.type != DataType::INT8 && idx.type != DataType::INT16 &&
                        idx.type != DataType::INT32 && idx.type != DataType::INT64 &&
                        idx.type != DataType::INT)
                        throw std::runtime_error("INDEX_GET: index must be int");
                    int64_t i = idx.i;
                    if (i < 0) i += (int64_t)coll.list->items.size();
                    if (i < 0 || i >= (int64_t)coll.list->items.size())
                        throw std::runtime_error("INDEX_GET: index " + std::to_string(i) + " out of range");
                    stack_.push(coll.list->items[(size_t)i]);
                    break;
                }

                if (coll.type == DataType::DICT) {
                    if (!coll.dict)
                        throw std::runtime_error("INDEX_GET: null dict");
                    if (idx.type != DataType::STR)
                        throw std::runtime_error("INDEX_GET: dict key must be str");
                    auto it = coll.dict->items.find(idx.s);
                    if (it == coll.dict->items.end())
                        throw std::runtime_error("INDEX_GET: key '" + idx.s + "' not found");
                    stack_.push(it->second);
                    break;
                }

                throw std::runtime_error("INDEX_GET: not a collection");
            }

            case (uint8_t)Op::INDEX_SET: {
                Value val = stack_.pop();
                Value idx = stack_.pop();
                Value coll = stack_.pop();

                if (coll.type == DataType::LIST || coll.type == DataType::ARRAY) {
                    if (!coll.list)
                        throw std::runtime_error("INDEX_SET: null list");
                    if (idx.type != DataType::INT8 && idx.type != DataType::INT16 &&
                        idx.type != DataType::INT32 && idx.type != DataType::INT64 &&
                        idx.type != DataType::INT)
                        throw std::runtime_error("INDEX_SET: index must be int");
                    int64_t i = idx.i;
                    if (i < 0) i += (int64_t)coll.list->items.size();
                    if (i < 0 || i >= (int64_t)coll.list->items.size())
                        throw std::runtime_error("INDEX_SET: index " + std::to_string(i) + " out of range");
                    coll.list->items[(size_t)i] = val;
                    break;
                }

                if (coll.type == DataType::DICT) {
                    if (!coll.dict)
                        throw std::runtime_error("INDEX_SET: null dict");
                    if (idx.type != DataType::STR)
                        throw std::runtime_error("INDEX_SET: dict key must be str");
                    coll.dict->items[idx.s] = val;
                    break;
                }

                throw std::runtime_error("INDEX_SET: not a collection");
            }

            case (uint8_t)Op::LEN: {
                Value coll = stack_.pop();
                if (coll.type == DataType::LIST || coll.type == DataType::ARRAY) {
                    if (!coll.list) { stack_.push(Value::make_int(0)); break; }
                    stack_.push(Value::make_int((int64_t)coll.list->items.size()));
                    break;
                }
                if (coll.type == DataType::DICT) {
                    if (!coll.dict) { stack_.push(Value::make_int(0)); break; }
                    stack_.push(Value::make_int((int64_t)coll.dict->items.size()));
                    break;
                }
                if (coll.type == DataType::STR) {
                    stack_.push(Value::make_int((int64_t)coll.s.size()));
                    break;
                }
                throw std::runtime_error("LEN: not a collection/str");
            }

            case (uint8_t)Op::LIST_CLEAR: {
                Value coll = stack_.pop();
                if (coll.list) coll.list->items.clear();
                break;
            }

            case (uint8_t)Op::LIST_INSERT: {
                Value val = stack_.pop();
                Value idx = stack_.pop();
                Value coll = stack_.pop();
                if (!coll.list)
                    throw std::runtime_error("LIST_INSERT: null list");
                if (idx.type != DataType::INT8 && idx.type != DataType::INT16 &&
                    idx.type != DataType::INT32 && idx.type != DataType::INT64 &&
                    idx.type != DataType::INT)
                    throw std::runtime_error("LIST_INSERT: index must be int");
                int64_t i = idx.i;
                if (i < 0) i += (int64_t)coll.list->items.size();
                if (i < 0) i = 0;
                if (i > (int64_t)coll.list->items.size())
                    i = (int64_t)coll.list->items.size();
                coll.list->items.insert(coll.list->items.begin() + i, val);
                break;
            }

            case (uint8_t)Op::LIST_REMOVE: {
                Value idx = stack_.pop();
                Value coll = stack_.pop();
                if (!coll.list)
                    throw std::runtime_error("LIST_REMOVE: null list");
                if (idx.type != DataType::INT8 && idx.type != DataType::INT16 &&
                    idx.type != DataType::INT32 && idx.type != DataType::INT64 &&
                    idx.type != DataType::INT)
                    throw std::runtime_error("LIST_REMOVE: index must be int");
                int64_t i = idx.i;
                if (i < 0) i += (int64_t)coll.list->items.size();
                if (i < 0 || i >= (int64_t)coll.list->items.size())
                    throw std::runtime_error("LIST_REMOVE: index out of range");
                coll.list->items.erase(coll.list->items.begin() + i);
                break;
            }

            case (uint8_t)Op::ARRAY_FILL: {
                Value val = stack_.pop();
                Value coll = stack_.pop();
                if (!coll.list)
                    throw std::runtime_error("ARRAY_FILL: null array");
                for (auto& it : coll.list->items) it = val;
                break;
            }

            case (uint8_t)Op::DICT_HAS: {
                Value key = stack_.pop();
                Value coll = stack_.pop();
                if (coll.type != DataType::DICT || !coll.dict) {
                    stack_.push(Value::make_bool(false));
                    break;
                }
                if (key.type != DataType::STR)
                    throw std::runtime_error("DICT_HAS: key must be str");
                stack_.push(Value::make_bool(coll.dict->items.count(key.s) > 0));
                break;
            }

            case (uint8_t)Op::DICT_REMOVE: {
                Value key = stack_.pop();
                Value coll = stack_.pop();
                if (coll.type != DataType::DICT || !coll.dict) {
                    stack_.push(Value::make_bool(false));
                    break;
                }
                if (key.type != DataType::STR)
                    throw std::runtime_error("DICT_REMOVE: key must be str");
                stack_.push(Value::make_bool(coll.dict->items.erase(key.s) > 0));
                break;
            }

            case (uint8_t)Op::DICT_KEYS: {
                Value coll = stack_.pop();
                auto l = std::make_shared<VMList>();
                if (coll.type == DataType::DICT && coll.dict) {
                    for (auto& [k, v] : coll.dict->items)
                        l->items.push_back(Value::make_str(k));
                }
                stack_.push(Value::make_list(l, false));
                break;
            }

            case (uint8_t)Op::DICT_VALUES: {
                Value coll = stack_.pop();
                auto l = std::make_shared<VMList>();
                if (coll.type == DataType::DICT && coll.dict) {
                    for (auto& [k, v] : coll.dict->items)
                        l->items.push_back(v);
                }
                stack_.push(Value::make_list(l, false));
                break;
            }

            default:
                throw std::runtime_error(
                    "Unknown opcode 0x" + std::to_string((int)op) +
                    " at ip=" + std::to_string(op_ip));
            }
        }
    }

}