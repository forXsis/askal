// Askal — https://github.com/forXsis/askal
// Copyright (c) 2026 forXsis <forxtrees@gmail.com>
// Licensed under the Apache License, Version 2.0.

#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

#define ASKAL_ABI_VERSION 2

#define AK_TYPE_STR    0x10
#define AK_TYPE_BOOL   0x11
#define AK_TYPE_FLOAT  0x12
#define AK_TYPE_INT8   0x13
#define AK_TYPE_INT16  0x14
#define AK_TYPE_INT32  0x15
#define AK_TYPE_INT64  0x16
#define AK_TYPE_INT    0x17
#define AK_TYPE_NULL   0x18
#define AK_TYPE_BIN    0x19
#define AK_TYPE_HEX    0x1A
#define AK_TYPE_AUTO   0x1B
#define AK_TYPE_OBJECT 0x1C
#define AK_TYPE_ARRAY  0x1D
#define AK_TYPE_LIST   0x1E
#define AK_TYPE_DICT   0x1F

typedef int (*AskDbFn)(const char* name,
                       const uint8_t* in, size_t in_size,
                       uint8_t* out, size_t* out_size);

#define ASKAL_OK             0
#define ASKAL_ERR_UNKNOWN    1
#define ASKAL_ERR_BADARGS    2
#define ASKAL_ERR_INTERNAL   3

typedef struct {
    const uint8_t* p;
    const uint8_t* end;
} AkReader;

static inline void ak_reader_init(AkReader* r, const uint8_t* in, size_t in_size) {
    r->p = in;
    r->end = in + in_size;
}

static inline int ak_eof(const AkReader* r) { return r->p >= r->end; }

static inline uint8_t ak_u8(AkReader* r) {
    return (r->p < r->end) ? *r->p++ : 0;
}

static inline uint32_t ak_u32(AkReader* r) {
    uint32_t x = 0;
    for (int i = 0; i < 4; ++i) x |= (uint32_t)ak_u8(r) << (i * 8);
    return x;
}

static inline int64_t ak_i64(AkReader* r) {
    uint64_t x = 0;
    for (int i = 0; i < 8; ++i) x |= (uint64_t)ak_u8(r) << (i * 8);
    return (int64_t)x;
}

static inline double ak_f64(AkReader* r) {
    uint64_t x = 0;
    for (int i = 0; i < 8; ++i) x |= (uint64_t)ak_u8(r) << (i * 8);
    double d; memcpy(&d, &x, 8);
    return d;
}

static inline uint32_t ak_str(AkReader* r, char* buf, uint32_t maxlen) {
    uint32_t len = ak_u32(r);
    uint32_t copy = (len < maxlen - 1) ? len : (maxlen - 1);
    for (uint32_t i = 0; i < copy; ++i) buf[i] = (char)ak_u8(r);
    buf[copy] = 0;
    for (uint32_t i = copy; i < len; ++i) ak_u8(r);
    return copy;
}

typedef struct {
    uint8_t* p;
    uint8_t* end;
} AkWriter;

static inline void ak_writer_init(AkWriter* w, uint8_t* out, size_t out_size) {
    w->p = out;
    w->end = out + out_size;
}

static inline void ak_w_u8(AkWriter* w, uint8_t x) {
    if (w->p < w->end) *w->p++ = x;
}

static inline void ak_w_u32(AkWriter* w, uint32_t x) {
    for (int i = 0; i < 4; ++i) ak_w_u8(w, (uint8_t)((x >> (i * 8)) & 0xFF));
}

static inline void ak_w_i64(AkWriter* w, int64_t x) {
    uint64_t u = (uint64_t)x;
    for (int i = 0; i < 8; ++i) ak_w_u8(w, (uint8_t)((u >> (i * 8)) & 0xFF));
}

static inline void ak_w_f64(AkWriter* w, double d) {
    uint64_t u; memcpy(&u, &d, 8);
    for (int i = 0; i < 8; ++i) ak_w_u8(w, (uint8_t)((u >> (i * 8)) & 0xFF));
}

static inline void ak_w_str(AkWriter* w, const char* s, uint32_t len) {
    ak_w_u32(w, len);
    for (uint32_t i = 0; i < len; ++i) ak_w_u8(w, (uint8_t)s[i]);
}

static inline void ak_ret_null (AkWriter* w) { ak_w_u8(w, AK_TYPE_NULL); }
static inline void ak_ret_int  (AkWriter* w, int64_t x) {
    ak_w_u8(w, AK_TYPE_INT64); ak_w_i64(w, x);
}
static inline void ak_ret_float(AkWriter* w, double d) {
    ak_w_u8(w, AK_TYPE_FLOAT); ak_w_f64(w, d);
}
static inline void ak_ret_bool (AkWriter* w, int b) {
    ak_w_u8(w, AK_TYPE_BOOL); ak_w_u8(w, b ? 1 : 0);
}
static inline void ak_ret_str  (AkWriter* w, const char* s, uint32_t len) {
    ak_w_u8(w, AK_TYPE_STR); ak_w_str(w, s, len);
}

#ifdef __cplusplus
}
#endif