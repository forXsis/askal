// Askal — https://github.com/forXsis/askal
// Copyright (c) 2026 forXsis <forxtrees@gmail.com>
// Licensed under the Apache License, Version 2.0.

#include "vm_memory.h"
#include <cstring>
#include <stdexcept>

namespace askal {

    static constexpr size_t AUTO_CELL_SIZE = 280;
    static constexpr size_t AUTO_STR_OFF = 24;
    static constexpr size_t AUTO_STR_MAX = 256;

    static void write_auto_cell(uint8_t* cell, const Value& v) {
        std::fill(cell, cell + AUTO_CELL_SIZE, 0);
        uint64_t tag = (uint64_t)v.type;
        std::memcpy(cell + 0, &tag, 8);
        int64_t iv = v.i;
        std::memcpy(cell + 8, &iv, 8);
        double fv = v.f;
        std::memcpy(cell + 16, &fv, 8);
        if (v.type == DataType::STR || v.type == DataType::BIN || v.type == DataType::HEX) {
            size_t len = v.s.size();
            if (len > AUTO_STR_MAX - 1) len = AUTO_STR_MAX - 1;
            std::memcpy(cell + AUTO_STR_OFF, v.s.data(), len);
        }
    }

    static Value read_auto_cell(const uint8_t* cell) {
        Value v;
        uint64_t tag = 0;
        std::memcpy(&tag, cell + 0, 8);
        v.type = (DataType)tag;
        std::memcpy(&v.i, cell + 8, 8);
        std::memcpy(&v.f, cell + 16, 8);
        v.b = (v.i != 0);
        if (v.type == DataType::STR || v.type == DataType::BIN || v.type == DataType::HEX) {
            size_t len = strnlen((const char*)(cell + AUTO_STR_OFF), AUTO_STR_MAX);
            v.s.assign((const char*)(cell + AUTO_STR_OFF), len);
        }
        return v;
    }


    Value Memory::load_var(uint32_t id) {
        if (!vm_.frames.empty()) {
            auto fit = vm_.frames.back().locals.find(id);
            if (fit != vm_.frames.back().locals.end())
                return fit->second;
        }
        auto it = vm_.globals.find(id);
        if (it == vm_.globals.end())
            throw std::runtime_error("Unknown variable id=" + std::to_string(id));
        return it->second.value;
    }

    void Memory::store_var(uint32_t id, const Value& v) {
        if (!vm_.frames.empty()) {
            auto fit = vm_.frames.back().locals.find(id);
            if (fit != vm_.frames.back().locals.end()) {
                fit->second = v;
                return;
            }
        }
        auto it = vm_.globals.find(id);
        if (it == vm_.globals.end())
            throw std::runtime_error("Unknown variable id=" + std::to_string(id));
        it->second.value = v;
    }

}