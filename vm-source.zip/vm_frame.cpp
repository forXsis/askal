// Askal — https://github.com/forXsis/askal
// Copyright (c) 2026 forXsis <forxtrees@gmail.com>
// Licensed under the Apache License, Version 2.0.

#include "vm_frame.h"
#include <iostream>
#include <stdexcept>

namespace askal {

    bool FrameManager::enter_call(uint32_t fun_id, uint8_t argc,
        const std::vector<Value>& args) {
        auto it = vm_.functions.find(fun_id);
        if (it == vm_.functions.end()) return false;
        FuncDef& fn = it->second;

        if (fn.args.size() != argc)
            throw std::runtime_error("Arg count mismatch for '" + fn.name +
                "': expected " + std::to_string(fn.args.size()) +
                ", got " + std::to_string(argc));

        Frame fr;
        fr.fun_id = fun_id;
        fr.saved_ip = vm_.ip;
        fr.saved_code = vm_.cur_code;

        for (size_t i = 0; i < argc; ++i)
            fr.locals[fn.args[i].id] = args[i];

        for (auto& lv : fn.locals)
            fr.locals[lv.id] = VM::default_value(lv.type);

        vm_.frames.push_back(std::move(fr));
        vm_.cur_code = &fn.body;
        vm_.ip = 0;

        if (VM::trace) std::cerr << "  [call] " << fn.name << " argc=" << (int)argc << "\n";
        return true;
    }

    void FrameManager::leave_call(const Value& ret) {
        if (vm_.frames.empty())
            throw std::runtime_error("RET outside function");

        Frame fr = std::move(vm_.frames.back());
        vm_.frames.pop_back();

        vm_.cur_code = fr.saved_code;
        vm_.ip = fr.saved_ip;

        vm_.stack.push_back(ret);

        if (VM::trace) std::cerr << "  [ret] fun_id=" << fr.fun_id << "\n";
    }

}