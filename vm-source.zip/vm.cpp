// Askal — https://github.com/forXsis/askal
// Copyright (c) 2026 forXsis <forxtrees@gmail.com>
// Licensed under the Apache License, Version 2.0.

#include "vm.h"
#include "vm_loader.h"
#include "vm_exec.h"
#include <algorithm>
#include <iostream>
#include <cstring>
#include <sstream>

namespace askal {

    bool VM::log_out = false;
    bool VM::trace = false;
    bool VM::pause_on_exit = false;

    bool VM::is_int_type(DataType t) {
        switch (t) {
        case DataType::INT8:
        case DataType::INT16:
        case DataType::INT32:
        case DataType::INT64:
        case DataType::INT:
            return true;
        default:
            return false;
        }
    }

    bool VM::is_float_type(DataType t) { return t == DataType::FLOAT; }

    int VM::type_size(DataType t) {
        switch (t) {
        case DataType::INT8:  return 1;
        case DataType::INT16: return 2;
        case DataType::INT32: return 4;
        case DataType::INT64:
        case DataType::INT:
        case DataType::FLOAT: return 8;
        case DataType::BOOL:  return 1;
        case DataType::STR:
        case DataType::BIN:
        case DataType::HEX:   return 256;
        case DataType::NULL_: return 0;
        }
        return 0;
    }

    Value VM::default_value(DataType t) {
        Value v; v.type = t;
        if (t == DataType::LIST) {
            auto l = std::make_shared<VMList>();
            l->is_fixed = false;
            v.list = l;
        }
        else if (t == DataType::ARRAY) {
            auto l = std::make_shared<VMList>();
            l->is_fixed = true;
            v.list = l;
        }
        else if (t == DataType::DICT) {
            v.dict = std::make_shared<VMDict>();
        }
        return v;
    }

    std::string VM::value_to_string(const Value& v) {
        std::ostringstream out;
        switch (v.type) {
        case DataType::INT8:
        case DataType::INT16:
        case DataType::INT32:
        case DataType::INT64:
        case DataType::INT:   out << v.i; break;
        case DataType::FLOAT: out << v.f; break;
        case DataType::BOOL:  out << (v.b ? "true" : "false"); break;
        case DataType::STR:
        case DataType::BIN:
        case DataType::HEX:   out << '"' << v.s << '"'; break;
        case DataType::NULL_: out << "null"; break;
        case DataType::OBJECT:
            out << "<object #" << v.i << ">";
            break;
        case DataType::ARRAY:
            out << "<array>";
            break;
        case DataType::LIST:
            out << "<list>";
            break;
        case DataType::DICT:
            out << "<dict>";
            break;
        }
        return out.str();
    }

    bool VM::load(const std::string& path) {
        Loader loader;
        return loader.load(*this, path);
    }

    uint32_t VM::find_function_by_name(const std::string& name) const {
        for (auto& [id, f] : functions) {
            if (f.name == name) return id;
        }
        return 0;
    }

    bool VM::call_function(uint32_t func_id, int argc) {
        auto it = functions.find(func_id);
        if (it == functions.end()) return false;
        FuncDef& fn = it->second;

        std::vector<Value> args;
        for (int i = 0; i < argc; ++i) {
            if (stack.empty()) return false;
            args.push_back(stack.back());
            stack.pop_back();
        }
        std::reverse(args.begin(), args.end());

        Frame fr;
        fr.fun_id = func_id;
        fr.saved_ip = ip;
        fr.saved_code = cur_code;

        for (size_t i = 0; i < args.size() && i < fn.args.size(); ++i) {
            fr.locals[fn.args[i].id] = args[i];
        }
        for (auto& lv : fn.locals) {
            fr.locals[lv.id] = default_value(lv.type);
        }

        frames.push_back(std::move(fr));
        cur_code = &fn.body;
        ip = 0;

        size_t start_depth = frames.size();
        try {
            Exec exec(*this);
            exec.run_until(start_depth);
        }
        catch (const std::exception& e) {
            std::cerr << "call_function runtime error: " << e.what() << "\n";
            return false;
        }
        return true;
    }

    bool VM::execute() {
        stack.clear();
        frames.clear();
        objects.clear();
        next_object_id = 1;
        handler_stack.clear();
        cur_code = &main_code;
        ip = 0;

        if (log_out) {
            std::cerr << "Globals:   " << globals.size() << "\n";
            std::cerr << "Functions: " << functions.size() << "\n";
            std::cerr << "Classes:   " << classes.size() << "\n";
            std::cerr << "Main size: " << main_code.size() << " bytes\n";
        }

        try {
            Exec exec(*this);
            exec.run();
        }
        catch (const std::exception& e) {
            std::cerr << "Runtime error: " << e.what() << "\n";
            return false;
        }
        return true;
    }

    void VM::dump_globals() const {
        std::cout << "\n--- Global variables ---\n";
        for (auto& [id, gv] : globals) {
            std::cout << "  id=" << id << " name=" << gv.name
                << " type=0x" << std::hex << (int)gv.type << std::dec
                << " value=" << value_to_string(gv.value) << "\n";
        }
        std::cout << "\n";
    }

}