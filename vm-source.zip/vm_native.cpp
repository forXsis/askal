// Askal — https://github.com/forXsis/askal
// Copyright (c) 2026 forXsis <forxtrees@gmail.com>
// Licensed under the Apache License, Version 2.0.

#include "vm_native.h"
#include <cstring>
#include <stdexcept>
#include <iostream>

#ifdef _WIN32
#include <windows.h>
static void* dl_open(const char* p) { return (void*)LoadLibraryA(p); }
static void* dl_sym(void* h, const char* n) { return (void*)GetProcAddress((HMODULE)h, n); }
static const char* dl_err() { return "LoadLibrary failed"; }
#else
#include <dlfcn.h>
static void* dl_open(const char* p) { return dlopen(p, RTLD_NOW); }
static void* dl_sym(void* h, const char* n) { return dlsym(h, n); }
static const char* dl_err() { return dlerror(); }
#endif

namespace askal {

    bool NativeRegistry::log_out = false;

    std::string NativeRegistry::lib_path(const std::string& name) {
#ifdef _WIN32
        return name + ".dll";
#else
        return "lib" + name + ".so";
#endif
    }

    bool NativeRegistry::load_one(const std::string& name) {
        if (loaded.count(name)) return true;

        std::string path = lib_path(name);
        void* h = dl_open(path.c_str());
        if (!h) {
            std::cerr << "[native] Cannot load '" << name << "' (" << path
                << "): " << dl_err() << "\n";
            return false;
        }

        AskDbFn fn = (AskDbFn)dl_sym(h, "askal_db");
        if (!fn) {
            std::cerr << "[native] '" << name << "' does not export askal_db\n";
            return false;
        }

        Entry e; e.handle = h; e.db = fn;
        loaded[name] = e;
        if (log_out) std::cerr << "[native] loaded " << path << "\n";
        return true;
    }

    bool NativeRegistry::load_all(const std::vector<std::string>& libs) {
        bool ok = true;
        for (auto& l : libs) if (!load_one(l)) ok = false;
        return ok;
    }

    static void put_u8(std::vector<uint8_t>& v, uint8_t  x) { v.push_back(x); }
    static void put_u32(std::vector<uint8_t>& v, uint32_t x) {
        for (int i = 0; i < 4; ++i) v.push_back((x >> (i * 8)) & 0xFF);
    }

    static void put_payload(std::vector<uint8_t>& v, const Value& val) {
        switch (val.type) {
        case DataType::LIST:
        case DataType::ARRAY: {
            put_u8(v, (uint8_t)val.type);
            if (!val.list) { put_u32(v, 0); break; }
            put_u32(v, (uint32_t)val.list->items.size());
            for (auto& it : val.list->items) put_payload(v, it);
            break;
        }
        case DataType::DICT: {
            put_u8(v, AK_TYPE_DICT);
            if (!val.dict) { put_u32(v, 0); break; }
            put_u32(v, (uint32_t)val.dict->items.size());
            for (auto& [k, vv] : val.dict->items) {
                put_payload(v, Value::make_str(k));
                put_payload(v, vv);
            }
            break;
        }
        case DataType::INT8:
        case DataType::INT16:
        case DataType::INT32:
        case DataType::INT64:
        case DataType::INT: {
            put_u8(v, AK_TYPE_INT64);
            int64_t x = val.i;
            for (int i = 0; i < 8; ++i) v.push_back((x >> (i * 8)) & 0xFF);
            break;
        }
        case DataType::FLOAT: {
            put_u8(v, AK_TYPE_FLOAT);
            uint64_t x; std::memcpy(&x, &val.f, 8);
            for (int i = 0; i < 8; ++i) v.push_back((x >> (i * 8)) & 0xFF);
            break;
        }
        case DataType::BOOL:
            put_u8(v, AK_TYPE_BOOL);
            put_u8(v, val.b ? 1 : 0);
            break;
        case DataType::STR:
        case DataType::BIN:
        case DataType::HEX: {
            put_u8(v, (uint8_t)val.type);
            put_u32(v, (uint32_t)val.s.size());
            v.insert(v.end(), val.s.begin(), val.s.end());
            break;
        }
        case DataType::NULL_:
            put_u8(v, AK_TYPE_NULL);
            break;
        }
    }

    std::vector<uint8_t> NativeRegistry::pack_args(const std::vector<Value>& args) {
        std::vector<uint8_t> buf;
        put_u32(buf, (uint32_t)args.size());
        for (auto& a : args) put_payload(buf, a);
        return buf;
    }

    static uint32_t take_u32(const std::vector<uint8_t>& v, size_t& p) {
        uint32_t x = 0;
        for (int i = 0; i < 4; ++i) x |= (uint32_t)v[p++] << (i * 8);
        return x;
    }

    Value NativeRegistry::unpack_value(const std::vector<uint8_t>& buf, size_t& pos) {
        Value v;
        v.type = (DataType)buf[pos++];
        switch (v.type) {
        case DataType::INT8:  v.i = (int8_t)buf[pos++]; break;
        case DataType::INT16: { int16_t x; std::memcpy(&x, &buf[pos], 2); pos += 2; v.i = x; break; }
        case DataType::INT32: { int32_t x; std::memcpy(&x, &buf[pos], 4); pos += 4; v.i = x; break; }
        case DataType::INT64:
        case DataType::INT: { int64_t x; std::memcpy(&x, &buf[pos], 8); pos += 8; v.i = x; break; }
        case DataType::FLOAT: {
            uint64_t x = 0;
            for (int i = 0;i < 8;++i) x |= (uint64_t)buf[pos++] << (i * 8);
            std::memcpy(&v.f, &x, 8); break;
        }
        case DataType::LIST:
        case DataType::ARRAY: {
            uint32_t n = take_u32(buf, pos);
            auto l = std::make_shared<VMList>();
            l->is_fixed = (v.type == DataType::ARRAY);
            for (uint32_t i = 0; i < n; ++i) {
                l->items.push_back(unpack_value(buf, pos));
            }
            v.list = l;
            break;
        }
        case DataType::DICT: {
            uint32_t n = take_u32(buf, pos);
            auto d = std::make_shared<VMDict>();
            for (uint32_t i = 0; i < n; ++i) {
                Value k = unpack_value(buf, pos);
                if (k.type != DataType::STR) throw std::runtime_error("dict key must be str");
                d->items[k.s] = unpack_value(buf, pos);
            }
            v.dict = d;
            break;
        }
        case DataType::BOOL:  v.b = buf[pos++] != 0; v.i = v.b ? 1 : 0; break;
        case DataType::STR:
        case DataType::BIN:
        case DataType::HEX: {
            uint32_t len = take_u32(buf, pos);
            v.s.assign((const char*)&buf[pos], len); pos += len;
            break;
        }
        case DataType::NULL_: break;
        }
        return v;
    }

    Value NativeRegistry::call(const std::string& lib,
        const std::string& fn,
        const std::vector<Value>& args) {
        auto it = loaded.find(lib);
        if (it == loaded.end())
            throw std::runtime_error("Library '" + lib + "' not loaded");

        auto in = pack_args(args);

        std::vector<uint8_t> out(64 * 1024, 0);
        size_t out_size = out.size();

        int rc = it->second.db(fn.c_str(),
            in.data(), in.size(),
            out.data(), &out_size);

        if (rc != ASKAL_OK) {
            std::string msg;
            if (out_size > 0 && out.size() >= 5 && out[0] == (uint8_t)DataType::STR) {
                size_t p = 1;
                uint32_t len = (uint32_t)out[p] | ((uint32_t)out[p + 1] << 8)
                    | ((uint32_t)out[p + 2] << 16) | ((uint32_t)out[p + 3] << 24);
                p += 4;
                if (p + len <= out.size())
                    msg.assign((const char*)&out[p], len);
            }

            std::string suffix = msg.empty() ? "" : (" — " + msg);
            if (rc == ASKAL_ERR_UNKNOWN)
                throw std::runtime_error("Unknown native function: " + lib + "::" + fn + suffix);
            if (rc == ASKAL_ERR_BADARGS)
                throw std::runtime_error("Bad args for: " + lib + "::" + fn + suffix);
            if (rc == ASKAL_ERR_INTERNAL)
                throw std::runtime_error("Library internal error: " + lib + "::" + fn + suffix);
            throw std::runtime_error("Native error code " + std::to_string(rc) + " from " + lib + "::" + fn + suffix);
        }

        size_t p = 0;
        return unpack_value(out, p);
    }

}