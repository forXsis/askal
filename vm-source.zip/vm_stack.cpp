// Askal — https://github.com/forXsis/askal
// Copyright (c) 2026 forXsis <forxtrees@gmail.com>
// Licensed under the Apache License, Version 2.0.

#include "vm_stack.h"
#include <stdexcept>
#include <iostream>

namespace askal {

    void StackOps::push(const Value& v) {
        if (VM::trace) std::cerr << "  [stack] push " << VM::value_to_string(v) << "\n";
        vm_.stack.push_back(v);
    }

    Value StackOps::pop() {
        if (vm_.stack.empty())
            throw std::runtime_error("Stack underflow");
        Value v = vm_.stack.back();
        vm_.stack.pop_back();
        if (VM::trace) std::cerr << "  [stack] pop  " << VM::value_to_string(v) << "\n";
        return v;
    }

}