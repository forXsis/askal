// Askal — https://github.com/forXsis/askal
// Copyright (c) 2026 forXsis <forxtrees@gmail.com>
// Licensed under the Apache License, Version 2.0.

#pragma once
#include "vm_opcodes.h"
#include <cstdint>
#include <string>
#include <vector>
#include <unordered_map>
#include <memory>

namespace askal {
    struct VMObject;
    struct VMList;
    struct VMDict;

    struct Value {
        DataType type = DataType::NULL_;
        int64_t  i = 0;
        double   f = 0.0;
        bool     b = false;
        std::string s;
        std::shared_ptr<VMObject> obj;
        std::shared_ptr<VMList>   list;
        std::shared_ptr<VMDict>   dict;

        static Value make_int(int64_t v) { Value r; r.type = DataType::INT64; r.i = v; return r; }
        static Value make_float(double v) { Value r; r.type = DataType::FLOAT; r.f = v; return r; }
        static Value make_bool(bool v) { Value r; r.type = DataType::BOOL;  r.b = v; r.i = v ? 1 : 0; return r; }
        static Value make_str(const std::string& v) { Value r; r.type = DataType::STR; r.s = v; return r; }
        static Value make_null() { Value r; r.type = DataType::NULL_; return r; }

        static Value make_object(uint64_t handle, std::shared_ptr<VMObject> o) {
            Value r;
            r.type = DataType::OBJECT;
            r.i = (int64_t)handle;
            r.obj = std::move(o);
            return r;
        }
        static Value make_list(std::shared_ptr<VMList> l, bool fixed = false) {
            Value r;
            r.type = fixed ? DataType::ARRAY : DataType::LIST;
            r.list = std::move(l);
            return r;
        }
        static Value make_dict(std::shared_ptr<VMDict> d) {
            Value r;
            r.type = DataType::DICT;
            r.dict = std::move(d);
            return r;
        }
    };

    struct VMList {
        std::vector<Value> items;
        bool is_fixed = false;
    };

    struct VMDict {
        std::unordered_map<std::string, Value> items;
    };

    struct VarDef {
        uint32_t id = 0;
        DataType type = DataType::NULL_;
        std::string name;
        Value    value;
        uint32_t size = 0;
    };

    struct FuncArg {
        uint32_t id = 0;
        DataType type = DataType::NULL_;
        std::string name;
    };

    struct FuncLocal {
        uint32_t id = 0;
        DataType type = DataType::NULL_;
        std::string name;
    };

    struct FuncDef {
        uint32_t id = 0;
        std::string name;
        DataType ret_type = DataType::NULL_;
        std::vector<FuncArg> args;
        std::vector<FuncLocal> locals;
        std::vector<uint8_t> body;
        bool is_method = false;
    };

    struct ClassDef {
        uint32_t id = 0;
        std::string name;
        std::vector<uint32_t> var_ids;
        std::vector<uint32_t> fun_ids;
    };

    struct Frame {
        uint32_t fun_id = 0;
        size_t   saved_ip = 0;
        const std::vector<uint8_t>* saved_code = nullptr;
        std::unordered_map<uint32_t, Value> locals;
    };

    struct VMObject {
        uint32_t class_id = 0;
        std::unordered_map<uint32_t, Value> fields;
    };

    struct VMThread {
        uint64_t handle = 0;
        uint32_t func_id = 0;
        std::string args_blob;

#ifdef _WIN32
        void* process = nullptr;
        void* stdin_w = nullptr;
        void* stdout_r = nullptr;
#else
        int pid = -1;
        int stdin_w = -1;
        int stdout_r = -1;
#endif

        bool finished = false;
        bool killed = false;
        int  exit_code = -1;
        Value result;
    };

    class VM {
    public:
        static bool log_out;
        static bool trace;
        static bool pause_on_exit;

        std::unordered_map<uint64_t, std::weak_ptr<VMObject>> objects;
        uint64_t next_object_id = 1;

        struct HandlerEntry {
            uint32_t target;
            const std::vector<uint8_t>* code;
            size_t frame_depth;
        };
        std::vector<HandlerEntry> handler_stack;

        std::string current_aklp_path;
        std::unordered_map<uint64_t, std::shared_ptr<VMThread>> threads;
        uint64_t next_thread_handle = 1;

        Value spawn_thread(uint32_t func_id, const Value& args);
        Value await_thread(uint64_t handle);
        bool  thread_alive(uint64_t handle);
        void  thread_kill(uint64_t handle);

        static std::string pack_value(const Value& v);
        static Value       unpack_value(const std::string& blob);

        std::unordered_map<uint32_t, VarDef>   globals;
        std::unordered_map<uint32_t, FuncDef>  functions;
        std::unordered_map<uint32_t, ClassDef> classes;
        std::vector<std::string> used_libs;
        std::vector<uint8_t> main_code;

        std::vector<Value> stack;
        std::vector<Frame> frames;
        const std::vector<uint8_t>* cur_code = nullptr;
        size_t ip = 0;

        bool load(const std::string& path);
        bool execute();
        void dump_globals() const;

        uint32_t find_function_by_name(const std::string& name) const;
        bool call_function(uint32_t func_id, int argc);

        static bool is_int_type(DataType t);
        static bool is_float_type(DataType t);
        static int  type_size(DataType t);
        static Value default_value(DataType t);
        static std::string value_to_string(const Value& v);
    };

}