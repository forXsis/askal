// Askal — https://github.com/forXsis/askal
// Copyright (c) 2026 forXsis <forxtrees@gmail.com>
// Licensed under the Apache License, Version 2.0.

#pragma once
#include "vm.h"
#include "vm_stack.h"
#include "vm_memory.h"
#include "vm_frame.h"
#include "vm_native.h"

namespace askal {

    class Exec {
    public:
        explicit Exec(VM& vm);

        void run();

        void run_until(size_t stop_depth);

    private:
        VM& vm_;
        StackOps  stack_;
        Memory    memory_;
        FrameManager frames_;
        NativeRegistry native_;

        size_t stop_depth_ = SIZE_MAX;

        void run_impl();

        uint8_t     read_byte();
        int64_t     read_signed(int bytes);
        double      read_double();
        uint32_t    read_u32();
        std::string read_str(uint32_t len);
        Value       read_literal(DataType t);

        Value do_arith(uint8_t op);
        Value do_cmp(uint8_t op);
    };

}