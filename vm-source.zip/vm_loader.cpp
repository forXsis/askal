// Askal — https://github.com/forXsis/askal
// Copyright (c) 2026 forXsis <forxtrees@gmail.com>
// Licensed under the Apache License, Version 2.0.

#include "vm_loader.h"
#include <fstream>
#include <iostream>
#include <cstring>

namespace askal {

    uint32_t Loader::read_u32(const std::vector<uint8_t>& b, size_t& p) {
        uint32_t x = 0;
        for (int i = 0; i < 4; ++i) x |= (uint32_t)b[p++] << (i * 8);
        return x;
    }

    bool Loader::skip_opcode(const std::vector<uint8_t>& bc, size_t& p) {
        if (p >= bc.size()) return false;
        uint8_t op = bc[p];

        if (op == (uint8_t)Op::END_DATA) return true;

        switch (op) {
        case (uint8_t)Op::PUSH: {
            DataType t = (DataType)bc[p + 1];
            p += 2;
            switch (t) {
            case DataType::INT8:  p += 1; break;
            case DataType::INT16: p += 2; break;
            case DataType::INT32: p += 4; break;
            case DataType::INT64:
            case DataType::INT:
            case DataType::FLOAT: p += 8; break;
            case DataType::BOOL:  p += 1; break;
            case DataType::STR:
            case DataType::BIN:
            case DataType::HEX: {
                uint32_t len = read_u32(bc, p);
                p += len;
                break;
            }
            case DataType::NULL_: break;
            }
            break;
        }
        case (uint8_t)Op::LOAD_VAR:
        case (uint8_t)Op::STORE_VAR:
        case (uint8_t)Op::JMP:
        case (uint8_t)Op::JZ:
        case (uint8_t)Op::JNZ:
            p += 5; break;
        case (uint8_t)Op::CALL:
            p += 6; break;

        case (uint8_t)Op::CALL_NATIVE: {
            p += 1;
            uint32_t lib_len = read_u32(bc, p);
            p += lib_len;
            uint32_t fn_len = read_u32(bc, p);
            p += fn_len;
            p += 1;
            break;
        }
        case (uint8_t)Op::NEW_CLASS:
        case (uint8_t)Op::LOAD_FIELD:
        case (uint8_t)Op::STORE_FIELD:
        case (uint8_t)Op::PUSH_HANDLER:
            p += 5; break;

        case (uint8_t)Op::CALL_METHOD:
            p += 6; break;
        default:
            p += 1; break;
        }
        return false;
    }

    bool Loader::load_vars(VM& vm, const std::vector<uint8_t>& bc, size_t& pos) {
        while (pos < bc.size() && bc[pos] == (uint8_t)Op::DECL_VAR) {
            pos++;
            VarDef v;
            v.id = read_u32(bc, pos);
            v.type = (DataType)bc[pos++];
            uint32_t nlen = read_u32(bc, pos);
            v.name.assign((const char*)&bc[pos], nlen); pos += nlen;

            v.value = read_value(bc, pos);
            vm.globals[v.id] = std::move(v);
        }
        return true;
    }
    Value Loader::read_value(const std::vector<uint8_t>& bc, size_t& pos) {
        Value v;
        v.type = (DataType)bc[pos++];
        switch (v.type) {
        case DataType::INT8:  v.i = (int8_t)bc[pos++]; break;
        case DataType::INT16: {
            int16_t x; std::memcpy(&x, &bc[pos], 2); pos += 2; v.i = x; break;
        }
        case DataType::INT32: {
            int32_t x; std::memcpy(&x, &bc[pos], 4); pos += 4; v.i = x; break;
        }
        case DataType::INT64:
        case DataType::INT: {
            int64_t x; std::memcpy(&x, &bc[pos], 8); pos += 8; v.i = x; break;
        }
        case DataType::FLOAT: {
            uint64_t x = 0;
            for (int i = 0; i < 8; ++i) x |= (uint64_t)bc[pos++] << (i * 8);
            std::memcpy(&v.f, &x, 8);
            break;
        }
        case DataType::BOOL:  v.b = bc[pos++] != 0; v.i = v.b ? 1 : 0; break;
        case DataType::STR:
        case DataType::BIN:
        case DataType::HEX: {
            uint32_t len = read_u32(bc, pos);
            v.s.assign((const char*)&bc[pos], len);
            pos += len;
            break;
        }
        case DataType::NULL_: break;
        case DataType::AUTO:
        case DataType::OBJECT:
        {
            uint32_t len = read_u32(bc, pos);
            v.s.assign((const char*)&bc[pos], len);
            pos += len;
        }
        break;
        }
        return v;
    }

    bool Loader::load_funcs(VM& vm, const std::vector<uint8_t>& bc, size_t& pos) {
        while (pos < bc.size() && bc[pos] == (uint8_t)Op::DECL_FUN) {
            pos++;
            FuncDef fn;
            fn.id = read_u32(bc, pos);
            uint32_t nlen = read_u32(bc, pos);
            fn.name.assign((const char*)&bc[pos], nlen); pos += nlen;
            fn.ret_type = (DataType)bc[pos++];
            fn.is_method = bc[pos++] != 0;
            uint8_t argc = bc[pos++];
            for (uint8_t i = 0; i < argc; ++i) {
                FuncArg a;
                a.id = read_u32(bc, pos);
                a.type = (DataType)bc[pos++];
                uint32_t an = read_u32(bc, pos);
                a.name.assign((const char*)&bc[pos], an); pos += an;
                fn.args.push_back(std::move(a));
            }
            uint32_t local_count = read_u32(bc, pos);
            for (uint32_t i = 0; i < local_count; ++i) {
                FuncLocal lv;
                lv.id = read_u32(bc, pos);
                lv.type = (DataType)bc[pos++];
                uint32_t ln = read_u32(bc, pos);
                lv.name.assign((const char*)&bc[pos], ln); pos += ln;
                fn.locals.push_back(std::move(lv));
            }
            if (bc[pos] != (uint8_t)Op::START_DATA) return false;
            pos++;
            size_t body_start = pos;
            while (pos < bc.size()) {
                if (skip_opcode(bc, pos)) break;
            }
            if (pos >= bc.size() || bc[pos] != (uint8_t)Op::END_DATA) return false;
            fn.body.assign(bc.begin() + body_start, bc.begin() + pos);
            pos++;
            vm.functions[fn.id] = std::move(fn);
        }
        return true;
    }

    bool Loader::load_classes(VM& vm, const std::vector<uint8_t>& bc, size_t& pos) {
        while (pos < bc.size() && bc[pos] == (uint8_t)Op::DECL_CLASS) {
            pos++;
            ClassDef c;
            c.id = read_u32(bc, pos);
            uint32_t nlen = read_u32(bc, pos);
            c.name.assign((const char*)&bc[pos], nlen); pos += nlen;
            uint32_t vc = read_u32(bc, pos);
            for (uint32_t i = 0; i < vc; ++i) c.var_ids.push_back(read_u32(bc, pos));
            uint32_t fc = read_u32(bc, pos);
            for (uint32_t i = 0; i < fc; ++i) c.fun_ids.push_back(read_u32(bc, pos));
            vm.classes[c.id] = std::move(c);
        }
        return true;
    }

    bool Loader::load(VM& vm, const std::string& path) {
        std::ifstream f(path, std::ios::binary);
        if (!f) {
            std::cerr << "Cannot open " << path << "\n";
            return false;
        }
        std::vector<uint8_t> bc((std::istreambuf_iterator<char>(f)),
            std::istreambuf_iterator<char>());
        f.close();

        size_t pos = 0;
        while (pos < bc.size()) {
            uint8_t marker = bc[pos++];
            if (marker == (uint8_t)Op::SEC_LIBS) {
                uint32_t count = read_u32(bc, pos);
                for (uint32_t i = 0; i < count; ++i) {
                    uint32_t len = read_u32(bc, pos);
                    std::string name((const char*)&bc[pos], len);
                    pos += len;
                    vm.used_libs.push_back(name);
                }
            }
            else if (marker == (uint8_t)Op::SEC_VARS) {
                if (!load_vars(vm, bc, pos)) return false;
            }
            else if (marker == (uint8_t)Op::SEC_FUNCS) {
                if (!load_funcs(vm, bc, pos)) return false;
            }
            else if (marker == (uint8_t)Op::SEC_CLASSES) {
                if (!load_classes(vm, bc, pos)) return false;
            }
            else if (marker == (uint8_t)Op::SEC_MAIN) {
                vm.main_code.assign(bc.begin() + pos, bc.end());
                return true;
            }
            else {
                std::cerr << "Unknown section marker: 0x"
                    << std::hex << (int)marker << std::dec << "\n";
                return false;
            }
        }
        return true;
    }

}