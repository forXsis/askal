// Askal — https://github.com/forXsis/askal
// Copyright (c) 2026 forXsis <forxtrees@gmail.com>
// Licensed under the Apache License, Version 2.0.

#pragma once
#include "vm.h"
#include <string>

namespace askal {

    class Loader {
    public:
        bool load(VM& vm, const std::string& path);

    private:
        static uint32_t read_u32(const std::vector<uint8_t>& b, size_t& p);
        bool load_vars(VM& vm, const std::vector<uint8_t>& bc, size_t& pos);
        bool load_funcs(VM& vm, const std::vector<uint8_t>& bc, size_t& pos);
        bool load_classes(VM& vm, const std::vector<uint8_t>& bc, size_t& pos);
        static bool skip_opcode(const std::vector<uint8_t>& bc, size_t& p);
        static Value read_value(const std::vector<uint8_t>& bc, size_t& pos);
    };

}