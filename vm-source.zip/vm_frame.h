// Askal — https://github.com/forXsis/askal
// Copyright (c) 2026 forXsis <forxtrees@gmail.com>
// Licensed under the Apache License, Version 2.0.

#pragma once
#include "vm.h"

namespace askal {

    class FrameManager {
    public:
        explicit FrameManager(VM& vm) : vm_(vm) {}

        bool enter_call(uint32_t fun_id, uint8_t argc,
            const std::vector<Value>& args);

        void leave_call(const Value& ret);

    private:
        VM& vm_;
    };

}