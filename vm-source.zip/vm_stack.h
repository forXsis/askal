// Askal — https://github.com/forXsis/askal
// Copyright (c) 2026 forXsis <forxtrees@gmail.com>
// Licensed under the Apache License, Version 2.0.

#pragma once
#include "vm.h"

namespace askal {

    class StackOps {
    public:
        explicit StackOps(VM& vm) : vm_(vm) {}
        void push(const Value& v);
        Value pop();

    private:
        VM& vm_;
    };

}