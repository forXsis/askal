// Askal — https://github.com/forXsis/askal
// Copyright (c) 2026 forXsis <forxtrees@gmail.com>
// Licensed under the Apache License, Version 2.0.

#include "vm.h"
#include <iostream>
#include <string>
#include <vector>
#include <cstdio>
#include <cstdlib>

#ifdef _WIN32
#include <windows.h>
#endif

static void setup_console() {
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif
}

static void print_usage() {
    std::cout <<
        R"(Askal VM v2.0.0
=====================================================
Usage:
  askal-vm --r <file.aklp>            Run bytecode
  askal-vm --r <file.aklp> -v         Verbose (loading info)
  askal-vm --r <file.aklp> --trace    Trace every opcode
  askal-vm --r <file.aklp> --dump     Dump globals after execution
  askal-vm --call-func <id> --aklp <path>   (internal, for thread)
  askal-vm --h                        Show help
  askal-vm --version                  Show version
)";
}

// ---------- stdin/stdout helpers для --call-func ----------

static bool read_all_stdin(std::string& out) {
#ifdef _WIN32
    HANDLE h = GetStdHandle(STD_INPUT_HANDLE);
    char buf[4096];
    DWORD got = 0;
    while (ReadFile(h, buf, sizeof(buf), &got, NULL) && got > 0)
        out.append(buf, got);
    return true;
#else
    char buf[4096];
    size_t got;
    while ((got = fread(buf, 1, sizeof(buf), stdin)) > 0)
        out.append(buf, got);
    return true;
#endif
}

static void write_all_stdout(const std::string& s) {
#ifdef _WIN32
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD written = 0;
    if (!s.empty()) WriteFile(h, s.data(), (DWORD)s.size(), &written, NULL);
#else
    if (!s.empty()) fwrite(s.data(), 1, s.size(), stdout);
#endif
}

int main(int argc, char** argv) {
    setup_console();

    if (argc < 2) { print_usage(); return 1; }

    std::string cmd = argv[1];

    if (cmd == "--h" || cmd == "-h" || cmd == "--help") {
        print_usage();
        return 0;
    }
    if (cmd == "--version" || cmd == "-V") {
        std::cout << "Askal VM v1.8.1\n";
        return 0;
    }

    if (cmd == "--r" || cmd == "-r") {
        if (argc < 3) {
            std::cerr << "Error: no input file\n";
            return 1;
        }

        std::string input = argv[2];
        bool dump = false;

        for (int i = 3; i < argc; ++i) {
            std::string a = argv[i];
            if (a == "-v") {
                askal::VM::log_out = true;
            }
            else if (a == "--trace") {
                askal::VM::trace = true;
            }
            else if (a == "--dump") {
                dump = true;
            }
            else {
                std::cerr << "Error: unknown option '" << a << "'\n";
                return 1;
            }
        }

#ifdef _WIN32
        SetEnvironmentVariableA("ASKAL_AKLP", input.c_str());
#else
        setenv("ASKAL_AKLP", input.c_str(), 1);
#endif

        askal::VM vm;
        if (!vm.load(input)) {
            std::cerr << "Load failed\n";
            return 1;
        }
        vm.current_aklp_path = input;
        bool ok = vm.execute();
        if (dump) vm.dump_globals();
        return ok ? 0 : 1;
    }

    if (cmd == "--call-func") {
        if (argc < 5) {
            std::cerr << "call-func: usage: --call-func <id> --aklp <path>\n";
            return 2;
        }

        uint32_t fid = 0;
        std::string aklp_path;

        for (int i = 2; i < argc; ++i) {
            std::string a = argv[i];
            if (a == "--aklp" && i + 1 < argc) {
                aklp_path = argv[++i];
            }
            else {
                try { fid = (uint32_t)std::stoul(a); }
                catch (...) {
                    std::cerr << "call-func: bad func id '" << a << "'\n";
                    return 2;
                }
            }
        }

        if (aklp_path.empty() || fid == 0) {
            std::cerr << "call-func: missing --aklp or func id\n";
            return 2;
        }

        askal::VM vm;
        if (!vm.load(aklp_path)) {
            std::cerr << "call-func: load failed\n";
            return 3;
        }
        vm.current_aklp_path = aklp_path;

        std::string in;
        read_all_stdin(in);

        int argc_ = 0;
        if (in.size() >= 4) {
            uint32_t len = 0;
            for (int i = 0; i < 4; ++i) len |= (uint32_t)(uint8_t)in[i] << (i * 8);
            if (in.size() >= 4 + (size_t)len && len > 0) {
                std::string blob = in.substr(4, len);
                askal::Value v = askal::VM::unpack_value(blob);
                vm.stack.push_back(v);
                argc_ = 1;
            }
        }

        if (!vm.call_function(fid, argc_)) {
            std::cerr << "call-func: call failed\n";
            return 5;
        }

        askal::Value r = vm.stack.empty()
            ? askal::Value::make_null()
            : vm.stack.back();

        std::string blob = askal::VM::pack_value(r);
        uint32_t len = (uint32_t)blob.size();
        std::string out;
        out.reserve(4 + blob.size());
        for (int i = 0; i < 4; ++i) out.push_back((char)((len >> (i * 8)) & 0xFF));
        out.append(blob);

        write_all_stdout(out);
        return 0;
    }

    std::cerr << "Error: unknown command '" << cmd << "'\n";
    print_usage();
    return 1;
}