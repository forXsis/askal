// Askal — https://github.com/forXsis/askal
// Copyright (c) 2026 forXsis <forxtrees@gmail.com>
// Licensed under the Apache License, Version 2.0.

#pragma once
#include "vm.h"

namespace askal {

    class Memory {
    public:
        explicit Memory(VM& vm) : vm_(vm) {}

        Value load_var(uint32_t id);
        void  store_var(uint32_t id, const Value& v);

    private:
        VM& vm_;
    };

}